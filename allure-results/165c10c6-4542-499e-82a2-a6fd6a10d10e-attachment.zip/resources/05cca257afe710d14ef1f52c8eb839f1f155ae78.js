/*
 * Author		: Rajasekhar Chittattooru
 * Description 	: Common JavaScripts for MVC Project
 */

// popup window properties
var winProps = 'toolbars=0, menubar=0,scrollbars=1,resizable=1,location=0,status=0,copyhistory=0,directories=0';

var PAGE_SIZE = 10; // default number of records per page
var ADULT_ID = 16;
var CHILD_ID = 17;
var MALE_ID = 24;
var FEMALE_ID = 25;
var FILTER_TYPE = null;

// report engine URL path
var rptServerPath = "";
var accomPrice=0;

// global function identify the browser type and version
(function(){
	var userAgent = navigator.userAgent.toLowerCase();
	window.browser = {
		version: (userAgent.match( /.+(?:rv|it|ra|ie)[\/: ]([\d.]+)/ ) || [0,'0'])[1],
		safari: /webkit/.test( userAgent ),
		opera: /opera/.test( userAgent ),
		msie: /msie/.test( userAgent ) && !/opera/.test( userAgent ),
		mozilla: /mozilla/.test( userAgent ) && !/(compatible|webkit)/.test( userAgent ),
		chrome: /chrome/.test( userAgent )
	};
})();

function $() {
    var elements = new Array();

    for (var i = 0; i < arguments.length; i++) {
        var element = arguments[i];

        if (typeof element == 'string')
            element = document.getElementById(element);

        if (arguments.length == 1)
            return element;

        elements.push(element);
    }
    return elements;
}
function recordOutboundLink(link, category, action) {
  try {
    var pageTracker=_gat._getTracker("UA-XXXXX-X");
    pageTracker._trackEvent(category, action);
    setTimeout('document.location = "' + link.href + '"', 100);
  }catch(err){}
}

var minutes =0, seconds = 0, xTm = 0;
function displayCounterTime(timerDv, actDiv) {
  document.getElementById(timerDv).innerHTML = (minutes < 10 ? "0" + minutes : minutes) + ":" + (seconds < 10 ? "0" + seconds : seconds);
  // Time minutes and seconds
  if(seconds <= 1) {
  	seconds = 59;
    minutes--;
  }  else {
    seconds--;
  }
  
  // If the count down is over, action on what to do next
  if (minutes < 0) {
    clearInterval(xTm);
    showdiv(actDiv);
    hidediv(timerDv);
  }
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function showClock() {
	var dayarray = new Array("Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday");
	var montharray = new Array("January","February","March","April","May","June","July","August","September","October","November","December");
	serverdate.setSeconds(serverdate.getSeconds()+1);
    var hours = serverdate.getHours();
    var minutes = serverdate.getMinutes();
    var seconds = serverdate.getSeconds();
    var day = serverdate.getDay();
    var date = serverdate.getDate();
    var month = serverdate.getMonth();
    var year = serverdate.getYear();

    var dn = "PM";
    if (hours < 12) {
        dn = "AM";
    }
    if (hours > 12) {
        hours = hours-12;
    }
    if (hours == 0) {
        hours=12;
    }
    if (minutes <= 9) {
        minutes = "0"+minutes;
    }
    if (seconds <= 9) {
        seconds = "0"+seconds;
    }

    if (year < 1000) {
        year += 1900;
    }

    var ctime = hours+": "+minutes+": "+seconds+" "+dn+", "+dayarray[day]+", "+date+" " + montharray[month]+" "+year;
	document.getElementById("clock").innerHTML = ctime;
	setTimeout("showClock()",1000);
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function disableCtrlKeyCombination(e) {
	// list all CTRL + key combinations you want to disable
    var forbiddenKeys = new Array("a", "n", "c", "x", "v", "j", "p");
    var key;
    var isCtrl;
    if(window.event) {
    	key = window.event.keyCode;     // IE
        if(window.event.ctrlKey)
        	isCtrl = true;
        else
        	isCtrl = false;
    } else {
    	key = e.which;     // firefox
        if(e.ctrlKey)
        	isCtrl = true;
        else
        	isCtrl = false;
    }
    // if ctrl is pressed check if other key is in forbidenKeys array
    if(isCtrl) {
    	for(var i=0; i<forbiddenKeys.length; i++) {
    		// case-insensitive comparation
            if(forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase()) {
            	alert("Key combination CTRL + "+String.fromCharCode(key)+" has been disabled.");
                return false;
            }
    	}
    }
    return true;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function removeDiv(parentDiv, childDiv) {
	
	if(parentDiv != null && parentDiv != "" && childDiv != null && childDiv != "") {
		var parent = document.getElementById(parentDiv);
		if(parent != null) {
			var children = parent.getElementsByTagName('div')[0];
			if(children != null) {
				parent.removeChild(children);
			}
		}
	}
}
function removeComboItems(obj){
    var selctdVal = obj.options[obj.selectedIndex].value;
    var optLen = obj.options.length;
    for (var i= optLen -1; i>=0; i--) {
		if(obj.options[i].value == selctdVal)  {
			continue;
		}
    	obj.remove(i);
    }
}
function createDiv(divId) {
	var divTag = document.createElement("div");
    divTag.id = divId;
    divTag.setAttribute("align","center");
    divTag.style.margin = "0px auto";
    return divTag;
}
function setAutocompleteOff() {
	if (document.getElementsByTagName) {
		var inputElements = document.getElementsByTagName("input");
		for (var i=0; inputElements[i]; i++) {
			if (inputElements[i].className && (inputElements[i].className.indexOf("disableAutoComplete") != -1)) {
				inputElements[i].setAttribute("autocomplete","off");
			}
		}
	}
}
function submitLogin(srcObj, eventObj) {
	var charCode = (eventObj.which) ? eventObj.which : event.keyCode;
	if(charCode == '13') {
		document.getElementById("submitBtn").click();
	}
}
/*
 * This function extends the basic JavaScript escape() functionality by also
 * encoding the '+' sign, which will otherwise be mistaken for a space.
 */
function URLencode(str)
{
    ns = escape(str);
    os = "";

    for(var i=ns.indexOf("+");-1!=i;i=ns.indexOf("+"))
    {
        os += ns.substr(0,i);
        os += "%2B";
        ns = ns.substr(i+1);
    }
    if(0 == os.length)
    {
        os = ns;
    }

    return os;
}

/*
 * This function extends the basic JavaScript escape() functionality by also
 * encoding the '+' sign, which will otherwise be mistaken for a space.
 */
function URLencode(str)
{
    ns = escape(str);
    os = "";

    for(var i=ns.indexOf("+");-1!=i;i=ns.indexOf("+"))
    {
        os += ns.substr(0,i);
        os += "%2B";
        ns = ns.substr(i+1);
    }
    if(0 == os.length)
    {
        os = ns;
    }

    return os;
}

// Returns an array containing old items (in current URL) check
function getQueryArgs()
{
    if(null == location.search)
    {		
        return new Array();	
    }	
    args = location.search.split("?");	
    if(args.length < 2)	
    {		
        return new Array();	
    }	
    s = args[1];
    args = s.split("&");
    return args;
}

/*
 * 
 * Scans the query-string of the URL of the current page and returns an array
 * holding the values for the elements of the requested name. That is, if the
 * current query string is
 * 
 * ?arg1=val1&arg2=val2U&arg2=val3&arg4=val4
 * 
 * then getFromUrl("arg1") would return ["val1"], and getFromUrl("arg2") would
 * return ["arg2","arg3"]
 * 
 */
function getFromUrl(param)
{
    n = new Array();
    count = 0;
    args = getQueryArgs();
    for(var i=0;i<args.length;i++)
    {
        nv = args[i].split("=");
        if(nv[0] != param)
        {
            continue;
        }
        n[count++] = nv[1];
    }
    return n;
}

function popUpWin(url, winName) {
	var childWin = window.open(url, winName, winProps+',width=1100, height=780');
}
function serviceHaltPopUp(url, winName) {
	var childWin = window.open(url, winName, winProps+',width=700, height=400, resizable=0');
}
/*
 * Redirect to another specified URL
 */
function gotoPage(url) {
	if (url == '') {
		url = '#';
	}
    location.href=url;
}
function gotoBack(path, btnObj) {
	var agree=confirm("Are you leaving the current page? The data you entered can not be recovered.\n Do you want to continue?");
	if (agree){
		btnObj.disabled = true;
		gotoPage(path);
	}
}
// This function used to reset the action
function setAction(action, formname) {
	var objForm = formname != '' ? document.forms[formname] : document.forms[0];
	objForm.action = action;
}
// This function used to get the radio value from form
function getRadioValue(radio) {
	for (var i=0;i<radio.length;i++) {
		if (radio[i].checked) return radio[i].value;
	}
}
/*
 * This function used for paging based on the start index
 */
function gotoIndex2(objForm, startIdx) {
	if (startIdx == '') {
		startIdx = '0';
	}
	
	// alert("form obj:"+document.forms[objForm]+" start Index "+startIdx);
	
	document.forms[objForm].startIndex.value = startIdx;
	document.forms[objForm].submit();
}
/*
 * This function used for paging based on the start index
 */
function gotoIndex(startIdx) {
	if (startIdx == '') {
		startIdx = '0';
	}
	var objForm = document.forms[0];
	objForm.startIndex.value = startIdx;
	objForm.submit();
}
/*
 * This function used for paging based on the start index
 */
function gotoIndex3(startIdx, next20) {
	if (startIdx == '') {
		startIdx = '0';
	}
	var objForm = document.forms[0];
	objForm.next20Page.value = next20;
	objForm.startIndex.value = startIdx;
	objForm.submit();
}
/*
 * This function used for paging based on the start index
 */
function gotoNext20Index(startIdx) {
	if (startIdx == '') {
		startIdx = '0';
	}
	var objForm = document.forms[0];
	objForm.next20Page.value = startIdx;
	if(objForm.pageSize != null) {
		PAGE_SIZE = objForm.pageSize.value;
	}
	objForm.startIndex.value = (startIdx - 1) * PAGE_SIZE;
	objForm.submit();
}
/*
 * This function used for paging based on the start index
 */
function gotoPrevious20Index(startIdx) {
	if (startIdx == '') {
		startIdx = '0';
	}
	var objForm = document.forms[0];
	objForm.next20Page.value = startIdx - 19;
	if(objForm.pageSize != null) {
		PAGE_SIZE = objForm.pageSize.value;
	}
	objForm.startIndex.value = (startIdx - 20) * PAGE_SIZE;
	objForm.submit();
}
/*
 * This function used for sort the column
 */
function sort(id) {
	var objForm = document.forms[0];
	var previousId = objForm.sortId.value;
	var previousOrder = objForm.sortOrder.value;
	var nextId = id;
	var nextOrder = "ASC";
	
	if ((previousId != null) && (previousId == nextId)) {
		if ((previousOrder != null) && (previousOrder == "ASC")) {
			nextOrder = "DESC";
		} else {
			nextOrder = "ASC";
		}
	}
	objForm.sortId.value = nextId;
	objForm.sortOrder.value = nextOrder;
	
	var startIdx = objForm.startIndex;
	if ((startIdx != null)) {
	objForm.startIndex.value = "0";
	}
	objForm.submit();
}
/*
 * This function used for sort the column
 */
function sort2(id, next20) {
	var objForm = document.forms[0];
	objForm.next20Page.value = next20;
	var previousId = objForm.sortId.value;
	var previousOrder = objForm.sortOrder.value;
	var nextId = id;
	var nextOrder = "ASC";
	
	if ((previousId != null) && (previousId == nextId)) {
		if ((previousOrder != null) && (previousOrder == "ASC")) {
			nextOrder = "DESC";
		} else {
			nextOrder = "ASC";
		}
	}
	
	objForm.sortId.value = nextId;
	objForm.sortOrder.value = nextOrder;
	
	var startIdx = objForm.startIndex;
	if ((startIdx != null)) {
	objForm.startIndex.value = "0";
	}
	objForm.submit();
}
// Removes leading whitespaces
function LTrim( value ) {
	var re = /\s*((\S+\s*)*)/;
	return value.replace(re, "$1");
}
// Removes ending whitespaces
function RTrim( value ) {
	var re = /((\s*\S+)*)\s*/;
	return value.replace(re, "$1");
}
function validNumber(val) {
	return val.match(/^\d+$/);
}
function validDecimal(val) {
	var reg = /^\d+(\.\d+)?$|^\.\d+$/;
	return reg.test(val);
}
function validAlphabet(val) {
	var reg = /[a-zA-z ]/;
	return reg.test(val);
}
function validAlphaNumeric(val) {
	var reg = /^[a-zA-Z0-9]+$/;
	return reg.test(val);
}
function validEmail(val) {
	var reg = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
	return reg.test(val);
}
//////////////////////////////////////
function getSelectedTextInCombo(fieldName) {
	var combObj = document.getElementById(fieldName);
	if(combObj == null || combObj.options == null) {
		return "";
	}
	return combObj.options[combObj.selectedIndex].text;
}
function checkTimeFormat(starttime, id) {
   // regular expression to match required time format
   var re = /^\d{1,4}:\d{2}([ap]m)?$/;
   if(starttime != '' && !starttime.match(re)) {
     alert("Invalid time format: " +starttime);
	  document.getElementById(id).value="";
     document.getElementById(id).focus();
     return false;
   }
}
function isNumber(txtObj) {
	var val = txtObj.value;
	if(val == "" || txtObj.value == "0.00") {
		return false;
	}
	if(validNumber(val)) {
		return true;
	} else {
		txtObj.value = "";
		txtObj.focus();
		alert("Please enter valid number.");
		return false;
	}
}
function isDecimal(txtObj) {
	var val = txtObj.value;
	if(val == "" || txtObj.value == "0.00") {
		return true;
	}
	if(validDecimal(val)) {
		return true;
	} else {
		alert("Please enter valid decimal number.");
		txtObj.value = "";
		txtObj.focus();
		return false;
	}
}
function validateDate(dtValue) {
	var dtRegex = new RegExp(/\b\d{1,2}[\/]\d{1,2}[\/]\d{4}\b/);
	return dtRegex.test(dtValue);
}

function validateAlphabet(txtObj, fieldName) {
	if(txtObj.value == "" || validAlphabet(txtObj.value)) {
		return true;
	} else {
		alert("Please enter valid " + fieldName);
		txtObj.value = "";
		txtObj.focus();
		return false;
	}
}
function validateEmail(txtObj) {
	if(txtObj.value == "" || validEmail(txtObj.value)) {
		return true;
	} else {
		alert("Please enter valid email address.");
		txtObj.value = "";
		txtObj.focus();
		return false;
	}
}
function maxLengthMoveToDest(val, maxLength, destName) {
	if(val.length == maxLength && document.getElementById(destName) != null) {
		document.getElementById(destName).focus();
	}
}
function getElementY(element){
	var targetTop = 0;
	if (element.offsetParent) {
		while (element.offsetParent) {
			targetTop += element.offsetTop;
            element = element.offsetParent;
		}
	} else if (element.y) {
		targetTop += element.y;
    }
	return targetTop;
}
// this function is used to reset the form,
// it reset the text, drop down boxes only and hidden fields.
function restForm(formObj) {
	var inputArray = document.getElementsByTagName("input");
	var size = inputArray.length;
	for(var i = 0; i < size; i++) {
		if (inputArray[i].type == "text") {
			inputArray[i].value = "";
		} else if (inputArray[i].type == "hidden") {
			if(inputArray[i].name == "ajaxAction"
				|| document.getElementById("ajaxAction").value == 'ticketHistory'
				|| inputArray[i].name == "contextPath"
				|| inputArray[i].name == "currentIndex") {
				continue;
			}
			inputArray[i].value = "";
		} else if(inputArray[i].type == 'select-one') {
			inputArray[i].value = "";
		} else if(inputArray[i].type == 'radio') {
			inputArray[i].checked = false;
		} else if(inputArray[i].type == 'checkbox'){
			inputArray[i].checked = false;
		}
	}// end of for loop
	
	if(document.getElementById("startIndex") != null) {
		document.getElementById("startIndex").value = 0;
	}
	
	if(document.getElementById("next20Page") != null) {
		document.getElementById("next20Page").value = 0;
	}
	
	if(document.getElementById("convertedFuel") != null) {
		document.getElementById("convertedFuel").value = 0.00;
	}
}// end of restForm()

// this function is used to reset the pagination form element,
function resetPaginationForm(formObj) {
	if(document.getElementById("startIndex") != null) {
		document.getElementById("startIndex").value = 0;
	}
	
	if(document.getElementById("next20Page") != null) {
		document.getElementById("next20Page").value = 0;
	}
	
}// end of resetPaginationForm()

/**
 * Thie method is used to select all the check boxes in a form, for a give
 * check box object.
 * 
 */
function  selectAllCheckBoxes(chkBoxObj) {
	// get the form object.
	var formObj= chkBoxObj.form;
	var inputArray = document.getElementsByTagName("input");
	// get the form elements size.
	var size = inputArray.length;
	// is the check box checked or not
	var isSelected = chkBoxObj.checked;
	
	for (var j=0; j < size;j++) {
		if(inputArray[j].type == 'checkbox'){
			// set the checked status as the given check object status.
			inputArray[j].checked = isSelected;
		}
		
	}// end of for loop
}// end of selectAllCheckBoxes() method.

function disableAllBtns() {
	var iAry = document.getElementsByTagName("input");
	// get the form elements size.
	var size = iAry.length;
	for (var j=0; j < size;j++) {
		// disable all buttons
		if(iAry[j].type == 'button' || iAry[j].type == 'submit')
			iAry[j].disabled = "disabled";
		
	}// end of for loop
}

function submitFormAction(path, id) {
	disableAllBtns();
	var formObj = document.getElementById(id);
	formObj.action = path;
	formObj.submit();
}
/**
 * This method is used to submit the download action and to set the form
 * action back
 */
function submitDownload(actionStr, formName) {
	var objForm = formName != '' ? document.forms[formName] : document.forms[0];
	
	if(objForm != null) {
		var prevAction = objForm.action;
		
		objForm.action = actionStr;
		objForm.submit();
		objForm.action  = prevAction;
	}
	else {
		var downWin = window.open(actionStr, 'downloadWin', 'height=10, width=10,scrollbars=1,resizable=1');
	}
}// end of submitDownload()
function trim(str) {
    if(!str || typeof str != 'string')
        return null;

    return str.replace(/^[\s]+/,'').replace(/[\s]+$/,'').replace(/[\s]{2,}/,' ');
}

function calendarPopup(id) {
	if(self.gfPop) {
		gfPop.fPopCalendar(document.getElementById(id));
	}
	return false;
}

function currCalPopup(id) {
	var d = serverdate.getDate();
    var m = serverdate.getMonth() + 1;
    var y = serverdate.getFullYear();
	
	if(self.gfPop) {
		gfPop.fPopCalendar(document.getElementById(id),[[y,m,d]]);
	}
	return false;
}

// textarea maxlength check.
function checklength(srcObj, maxLength) {
	var str =  srcObj.value;
	maxLen = parseInt(maxLength); // 200; // max number of characters
									// allowed
	if (str.length >= maxLen) {
		// Alert message if maximum limit is reached.
		// If required Alert can be removed.
		alert("You have reached your maximum limit of characters allowed");
		// Reached the Maximum length so trim the textarea
		srcObj.value = srcObj.value.substring(0, maxLen);
	}else{ // Maximum length not reached so update the value of my_text
			// counter
		document.getElementById('textnum').value = maxLen - srcObj.value.length;
	}
}
function printPageByDiv(printDivId) {
	if(printDivId == null || document.getElementById(printDivId) == null) {
		return false;
	}
	var contentObj = document.getElementById(printDivId).innerHTML; 
    var newWin = window.open("", "_blank"
    		, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no, width=1100, height=780");
    if(document.getElementById("contextPath") != null) {
    	var contextPath = document.getElementById("contextPath").value;
    	var cssLink;
    	cssLink = '<link id="skinCssID" href="' + contextPath + '/_assets/skin/print.css" rel="stylesheet" type="text/css"/>';
    	newWin.document.write(cssLink);
    	
    	cssLink = '<link id="skinCssID" href="' + contextPath + '/_assets/skin/skin_3_14_7.css" rel="stylesheet" type="text/css"/>';
    	newWin.document.write(cssLink);
    }
    newWin.document.write(contentObj); 
    newWin.document.close(); 
    myDelay = setInterval(checkReadyState, 1000);
	
	function checkReadyState() {
        if (newWin.document.readyState == "complete") {
            clearInterval(myDelay);
            newWin.focus(); // necessary for IE >= 10
            newWin.print(); 
            newWin.close();
        }
    }
    // --------------------------------------- 
}

function printCurrentPage(objName) {
 	var x = document.getElementById(objName);
	x.style.visibility = 'hidden';	
	window.print();
	x.style.visibility = 'visible';	
}
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////MODULE RELATED JAVASCRIPT CODE 														//////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function reduceOnMeal(obj, qt) {
	if(!isNumber(obj)) return false;
	var v = parseInt(obj.value);
	if(v > qt) {
		alert("Please enter valid quantity to be cancelled.");
		obj.value = qt; 
		obj.focus();
	}
}
function isFemaleSeatBooked(requestType, tdId, seatIndx, currentIdx, seatType, isGenaralLady, level) {
	if(seatType != null && seatType != '' && seatType == 'B' && isGenaralLady != 'Y') {
		return false;
	}
	var columns = parseInt(document.getElementById("columns" + requestType).value);
	var nextIdx = parseInt(seatIndx) + columns;
	var seatTd = document.getElementById((requestType + nextIdx));
	var femSt = 'ladiesSeatClass' + seatType;
	var isSingleLadyEnabled = document.getElementById("singleLadyEnabled"+ requestType);
	if(isSingleLadyEnabled != null && isSingleLadyEnabled.value == "true"){
		femSt = 'bookedSeatClassLadies' + seatType;
	}
	//for 1 column seat/sleeper
	if (document.getElementById("level_" + requestType + nextIdx) != null) {
		seatLevel = parseInt(document.getElementById("level_" + requestType+ nextIdx).value);
		if (seatLevel != level) {
			return false;
		}
	}
	if(seatTd != null) {
		if(seatTd.className == femSt  
			&& document.getElementById(("genderCodeId" + requestType + currentIdx)).value == MALE_ID) {
			return true;
		}
	}
	nextIdx = parseInt(seatIndx) - columns;
	seatTd = document.getElementById((requestType + nextIdx));
	//for 1 column seat/sleeper
	if (document.getElementById("level_" + requestType + nextIdx) != null) {
		seatLevel = parseInt(document.getElementById("level_" + requestType+ nextIdx).value);
		if (seatLevel != level) {
			return false;
		}
	}
	if(seatTd != null) {
		if(seatTd.className == femSt 
			&& document.getElementById(("genderCodeId" + requestType + currentIdx)).value == MALE_ID) {
			return true;
		}
	}
	return false;
}

function isAdjusantConductorSeat(requestType, tdId, seatIndx, currentIdx, seatType) {
	if(seatType != null && seatType != '' && seatType == 'B') {
		return false;
	}
	var columns = parseInt(document.getElementById("columns" + requestType).value);
	var nextIdx = parseInt(seatIndx) + columns;
	var seatTd = document.getElementById((requestType + nextIdx));
	var femSt = 'conductorSeatClass' + seatType;
	if(seatTd != null) {
		if(seatTd.className == femSt  
			&& document.getElementById(("genderCodeId" + requestType + currentIdx)).value == MALE_ID) {
			return true;
		}
	}
	nextIdx = parseInt(seatIndx) - columns;
	seatTd = document.getElementById((requestType + nextIdx));
	
	if(seatTd != null) {
		if(seatTd.className == femSt 
			&& document.getElementById(("genderCodeId" + requestType + currentIdx)).value == MALE_ID) {
			return true;
		}
	}
	return false;
}

function lockFemaleAdjacentSeat(requestType, tdId, seatIndx, currentIdx, seatType, isGenaralLady, level) {
	if(seatType != null && seatType != '' && seatType == 'B' && isGenaralLady != 'Y') {
		return false;
	}	
	var columns = parseInt(document.getElementById("columns" + requestType).value);	
	var nextIdx = parseInt(seatIndx) + columns;
	var seatTd = document.getElementById((requestType + nextIdx));
	var femSt = 'ladiesSeatClass' + seatType;
	//for 1 column seat/sleeper
	if (document.getElementById("level_" + requestType + nextIdx) != null) {
		seatLevel = parseInt(document.getElementById("level_" + requestType+ nextIdx).value);
		if (seatLevel != level) {
			return false;
		}
	}
	if(seatTd != null) {
		if(seatTd.className == femSt) {
			var fOb = document.getElementById(("genderCodeId" + requestType + currentIdx));
			if(fOb != null) {
				fOb.value = FEMALE_ID;
				removeComboItems(fOb);
			}
		}
	}
	nextIdx = parseInt(seatIndx) - columns;
	seatTd = document.getElementById((requestType + nextIdx));
	//for 1 column seat/sleeper
	if (document.getElementById("level_" + requestType + nextIdx) != null) {
		seatLevel = parseInt(document.getElementById("level_" + requestType+ nextIdx).value);
		if (seatLevel != level) {
			return false;
		}
	}
	if(seatTd != null) {
		if(seatTd.className == femSt ) {
			document.getElementById(("genderCodeId" + requestType + currentIdx)).value = FEMALE_ID;
			removeComboItems(document.getElementById(("genderCodeId" + requestType + currentIdx)));
		}
	}	
}

function checkWLSeatsOrder(requestType){
	for(var j=1004;j>=1000;j--) {
		wlObj = document.getElementById(requestType + j);
		if(wlObj != null && wlObj.className.indexOf('selec') != -1) {
			if(!checkWaitingListSeats(requestType, j)) {
				return false;
			}
		}
	}
	return true;
}

function checkWaitingListSeats(requestType, seatIndx) {
	for(var i=1;i<=4;i++){
		var minIdx = parseInt(seatIndx)-i;
		if(minIdx < 0) {
			break;
		}
		var mintdId = document.getElementById((requestType + minIdx));
		
		if(mintdId != null && mintdId.className.indexOf('avail') != -1) {
			alert('Please select minimum waiting list seat number');
			return false;
		} 
	}
	return true;
}

function setSelectedSeatDetail(requestType, seatNumber, seatType, seatIndx, level) {	
	var indx = parseInt(document.getElementById("currSeatIndex" + requestType).value);
	
	var size = 1 ;
	
	var tdId = document.getElementById((requestType + seatIndx));
		
	if(seatNumber.indexOf('WL') != -1 && tdId.className.substring(0,5) == "avail") {
		var flag = checkWaitingListSeats(requestType, seatIndx);
		if(!flag) return false;
	}
	
	var maxSeatsAllowed = parseInt(document.getElementById("maxPassengerAllowed").value);
	size = maxSeatsAllowed;
	if(indx < 0) {
		indx = 0;
	}
	if(indx >= size && tdId.className == ("availSeatClass" + seatType)) {
		alert("Maximum " + size + " seat(s) allowed to book.");
		return false;
	}
	
	var tblId = 'PaxTbl'+requestType;
	var fvs = document.getElementById("femaleSeatSpanId" + requestType);
	if(fvs != null) {
		fvs.innerHTML = "";
		fvs.className = "";
	}
	
	var sLdy = document.getElementById("sldyAllowed" + requestType);
	
	var isSingleLadyEnabled = document.getElementById("singleLadyEnabled"+ requestType);
	
	var isSingleLadyAllowedForThisBus = document.getElementById("singleLadyEnabledForBus"+ requestType);
	//for sleeper
	var isgeneralLady = '';
	if(document.getElementById("generalLadyEnabledForBus" + requestType) != null){
		isgeneralLady = document.getElementById("generalLadyEnabledForBus" + requestType).value
	}
	// set seat details and calculate total price details 
	var isPaxConceAllowed = false;
	if(tdId != null) {
		if(tdId.className == ("selectedSeatClass" + seatType)) {
			tdId.className = "availSeatClass" + seatType;
			
			indx = indx - 1;
			var vb = false;
			for(var sIdx = 0; sIdx < indx; sIdx++) {
				if(document.getElementById(("seatDetails" + requestType + sIdx)).value == seatNumber) {
					vb = true;	
				}
				if(vb && document.getElementById(("seatDetails" + requestType + (sIdx+1)))) {
					document.getElementById(("seatDetails" + requestType + sIdx)).value = document.getElementById(("seatDetails" + requestType + (sIdx+1))).value;
					document.getElementById(("categoryCodeId" + requestType + sIdx)).value = document.getElementById(("categoryCodeId" + requestType + (sIdx+1))).value;
					document.getElementById(("genderCodeId" + requestType + sIdx)).value = document.getElementById(("genderCodeId" + requestType + (sIdx+1))).value;
					document.getElementById(("passengerName" + requestType + sIdx)).value = document.getElementById(("passengerName" + requestType + (sIdx+1))).value;
					document.getElementById(("passengerAge" + requestType + sIdx)).value = document.getElementById(("passengerAge" + requestType + (sIdx+1))).value;
					
					if(document.getElementById(("nationality" + requestType + (sIdx+1)))!=null){
						document.getElementById(("nationality" + requestType + sIdx)).value = document.getElementById(("nationality" + requestType + (sIdx+1))).value;					
						document.getElementById(("passportNo" + requestType + sIdx)).value = document.getElementById(("passportNo" + requestType + (sIdx+1))).value;
						document.getElementById(("foreignerAddress" + requestType + sIdx)).value = document.getElementById(("foreignerAddress" + requestType + (sIdx+1))).value;
						document.getElementById(("dob" + requestType + sIdx)).value = document.getElementById(("dob" + requestType + (sIdx+1))).value;	
					}
					
					if(document.getElementById("paxConcessionAllowed") != null){
						isPaxConceAllowed = document.getElementById("paxConcessionAllowed").value;
						
						if(isPaxConceAllowed == "true"){
							if(document.getElementById(("concessionIds" + requestType + (sIdx+1)))){
								document.getElementById(("concessionIds" + requestType + sIdx)).value = document.getElementById(("concessionIds" + requestType + (sIdx+1))).value;
							}
						}
					}
				}
			}
			document.getElementById(("seatDetails" + requestType + indx)).value = "";
			document.getElementById(("genderCodeId" + requestType + indx)).value = "";
			document.getElementById(("passengerName" + requestType + indx)).value = "";
			document.getElementById(("passengerAge" + requestType + indx)).value = "";

			if(document.getElementById("nationality" + requestType + indx)!=null){
				document.getElementById(("nationality" + requestType + indx)).value = "";
			}
			removePaxRow(requestType, indx, tblId);			
		} else {
			if(requestType == 'Return'){
				var indxForward = parseInt(document.getElementById("currSeatIndexForward").value);
				if(indxForward == indx ){
					if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == 1){
						alert("Numbers of onwrad and multileg seats should be same. ");
					}
					alert("Numbers of onwrad and return seats should be same. ");
					return false;
				}
			}
			if(sLdy != null && sLdy.value == "1" && indx > 0) {
				alert("Please select single lady seat only. You are not allowed for multiple single lady seats.")
				return false;
			}
			
			if(document.getElementById("paxConcessionAllowed") != null)
				isPaxConceAllowed = document.getElementById("paxConcessionAllowed").value;
			
			if(isPaxConceAllowed == "true"){
				addNewPaxConcessRow(requestType, indx, tblId, tdId, seatIndx, seatType,isSingleLadyEnabled, isSingleLadyAllowedForThisBus);
			}else{
				addNewPaxRow(requestType, indx, tblId, tdId, seatIndx, seatType, isSingleLadyEnabled, isSingleLadyAllowedForThisBus);
			}
			if(requestType == 'Return'){
				populateEachPaxDetails(indx);
			}
			if(requestType == 'End'){
				populateLinkEachPaxDetails(indx);
			}
			if(sLdy != null && sLdy.value == 1) {
				document.getElementById("genderCodeId" + requestType + indx).value = FEMALE_ID;
				removeComboItems(document.getElementById("genderCodeId" + requestType + indx));
			}
			
			if(document.getElementById("isLadiesSpecial" + requestType) != null && 
					Number(document.getElementById("isLadiesSpecial" + requestType).value) == 1) {
				document.getElementById("genderCodeId" + requestType + indx).value = FEMALE_ID;
				removeComboItems(document.getElementById("genderCodeId" + requestType + indx));
			}
			
			tdId.className = "selectedSeatClass" + seatType;
			//copyPrimaryPaxName();
			
			if(isAdjusantConductorSeat(requestType, tdId, seatIndx, indx, seatType)) {
				var tmsg = "Only Male is allowed next to Driver Seat.";
				var b = confirm(tmsg);
				if(!b) {
					tdId.className = "availSeatClass" + seatType;
					document.getElementById(("seatDetails" + requestType + indx)).value = "";
					document.getElementById(("genderCodeId" + requestType + indx)).value = "";
					document.getElementById(("passengerName" + requestType + indx)).value = "";
					document.getElementById(("passengerAge" + requestType + indx)).value = "";
					removePaxRow(requestType, indx, tblId);
					return false;
				}
				document.getElementById(("genderCodeId" + requestType + indx)).value = MALE_ID;
				removeComboItems(document.getElementById(("genderCodeId" + requestType + indx)));
				fvs = document.getElementById("femaleSeatSpanId" + requestType);
				if(fvs != null) {
					fvs.innerHTML = tmsg;
					fvs.className = "errormsg";
				}
			}
			if((isSingleLadyEnabled != null && isSingleLadyEnabled.value == "false") || (isSingleLadyAllowedForThisBus != null && isSingleLadyAllowedForThisBus.value == "false")) { // isSingleLadyEnabled.value == "false" means single lady feature disabled
				if(isFemaleSeatBooked(requestType, tdId, seatIndx, indx, seatType, isgeneralLady, level)) {
					tdId.className = "selectedSeatClass" + seatType;
					var tmsg = "Only a female is allowed to book next to female seat";
					var b = confirm(tmsg);
	//				// if not confirmed then do not allow the user to continue the seat selection.
					if(!b) {
						tdId.className = "availSeatClass" + seatType;
						document.getElementById(("seatDetails" + requestType + indx)).value = "";
						document.getElementById(("genderCodeId" + requestType + indx)).value = "";
						document.getElementById(("passengerName" + requestType + indx)).value = "";
						document.getElementById(("passengerAge" + requestType + indx)).value = "";
						removePaxRow(requestType, indx, tblId);
						return false;
					}
					document.getElementById(("genderCodeId" + requestType + indx)).value = FEMALE_ID;
					removeComboItems(document.getElementById(("genderCodeId" + requestType + indx)));
					fvs = document.getElementById("femaleSeatSpanId" + requestType);
					if(fvs != null) {
						fvs.innerHTML = tmsg;
						fvs.className = "errormsg";
					}
				}
			}
			
			
			lockFemaleAdjacentSeat(requestType, tdId, seatIndx, indx, seatType, isgeneralLady, level);
			document.getElementById(("seatDetails" + requestType + indx)).value = seatNumber;
			indx = indx + 1;			
		}
	}
	//calculateTotalFare(requestType);
	calculateLayoutFares(requestType);
	document.getElementById("currSeatIndex" + requestType).value = indx;
	//set reward points
	hidediv("ShowRewardPoinstDiv");
	showdiv("ShowBtnRedeemDivID");
	if(document.getElementById("redeemCheck") != null)
		document.getElementById("redeemCheck").checked = false;
}
function ttdAlert(reqType){

if(document.getElementById("alertTtd")!= null){
	if((document.getElementById("alertTtd").value=="1" && reqType=="Forward")
	  ||(document.getElementById("alertTtd").value=="1" && reqType=="Return" && document.getElementById('isFirstLinkTtd') != null && document.getElementById('isFirstLinkTtd').value == '')){
		
	alert("Rs.300/- E-SPL Entry Darshan Tickets to avail the Darshan of \nLord Sri Venketeswara, Tirumala are available for this service. You can book now");
	}
}
}
function calculateBalance(collectedAmt) {
	var balanceObj = document.getElementById("BalanceAmtId");
	
	if(collectedAmt == "") 
		collectedAmt = 0.00;
	var prevTotalVal = 0.00;
	if(document.getElementById("totalAmount") != null) {
		prevTotalVal = parseFloat(document.getElementById("totalAmount").value);
	}
	var balancePrice = parseFloat(collectedAmt) - parseFloat(document.getElementById("grandTotal").value) + prevTotalVal;
	
	balanceObj.innerHTML = balancePrice.toFixed(2); 
	if(balancePrice >= 0) {
		balanceObj.className = "greenBgColor";
		document.getElementById("SavePassengersBtn").disabled = "";
	} else {
		balanceObj.className = "redFontColor";
		document.getElementById("SavePassengersBtn").disabled = "disabled";
	}
}
function hideBookingLayout() {
	hideDivision("ShowLayoutDiv");
	hideDivision("ShowReturnLayoutDiv");
}
function validateBookingForm(requestType) {
	var size = 10; 
	// set seat details and calculate total price details
	var ageObj, seatObj, nm, ad, genderObj, idProofObj, concessionObj, cardNumObj; 
	ad = false;
	var pax = 0;
	for(var i=0; i<size; i++) {
		nm = document.getElementById(("passengerName" + requestType + i));
		ageObj = document.getElementById(("passengerAge" + requestType + i));
		seatObj = document.getElementById(("seatDetails" + requestType + i));
		genderObj = document.getElementById(("genderCodeId" + requestType + i));
		if( document.getElementById(("concessionIds" + requestType + i)) != null){
			concessionObj = document.getElementById(("concessionIds" + requestType + i));
		}
		if( document.getElementById(("cardNumber" + requestType + i)) != null){
			cardNumObj = document.getElementById(("cardNumber" + requestType + i));
		}
		if( document.getElementById("idProof" + requestType + i) != null){
			idProofObj = document.getElementById(("idProof" + requestType + i));
		}
		if(seatObj == null) { continue; }
		
		if(genderObj != null && genderObj.value != '24' && genderObj.value != '25'){
			alert("Please select gender.");
			genderObj.focus();
			return false;
		}
		if(document.getElementById("isLadiesSpecial" + requestType) != null &&
				Number(document.getElementById("isLadiesSpecial" + requestType).value) == 1	) {
			if(genderObj.value != '25'){
				alert("Female only allowed to book for this service");
				genderObj.focus();
				return false;
			}
		}
		if(document.getElementById(("categoryCodeId" + requestType + i)).value == ADULT_ID) {
			ad = true;
		}
		if(seatObj.value == "") {
			alert("Please select " + size + " number of seat(s).");
			ageObj.focus();
			return false;
		} else if(ageObj.value == "") {
			alert("Please enter passenger age.");
			ageObj.focus();
			return false;
		} else if(nm.value == "") {
			alert("Please enter passenger name.");
			nm.focus();
			return false;
		} else if(idProofObj != null && idProofObj.value.trim() == "") {
			alert("Please enter ID Proof Details");
			idProofObj.focus();
			return false;
		} else if(concessionObj != null && (concessionObj.value.trim() == "" || concessionObj.value == -1)) {
			alert("Please select concession type ");
			concessionObj.focus();
			return false;
		}else if(cardNumObj != null && cardNumObj.disabled == false && cardNumObj.value == "") {
			alert("Please enter card number ");
			cardNumObj.focus();
			return false;
		}
		nationalityObj=document.getElementById(("nationality" + requestType + i));
		if(nationalityObj!= null) {
			if(nationalityObj.value!='IN'){
				if((size-1)==i){
					return foreignPassengerValidation(requestType + i)
				}
				else{
					if(!foreignPassengerValidation(requestType + i)){
						return false;
					}			
				} 
			}
		}
		++pax;
	}
	document.getElementById("currSeatIndex" + requestType).value = pax;
	if(ad == false) {
		alert("Atleast one adult passenger is required to continue.");
		return false;
	}
	return true;
}

function validateMandatoryFields() {
	var inputArray = document.getElementsByTagName("input");
	var size = inputArray.length;
	// validate form here
	for(var i = 0; i < size; i++) {
		if(inputArray[i].type == "text"
			&& inputArray[i].className == 'requiredfield' 
			&& inputArray[i].value == '') {
			alert("Please fill the required fields to continue.");
			return false;
		}
	}
	return true;
}

function validateMobileNo(ob)  {
	var msg = "";
	var val = ob.value;
	if(val.length != 10) msg = "Please enter valid 10 digits mobile number.";
	else if(val.charAt(0) != '6' && val.charAt(0) != '7' && val.charAt(0) != '8' && val.charAt(0) != '9')
		msg = "Mobile number must start with 6 or 7 or 8 or 9.";
	if(msg != "") {
		alert(msg);
		ob.value = "";
		ob.focus();
		return false;
	}
	return true;
}

function validateSubmitBookingLayout() {
	// validate Mobile number
	var txtObj = document.getElementById("mobileNo");
	var val = "";
	var msg = "";
	
	if(!validateMobileNo(txtObj)) {
		return false;
	}
	
	// validate Passenger Name for 150 characters
	/*txtObj = document.getElementById("bookedByName");
	val = txtObj.value;
	if(val.length > 100) msg = "The Passenger Name   can not be more than 100 characters.";
	else if(LTrim(RTrim(val)).length < 1) 
		msg = "Please enter valid Passenger Name.";
	*/
	if(msg != "") {
		alert(msg);
		txtObj.focus();
		return false;
	}
	
	txtObj = document.getElementById("email");
	if(txtObj != null && txtObj.value == "") {
		alert("Please enter valid email address.");
		txtObj.focus();
		return false;
	}
	
	// validate Address field for 100 characters
	txtObj = document.getElementById("address");
	if(txtObj != null) {
		val = txtObj.value;
		msg = "Address can not be more than 100 characters.";
		if(val.length > 100) {
			alert(msg);
			txtObj.focus();
			return false;
		}
	}
	txtObj = document.getElementById("cardNumber");
	if(txtObj != null && txtObj.value == "") {
		alert("Please enter card number.");
		txtObj.focus();
		return false;
	}

	if(document.getElementById('isLinkEndBooking') == null || document.getElementById('isLinkEndBooking').value != '1'){
		if(!validateBookingForm("Forward")) return false;
		if(!checkWLSeatsOrder("Forward")) return false;
	}
	
	var txtObj = document.getElementById("totalAmount");
	if(txtObj != null) {
		document.getElementById("oldBookingAmt").value = txtObj.value;
		var grandTotal = parseFloat(document.getElementById("grandTotal").value);
		grandTotal = grandTotal - parseFloat(txtObj.value);
		document.getElementById("collectedAmt").value = grandTotal.toFixed(2);
	}
	
	
	var fwCurIdx = 0,  rtCurIdx = 0;
	
	fwCurIdx = parseInt(document.getElementById("currSeatIndexForward").value);
	if(document.getElementById("currSeatIndexReturn") != null) {
		rtCurIdx = parseInt(document.getElementById("currSeatIndexReturn").value);
		
		if(!checkWLSeatsOrder("Return")) return false;
		
		if(!validateBookingForm("Return")) {
			return false;
		}
		if(fwCurIdx != rtCurIdx) {
			alert("Please select same number of seats in Onward and return journey.");
			return false;
		}
	}
	return true;
}

function bookingFormSubmitAction(path, formObj) {
	if(!validateSubmitBookingLayout()) {
		return false;
	}
	if(!checkRedeemRewardEnable()) {
		return false;
	}
	if(!validateTTDDarsanPassengers('Forward')) {
		return false;
	}
	if(document.getElementById("currSeatIndexReturn") != null) {
		if(!validateTTDDarsanPassengers('Return')) {
			return false;
		}
	}
 	var ob = document.getElementById("copyPaxChk");
 	if(ob != null) {
		populatePaxDetails(true);
	}
 	var acttype = "Forward";
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
		acttype = "Return";
	}	
 	if(document.getElementById('srisailamAccommodationId') != null && document.getElementById('srisailamAccommodationId').value != ''){
 		if(($('#srisailamAccommodationId').length == 0  || ($('#srisailamAccommodationId').length > 0 
 	 			&& document.getElementById('srisailamAccommodationId').value == ''))
 	 			|| (($('#SrslmAccomadationDiv').css('display') != 'none') 
 	 					&& ($('#idProofPopUp'+acttype).css('display') == 'block'))
 	 			||(document.getElementById('isFirstLinkSrslm') != null && document.getElementById('isFirstLinkSrslm').value == '1')){	

 	 		formObj.action = path;
 	 		formObj.submit();	
 	 	}
 	 	else if(document.getElementById('paxProofId') != null){
 	 		if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
 	 	 		getIdProofPopUp("idProofPopUpReturn");
 	 		}else{
 	 			getIdProofPopUp("idProofPopUpForward");
 	 		}
 	 	}else{
 	 		formObj.action = path;
 	 		formObj.submit();	
 	 	}
 	}else{
 	if(($('#ttdAccommodationId').length == 0  || ($('#ttdAccommodationId').length > 0 
 			&& document.getElementById('ttdAccommodationId').value == ''))
 			|| (($('#TtdAccomadationDiv').css('display') != 'none') 
 					&& ($('#idProofPopUp'+acttype).css('display') == 'block'))
 			|| (document.getElementById('isFirstLinkTtd') != null && document.getElementById('isFirstLinkTtd').value == '1')){

 		formObj.action = path;
 		formObj.submit();	
 	}
 	else if(document.getElementById('paxProofId') != null){
 		if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
	 	 		getIdProofPopUp("idProofPopUpReturn");
	 		}else{
	 			getIdProofPopUp("idProofPopUpForward");
	 		}
 	}else{
 		formObj.action = path;
 		formObj.submit();	
 	}
 	}
}

function addDay(dtVal, days) {
    var curDate;
    var dateObj;
	
	curDate = getDateObj(new Date());
	
    if(dtVal == 'Depart On') {
    	return curDate;
    }
	
    var dtAr = dtVal.split("/");
	var yy = parseInt(dtAr[2]);
	var mm = parseInt(dtAr[1]) - 1;
	var dd = parseInt(dtAr[0]);
	dateObj = new Date(yy, mm, dd); // year, month, day
	dateObj.setDate(dateObj.getDate() + days);
	dateObj = getDateObj(dateObj);
	
	if (dateObj >= curDate) {
        // alert("Date Obj is greather then equal to Current Date.");
    	return dateObj;
    } else {
      // alert("Date Two is greather then Date One.");
    }
    return dateObj;
}

function padDt(s) { 
	return (s < 10) ? '0' + s : s; 
}

function getDateObj(d) {
	return [padDt(d.getDate()), padDt(d.getMonth()+1), d.getFullYear()].join('/');
}

function convertDateStr(dateObj) {
	return getDateObj(dateObj);
}

function refineSearchResults(days) {
	var contextPath = document.getElementById("contextPath").value;
	var path = contextPath + '/avail/services.do';
	
	var ob = document.getElementById("txtJourneyDate");
	formObj = ob.form;
	
	var t = "";
	if(ob != null) {
		t = addDay(ob.value, days);
		
		if(t == null) {
			return false;
		}
		ob.value = t;
	}
	
	if(document.getElementById('isLinkStartBooking') != null && document.getElementById('isLinkStartBooking').value == '1'){
		if(document.getElementById("txtReturnJourneyDate") != null){
			document.getElementById("txtReturnJourneyDate").value = 'For Roundtrip';
		}
	}
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
		if(document.getElementById("txtReturnJourneyDate") != null){
			document.getElementById("txtReturnJourneyDate").value = 'For Roundtrip';
		}
	}
	
	ob = document.getElementById("txtReturnJourneyDate");
	
	if(ob != null && ob.value != "" && ob.value != 'For Roundtrip') {
		t = addDay(ob.value, days);
		if(t != null) {
			ob.value = t;
		}
		
	}
	validateBookingSearch(formObj, path);
}

function validateBookingSearch(formObj, path) {
	var txtObj;
	var t;
	txtObj = document.getElementById("startPlaceId");
	if(txtObj.value == "" || txtObj.value == "0" || txtObj.value == "From") {
		alert("Please select start place.");
		return false;
	}
	t = txtObj.value;
	txtObj = document.getElementById("endPlaceId");
	if(txtObj.value == "" || txtObj.value == "0" || txtObj.value == "To") {
		alert("Please select end place.");
		return false;
	}
	if((formObj.fromPlaceName.value.toLowerCase()=="from") || (formObj.fromPlaceName && !formObj.fromPlaceName.value)) {
	    alert("Please select start place.");
		return false;
	}
	
	if((formObj.toPlaceName.value.toLowerCase()=="to") || (formObj.toPlaceName && !formObj.toPlaceName.value)) {
	    alert("Please select end place.");
		return false;
	}
	
	if(t == txtObj.value) {
		alert("End Place cannot be same as Start Place.");
		return false;
	}
	if(document.getElementById("adultMale") != null)
		adultMale = document.getElementById("adultMale").value;
	
	if(document.getElementById("txtJourneyDate") != null)
		t = document.getElementById("txtJourneyDate").value;
	
	if(t != null && t != "" && !validateDate(t)) {
		// alert("Please select a valid Journey Date to continue.");
		$('#txtJourneyDate').datepicker("show");
		return false;
	}
	if(document.getElementById("txtReturnJourneyDate") != null){
		t = document.getElementById("txtReturnJourneyDate").value;
		if(document.getElementById("txtLinkJourneyDate") != null)
			document.getElementById("txtLinkJourneyDate").value = t;
	}
	if(t == null || t == "" || t == "For Roundtrip") {
		document.getElementById("txtReturnJourneyDate").value = "";
	} else if(t != null && t != "" && !validateDate(t)) {
		// alert("Please select a valid Journey Date to continue.");
		$('#txtReturnJourneyDate').datepicker("show");
		return false;
	}
	
	formObj.action = path;
	formObj.submit();
	
}
function modifyPlace(obj) {
    if(!obj.value) {
	if(document.getElementById("startPlaceId") && document.getElementById("startPlaceId").value !='') {
	    document.getElementById("startPlaceId").value=obj.value;
	}
    }this
}
function modifyPlaces(obj){
    if(!obj.value){
	if(document.getElementById("endPlaceId") && document.getElementById("endPlaceId").value !='') {
	    document.getElementById("endPlaceId").value=obj.value;
	}
    }
}

function submitTrack(formObj,path) {
	
	txtObj = document.getElementById("id");
	if(txtObj.value == "" || txtObj.value == "0") {
		alert("Please enter Ticket Number value");
		txtObj.focus();
		return false;
	}
	
	txtObj = document.getElementById("uidNumber");
	if(txtObj.value == "" || txtObj.value == "0") {
		alert("Please enter UID Number");
		txtObj.focus();
		return false;
	}
	
	txtObj = document.getElementById("mobileNo");
	if(txtObj.value == "" || txtObj.value == "0") {
		alert("Please enter Mobile Number");
		txtObj.focus();
		return false;
	}
	formObj.action = path;
	formObj.submit();
}

function ttdRefAlert(){
	if(document.getElementById("ttdNoRefund")!= null){
		if(document.getElementById("ttdNoRefund").value=="1"){
		alert("TTD dharshan amount will not be refunded");
		}
	}
}

function showCancelTicket() {
	if(document.getElementById("id")!= null && document.getElementById("returnId") != null && document.getElementById("returnJourney").checked == true){
		var onwardTkt = document.getElementById("id").value;
		var returnTkt = document.getElementById("returnId").value;
		alert("You are selected both onward Ticket " + onwardTkt+" and Return Ticket "+returnTkt+" to cancel");
		
	}
	if(document.getElementById("returnId")==null && document.getElementById("returnJourney")!=null){
		document.getElementById("returnJourney").checked=false;
	}
	var returnJourney;
	if(document.getElementById("returnJourney")!=null){
		returnJourney = document.getElementById("returnJourney").value;
	}
	var divName = 'BookedTicketsDivId';
	hideMessages();
	
	var path =  "/ajax/cancel/details/load.do?searchType=0"
				+ "&id=" + document.getElementById("id").value
				+ "&uidNumber=" + document.getElementById("uidNumber").value
				+ "&mobileNo=" + document.getElementById("mobileNo").value
				+ "&returnJourney=" + returnJourney;
	;
	var txtObj = document.getElementById("id");
	if(txtObj.value == "" || txtObj.value == "0") {
		alert("Please enter Ticket Number value");
		txtObj.focus();
		return false;
	}
	
	txtObj = document.getElementById("uidNumber");
	if(txtObj.value == "" || txtObj.value == "0") {
		alert("Please enter UID Number");
		txtObj.focus();
		return false;
	}
	
	txtObj = document.getElementById("mobileNo");
	if(!validateMobileNo(txtObj)) {
		return false;
	}
	if(document.getElementById("returnJourney")!=null){
	var returnJourneyCheck = document.getElementById("returnJourney");
	var txtObj = document.getElementById("returnId");
	if (returnJourneyCheck.checked && txtObj!=null) {
		if(txtObj.value == "" || txtObj.value == "0") {
			alert("Please enter return journey Ticket Number value");
			txtObj.focus();
			return false;
		} else {
			path = path + "&returnId=" + document.getElementById("returnId").value;
		}
		
		txtObj = document.getElementById("returnUidNumber");
		if(txtObj.value == "" || txtObj.value == "0") {
			alert("Please enter return journey UID Number");
			txtObj.focus();
			return false;
		} else {
			path = path +"&returnUidNumber=" + document.getElementById("returnUidNumber").value
		}
		
		txtObj = document.getElementById("returnMobileNo");
		if(!validateMobileNo(txtObj)) {
			return false;
		} else {
			path = path +"&returnMobileNo=" + document.getElementById("returnMobileNo").value
		}
	}
		
		}
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function validateAgeField(txtObj, actType, idx) {
	if(!isNumber(txtObj)) {
		return false;
	}
	var max = parseInt(document.getElementById("maxAgeCh").value);
	var age = parseInt(txtObj.value);
	var id = 0;
	
	if(document.getElementById("categoryCodeId" + actType + idx) != null) {
		id = document.getElementById("categoryCodeId" + actType + idx).value;
	}
	
	if(CHILD_ID == id && age > max) {
		alert("Child age must be less than or equal to " + max + " years.");
		txtObj.value = "";
		return false;
	}
	var destName = "passengerName" + actType + (parseInt(idx) + 1);
	maxLengthMoveToDest(txtObj.value, 2, destName);
}

function setThisValueTo(destName, sourceObj) {
	var destObj = document.getElementById(destName);
	if(destObj != null) {
		destObj.value = sourceObj.value;
	}
}
function hideMessages() {
	hidediv('errorMsg');
	hidediv('successmsg');
}

function submitRepeatBooking(formObj) {
	document.getElementById("repeat").value = '1';
	formObj.submit();	
}
function showRepeatBookingLayout() {
	if(document.getElementById("repeat").value == '1'
		&& document.getElementById("serviceId").value != "") {
		document.getElementById("repeat").value = '0';
		document.getElementById("aType").value = "search";
		getAvailableServiceList('/booking/specific/search.do?aType=search');
	}
}
function showFareTypeScheduleDiv(val) {
	if(val == '0') {
		hidediv('fareTypeScheduleDivId');
	} else {
		showdiv('fareTypeScheduleDivId');
		setSelectedDays('0');
	}
}
function showMinTravelDistanceScheduleDetail(val) {
	if(val == '' || parseFloat(val) <= 0.00) {
		hidediv('minTravelScheduleDivId');
	} else {
		showdiv('minTravelScheduleDivId');
		checkSelectedDayDetails('0', 'minDay_');
	}
}
function submitBookingForm(param) {
	if(param == '') {
		hidediv('ForwardAvailableServicesDiv');
		hidediv('ReturnAvailableServicesDiv');
		hidediv('buttonsDivId');
		showdiv('loginPageDivId');
	} else {
		document.getElementById("bookingsForm").submit();
	}
}
function pgSubmitAction(path, formObj) {
	var pgObj;
	var pgchk = false;
	for(var i=1; i<=3; i++) {
		pgObj = document.getElementById(("pgId"+i));
		if(pgObj == null) {
			break;
		} else if(pgObj.checked == true) {
			pgchk = true;
			break;
		}
	}
	if(pgchk) {
		alert("Please select payment gateway to continue.");
		return false;
	}
	if(document.getElementById("termsChk").checked == false) {
		alert("Please accept terms and conditions.");
		return false;
	}
	formObj.action = path;
	formObj.submit();
}
function printTickets(formObj) {
	hide('srslmPrintDv_0');
	hide('ttdPrintDv_0');
	hide('srslmPrintDv_1');
	hide('ttdPrintDv_1');
	printPageByDiv("TktPrintDivID_0");
	divObj = document.getElementById("TktPrintDivID_1");
	if(divObj != null) {
		printPageByDiv("TktPrintDivID_1");
	}
}
function printTTDTickets(formObj) {
	hide('ttdPrintDv_0');
	printPageByDiv("ttdPrintDv_0");
	
	divObj = document.getElementById("ttdPrintDv_1");
	if(divObj != null) {
		hide('ttdPrintDv_1');
		printPageByDiv("ttdPrintDv_1");
	}
}

function divFlipFlop(divName, obj) {
	var dObj = document.getElementById(divName);
	var v = dObj.style.display;
	if(v == null || v == '' || v == 'none' || !(v)) {
		obj.className = 'modifyBkgSelect';
		dObj.style.display = 'block';
	}
	/* else {
		obj.className = 'modifyBkgCS';
		dObj.style.display = 'none';
	}*/
	if(document.getElementById('isLinkStartBooking') != null && document.getElementById('isLinkStartBooking').value == '1'){
		if(document.getElementById("txtReturnJourneyDate") != null){
			document.getElementById("txtReturnJourneyDate").value = 'For Roundtrip';
		}
	}
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
		if(document.getElementById("txtReturnJourneyDate") != null){
			document.getElementById("txtReturnJourneyDate").value = 'For Roundtrip';
		}
	}
	hidediv('fwInfoLeftId');
	hidediv('retInfoLeftId');
	hidediv('ForwardAvailableServicesDiv');
	hidediv('ReturnAvailableServicesDiv');
	hidediv('ForwardEndAvailableServicesDiv');
}
function setAccomodationDetails(actName, id, ac, price) {
	document.getElementById(("accomodationId" + actName)).value = id;
	document.getElementById(("acFlag" + actName)).value = ac;
	if(price !=''){
		accomPrice = price;
		calculateTotalFare(actName);
	} else {
		accomPrice = 0;
		calculateTotalFare(actName);
	}
	if(id == '') {
		document.getElementById("acmdtPrice" + actName).value = 0.00;
	}
}

function setTtdAccomodationAmount(actName) {
	calculateTotalFare(actName);

}

function searchTtdAccDetails(path, divName, requestType, dateMinRange, dateMaxRange){
	var ttdAccJourneyDate, serviceId;
	var aPax = 0, cPax = 0, totPax = 0;
	var tripNo = 0;
	var startdateParts = null;
	var enddateParts = null;
	var darshanDateParts = null;
	var startDate = null;
	var endDate = null;
	var darshanDate = null;
	if(dateMinRange && dateMaxRange) {
		startdateParts = dateMinRange.split("/");
		enddateParts = dateMaxRange.split("/");
		startDate = new Date(+startdateParts[2], startdateParts[1] - 1, +startdateParts[0]);
		endDate = new Date(+enddateParts[2], enddateParts[1] - 1, +enddateParts[0]);
	}
	var max = parseInt(document.getElementById("maxAgeCh").value);
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			
			if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax;
	if(totPax == 0){
		alert("Please select seat..");
		return false;
	}
	

	var Obj = document.getElementById("ttdAccJourneyDate");
	console.log(ttdAccJourneyDate);
	if(Obj == null) {
		alert("Please select date to continue..");
		return false;
	} else {
		ttdAccJourneyDate = Obj.value;
	}
	if(ttdAccJourneyDate == ""){
		alert("Please select Darshan Date.");
		return false;
	}
	darshanDateParts = ttdAccJourneyDate.split("/");
	darshanDate = new Date(+darshanDateParts[2], darshanDateParts[1] - 1, +darshanDateParts[0]);
	if(startDate && endDate) {
		if(!(darshanDate >= startDate && darshanDate <= endDate)) {
			alert("Please select available Darshan Date.");
			return false;
		}
	}
	
	if(document.getElementById("TtdSearchAccDiv")) {
		document.getElementById("TtdSearchAccDiv").style.display = '';
	}
	Obj = document.getElementById("ForwardServiceId");
	if(Obj != null){
		serviceId = Obj.value;
	}
	if(requestType == 'Return'){
		Obj = document.getElementById("ReturnServiceId");
		if(Obj != null){
			serviceId = Obj.value;
		}
	}
	if(requestType == 'Return'){
		Obj = document.getElementById("retTripNo");
		if(Obj != null)
			tripNo = Obj.value;
	} else {
		Obj = document.getElementById("forwardTtripNo");
		if(Obj != null)
			tripNo = Obj.value;
	}
	path =  path +"?serviceId=" +serviceId
	+ "&ttdAccJourneyDate=" + ttdAccJourneyDate
	+"&totalNoPassengers="+totPax
	+"&RequestType="+requestType
	+"&tripNo=" + tripNo
	;
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function setTtdAccomodationDetails(requestType, ttdAccId, slot, linkAccommodationId) {

	if(ttdAccId == 0){
		if(document.getElementById('ttdAccommodationId') != null)
			document.getElementById('ttdAccommodationId').value = "";
		
		if(document.getElementById('linkAccommodationId') != null)		
			document.getElementById("linkAccommodationId").value = "";
		
		if(document.getElementById('totalTtdAccAmount') != null){
			document.getElementById('totalTtdAccAmount').value = 0;
			if(document.getElementById('totalLinkAccAmt') != null)		
				document.getElementById('totalLinkAccAmt').value = 0;
			setTtdAccomodationAmount('Forward');
			document.getElementById('TtdAccomadationDiv').style.display = "none";
		}
		return false;
	}
	showdiv('TtdAccomadationDiv');
	
if(requestType == 'Forward'){
	document.getElementById('ttdAccFlag').value = 0;
}else{
	document.getElementById('ttdAccFlag').value = 1;
}
	divName = "TtdAccomadationDiv";
	var ttdAccJourneyDate, serviceId;
	var Obj = document.getElementById("ttdAccJourneyDate");
	if(Obj != null) {
		ttdAccJourneyDate = Obj.value;
	}

	if(ttdAccJourneyDate == ""){
		alert("Please select Darshan Date.");
		return false;
	}

	Obj = document.getElementById("ForwardServiceId");
	if(Obj != null){
		serviceId = Obj.value;
	}
	
	var aPax = 0, cPax = 0, totPax = 0;
	var max = parseInt(document.getElementById("maxAgeCh").value);
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			
			if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax;
	document.getElementById("linkAccommodationId").value = linkAccommodationId;
	document.getElementById('ttdAccommodationId').value = ttdAccId;
	var tripNo;
	if(document.getElementById("forwardTtripNo") != null)
		tripNo = document.getElementById("forwardTtripNo").value;
	
	var darshandPlaceId = document.getElementById('endPlaceId').value;
	if(document.getElementById('isLinkStartBooking') != null 
			&& document.getElementById('isLinkStartBooking').value == '1'
			&& document.getElementById('linkPlaceId') != null
			&& document.getElementById('linkPlaceId').value != ''){
		darshandPlaceId = document.getElementById('linkPlaceId').value;
	}
	var journeyDate = document.getElementById('txtJourneyDate').value;
	var startPlaceId = document.getElementById('startPlaceId').value;
	if(document.getElementById('isLinkEndBooking') != null 
			&& document.getElementById('isLinkEndBooking').value == '1'
			&& document.getElementById('endPlaceId') != null
			&& document.getElementById('endPlaceId').value != ''){
		startPlaceId = document.getElementById('linkPlaceId').value;
		darshandPlaceId = document.getElementById('endPlaceId').value;
		Obj = document.getElementById("ReturnServiceId");
		if(Obj != null){
			serviceId = Obj.value;
		}
		Obj = document.getElementById("retTripNo");
		if(Obj != null){
			tripNo = Obj.value;
		}
	}

	var path =  "/ttd/search/slot.do?ttdAccommodationId=" + ttdAccId
	+"&ttdSlot=" + slot
	+"&totalNoPassengers="+totPax
	+"&ttdAccJourneyDate=" + ttdAccJourneyDate
	+"&serviceId=" + serviceId
	+ "&txtJourneyDate=" + journeyDate
	+ "&startPlaceId=" + startPlaceId
	+ "&endPlaceId=" + darshandPlaceId
	+ "&concessionId=" + document.getElementById('concessionId').value
	+ "&tripNo=" + tripNo
	+ "&requestType=" + requestType   
	+ "&linkAccommodationId=" + linkAccommodationId
	;

	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	/*if(price !=''){
		accomPrice = price;
		calculateTotalFare(actName);
	} else {
		accomPrice = 0;
		calculateTotalFare(actName);
	}
	if(id == '') {
		document.getElementById("acmdtPrice" + actName).value = 0.00;
	}*/
}
function displaySelectedSearchPage(val,advDays) {
	autocompletePlace("#fromPlaceName","#startPlaceId");
	autocompletePlace("#toPlaceName","#endPlaceId");
	if(advDays == null || advDays == ''){
		advDays = 30;
	}
	$('#txtJourneyDate').datepicker({ numberOfMonths: 2
			, dateFormat: 'dd/mm/yy'
			, minDate: '0'
			, maxDate: "+"+advDays+"d"
			,  onSelect: function(selected) {$("#txtReturnJourneyDate").datepicker("option","minDate", selected);}
			}).val();
	
	if(document.getElementById("txtJourneyDatePop")) {
		$('#txtJourneyDatePop').datepicker({ numberOfMonths: 2
			, dateFormat: 'dd/mm/yy'
			, minDate: '0'
			, maxDate: "+30d"
			}).val();
	}
	
	
	$('#txtReturnJourneyDate').datepicker({ numberOfMonths: 2
			, dateFormat: 'dd/mm/yy'
			, minDate: '0'
			, maxDate: "+"+advDays+"d"
			
		}).val();

	
	setHelpText('From', 'fromPlaceName');
	setHelpText('To', 'toPlaceName');
}
function submitUserForm(formObj){
	var user = document.getElementById("error");
	if(user != null) { 
		if(user.value == 'true') {
			alert("Login Name Already Exist!");
			return false;
		}
	}
	var email = document.getElementById("flag");
	if(email != null) { 
		if(email.value == 'true') {
	    	alert("Email ID Already Exist!");
	    	return false;	
	    }
    }
	var mobileNo = document.getElementById("flag1");
	if(mobileNo != null) { 
		if(mobileNo.value == 'true') {
	    	alert("Mobile Number Already Exist!");
	    	return false;	
	    }
    }
	formObj.submit();
}
function populatePaxDetails(chk) {
	var oj = 'Forward';
	var rt = 'Return';
	var indx = parseInt(document.getElementById("currSeatIndex" + rt).value);
    var curIdx = 0;    
	for(var i = 0; i < 10 ; i++) {
		if(document.getElementById("categoryCodeId" + rt + i) != null
			&& document.getElementById("categoryCodeId" + oj + i) != null) {
			if(chk == true) {
				document.getElementById("categoryCodeId" + rt + i).value = document.getElementById("categoryCodeId" + oj + i).value;
				document.getElementById("genderCodeId" + rt + i).value = document.getElementById("genderCodeId" + oj + i).value;
				document.getElementById("passengerName" + rt + i).value = document.getElementById("passengerName" + oj + i).value;
				document.getElementById("passengerAge" + rt + i).value = document.getElementById("passengerAge" + oj + i).value;				
			}  else {
				document.getElementById("passengerName" + rt + i).value = "";
				document.getElementById("passengerAge" + rt + i).value = "";
				
			}
			document.getElementById("categoryCodeId" + rt + i).value = document.getElementById("categoryCodeId" + oj + i).value;
			curIdx++;
		}
		if(curIdx == indx)  {
			break;
		}
	}//  end of for loop
	calculateTotalFare(rt);
}

function populateEachPaxDetails(indx) {
	var oj = 'Forward';
	var rt = 'Return';
	var curIdx = 0,countIndians=0; 
	var indxselected = indx;
	for(var indx = 0; indx <=  indxselected ; indx++) {
		if(document.getElementById("categoryCodeId" + rt + indx) != null
				&& document.getElementById("categoryCodeId" + oj + indx) != null) {
				
					document.getElementById("categoryCodeId" + rt + indx).value = document.getElementById("categoryCodeId" + oj + indx).value;
					document.getElementById("genderCodeId" + rt + indx).value = document.getElementById("genderCodeId" + oj + indx).value;
					document.getElementById("passengerName" + rt + indx).value = document.getElementById("passengerName" + oj + indx).value;
					
					document.getElementById("passengerAge" + rt + indx).value = document.getElementById("passengerAge" + oj + indx).value;				
					
					var isPaxConceAllowed = false;
					if(document.getElementById("paxConcessionAllowed") != null){
						isPaxConceAllowed = document.getElementById("paxConcessionAllowed").value;
						if(isPaxConceAllowed == "true"){
							if(document.getElementById("cardNumber" + oj + indx) != null){
								document.getElementById("cardNumber" + rt + indx).value = document.getElementById("cardNumber" + oj + indx).value;
								document.getElementById("cardNumber"+ rt + indx).readOnly = true;
								//document.getElementById("cardNumber"+ rt + indx).setAttribute("readonly","readonly");

							}
							if(document.getElementById("concessionIds" + oj + indx) != null){
								document.getElementById("concessionIds" + rt + indx).value = document.getElementById("concessionIds"+ oj + indx).value;
								document.getElementById("concessionIds"+ rt + indx).setAttribute("style","opacity: 0.5;pointer-events: none;cursor: default;");						
							}	
						}
						for(i=0;i<document.querySelectorAll("[id^='nationalityForward']").length;i++){
							if(document.querySelectorAll("[id^='nationalityForward']")[i].value=='IN'){
								countIndians++;
							}
						}
						
						//if(document.getElementById("dob" + oj +indx)!=null ){
							
							if(document.querySelectorAll("[id^='nationalityForward']").length!=countIndians){
							var hiddenForeignerId=document.getElementsByClassName('hiddenForeignerId');
							while (hiddenForeignerId.length) hiddenForeignerId[0].classList.remove("hiddenForeignerId");
							}
							for(i=0;i<document.querySelectorAll("[id^='nationalityForward']").length;i++){
								
								/*if(document.querySelectorAll("[id^='nationalityForward']")[i].value=='IN'){
									if(document.getElementById('foreignerForward'+i) !=null)
										document.getElementById('foreignerForward'+i).classList.add("hiddenForeignerId");
									if(document.getElementById('foreignerReturn'+i) !=null)
										document.getElementById('foreignerReturn'+i).classList.add("hiddenForeignerId");
								}*/
								if(document.querySelectorAll("[id^='nationalityForward']")[i].value=='IN'){
									if(document.getElementById('foreignerPnoForward'+i) !=null){
										document.getElementById('foreignerPnoForward'+i).classList.add("hiddenForeignerId");
										document.getElementById('foreignerPaddForward'+i).classList.add("hiddenForeignerId");
										document.getElementById('foreignerpDobForward'+i).classList.add("hiddenForeignerId");
										
										if(document.getElementById('foreignerPnoReturn'+i) !=null){
											document.getElementById('foreignerPnoReturn'+i).classList.add("hiddenForeignerId");
											document.getElementById('foreignerPaddReturn'+i).classList.add("hiddenForeignerId");
											document.getElementById('foreignerpDobReturn'+i).classList.add("hiddenForeignerId");
										}
									}
								}
							}
							if(document.querySelectorAll("[id^='nationalityForward']").length!=countIndians){
								document.getElementById("dob" + rt + indx).value = document.getElementById("dob" + oj +indx).value;
								document.getElementById("passportNo" + rt + indx).value = document.getElementById("passportNo" + oj +indx).value;
								document.getElementById("foreignerAddress" + rt + indx).value = document.getElementById("foreignerAddress" + oj +indx).value;
								document.getElementById("nationality" + rt + indx).value = document.getElementById("nationality" + oj +indx).value;
							}
						
						//}
					}
					document.getElementById("categoryCodeId" + rt + indx).value = document.getElementById("categoryCodeId" + oj +indx).value;
				curIdx++;
			}
		 //calculateTotalFare(rt);
	}
}

function populateLinkEachPaxDetails(indx) {
	var oj = 'Start';
	var rt = 'End';
    var curIdx = 0;    
		if(document.getElementById("categoryCodeId" + rt + indx) != null
			&& document.getElementById("categoryCodeId" + oj + indx) != null) {
			
			document.getElementById("categoryCodeId" + rt + indx).value = document.getElementById("categoryCodeId" + oj + indx).value;
			document.getElementById("genderCodeId" + rt + indx).value = document.getElementById("genderCodeId" + oj + indx).value;
			document.getElementById("passengerName" + rt + indx).value = document.getElementById("passengerName" + oj + indx).value;
			if(document.getElementById("concessionIds" + oj + indx) != null){
				document.getElementById("concessionIds" + rt + indx).value = document.getElementById("concessionIds" + oj + indx).value;
			}
			document.getElementById("passengerAge" + rt + indx).value = document.getElementById("passengerAge" + oj + indx).value;				
			
			var isPaxConceAllowed = false;
			if(document.getElementById("paxConcessionAllowed") != null){
				isPaxConceAllowed = document.getElementById("paxConcessionAllowed").value;
				if(isPaxConceAllowed == "true"){
					document.getElementById("cardNumber" + rt + indx).value = document.getElementById("cardNumber" + oj + indx).value;
				}
			}
			document.getElementById("categoryCodeId" + rt + indx).value = document.getElementById("categoryCodeId" + oj +indx).value;
		curIdx++;
	}
	 //calculateTotalFare(rt);
}

function showNewsDiv(subect,i) {
	var dv = document.getElementById('nwDiv');
	dv.style.display = 'block';
    dv.style.opacity = 2;
    var btn = "<a haref=# class=nwsHrefCs onclick=hidediv(\'nwDiv\')>close x</a>";
	var aTxt = "<table class=newsbodyTbl><tr><td>" + btn + "</td></tr>"
			+ "<tr><td class=newsSubject>" + document.getElementById("subjectCode"+i).innerHTML+ "</td>"
			+ "<tr><td>"+ document.getElementById("textMessage"+i).innerHTML 
			+ "</td></tr></table>" ;
	dv.innerHTML = aTxt ;
}
function showClassification() {
	var s = document.getElementById("classTextDiv").className;
	
	if(s == 'showClasTxt') {
		s = "hideClasTxt";
	} else {
		s = "showClasTxt";
	}
	document.getElementById("classTextDiv").className = s;
}
function changeDivClss(id,s) {
	document.getElementById(id).className = s;
}
function showfac(a) {
	var s = document.getElementById(a).className;
	if(s == 'showClasTxt') {
		s = "hideClasTxt";
	} else {
		s = "showClasTxt";
	}

	document.getElementById(a).className = s;
}

function confirmCancellation(path, formObj) {
	var a = false;
	if(document.getElementById("id")!= null && document.getElementById("returnId")!= null){
		var onwardTkt = document.getElementById("id").value;
		var returnTkt = document.getElementById("returnId").value;
		a = confirm("ALERT: Do you want to cancel the ticket with return journey as well?");
	} else {
		a = confirm("ALERT: Do you want to cancel the ticket?");
	}
	
	
	if (a) {
		submitFormAction(path, formObj);
	}
}
/** DOM PRINTER END * */
/** AutoComplete place details **/
function autocompletePlace(ele,dataEle) {
	$(ele).autocomplete({
	    source: jsondata,
	    minLength: 3,
	    autoFocus: true,
	    select: function (event, ui) { 
	        $(ele).val( ui.item.value );
	        $(dataEle).val(ui.item.id);	 
	    }
	}).data("ui-autocomplete")._renderItem = function(ul, item) {
		return $("<li class=\"" + item.value + "\"></li>").data(
				"ui-autocomplete-item", item).append(
				$("<a></a>").html(
						'<span style="font-weight:bold">' + item.data_name
								+ '</span><br>'
								+ '<span style="font-style:italic">'
								+ convertToCameCaselString(item.data_pickupPoint) + '</span>')).appendTo(ul);	
};
}


function autocomplete(ele,dataEle,data) {
	$(ele).autocomplete({
	    source: data,
	    autoFocus: true,
	    select: function (event, ui) { 
	        $(ele).val( ui.item.value );
	        $(dataEle).val(ui.item.id);	 
	    }
	});	
}
function resetTxt(o, v) {
	if(o != null) {
		o.value = v;
	}
	$('#txtJourneyDate').datepicker({ numberOfMonths: 2
		, dateFormat: 'dd/mm/yy'
		, minDate: '0'
		, maxDate: "+30d"
		}).val();
}
function clearHelpText(txt, name) {
	var temp = new Array();
	temp = txt.split(",");
	var obj = document.getElementById(name);
	var cs = obj.className;
	if(cs == 'placesRequired') {
		cs = cs.replace("placesRequiredGray",  "placesRequired");
		obj.className = cs;
	}
	if(obj.value == temp[0] || (temp.length > 1 && obj.value == temp[1])) {
		obj.value = '';
	}
}

function setHelpText(txt, name) {
	var obj = document.getElementById(name);
	if(obj == null){
		return;
	}
	var cs = obj.className;
	if(cs == 'placesRequiredGray') {
		cs = cs.replace("placesRequired",  "placesRequiredGray");
		obj.className = cs;
	}
	if(obj.value == '') {
		obj.value = txt;
	}
}
/* For package tours display */
function showDetailsPack(showId) {
	hidediv("maintableId");
	hidediv("srisailDivId");
	hidediv("arakuDivId");
	hidediv("niamDivId");
	hidediv("hanumaDivId");
	hidediv("hydDivId");	
	hidediv("kadapaDivId");
	hidediv("yaganDivId");
	hidediv("lepakDivId");
	hidediv("nachDivId");
	hidediv("tiruDivId");
	hidediv("basaraDivId");
	showdiv(showId);
	showdiv("buttonId");
}

function showMainPack() {
	showdiv("maintableId");
	//hidediv("papiDivId");
	hidediv("kaniDivId");
	hidediv("srisailDivId");
	hidediv("arakuDivId");
	hidediv("niamDivId");
	hidediv("hanumaDivId");
	hidediv("kadapaDivId");
	hidediv("hydDivId");
	hidediv("kadapaDivId");
	hidediv("yaganDivId");
	hidediv("lepakDivId");
	hidediv("nachDivId");
	hidediv("tiruDivId");
	hidediv("basaraDivId");
	hidediv("buttonId");
}
function calendarMnYrSelect(id) {
	$('#'+id).datepicker({ numberOfMonths: 1, dateFormat: 'dd/mm/yy', changeMonth: true
	, changeYear: true, yearRange: '2010:2030'}).val();
}

function calendarMnYrSelectDob(id) {
	$('#'+id).datepicker({ numberOfMonths: 1, dateFormat: 'dd/mm/yy', changeMonth: true
	, changeYear: true, yearRange: '1950:2030'}).val();
}

function populateSearch(fId,fnm,tId,tnm) {
	var ob = document.getElementById("startPlaceId");
	if(ob != null) {
		ob.value = fId;
	}
	ob = document.getElementById("fromPlaceName");
	if(ob != null) {
		ob.value = fnm;
	}
	
	ob = document.getElementById("endPlaceId");
	if(ob != null) {
		ob.value = tId;
	}
	ob = document.getElementById("toPlaceName");
	if(ob != null) {
		ob.value = tnm;
	}
	$("#txtJourneyDate").datepicker('show');
}

function populateGtsSearch(fId, fnm, tId, tnm ) {
    var ob = document.getElementById("startPlaceId");
    if (ob != null) ob.value = fId;

    ob = document.getElementById("fromPlaceName");
    if (ob != null) ob.value = fnm;

    ob = document.getElementById("endPlaceId");
    if (ob != null) ob.value = tId;

    ob = document.getElementById("toPlaceName");
    if (ob != null) ob.value = tnm;
    
    ob = document.getElementById("source");
    if (ob != null) ob.value = fnm;
    
    ob = document.getElementById("destination");
    if (ob != null) ob.value = tnm;
            
    var dateObj = document.getElementById("txtJourneyDate");
    dateObj.value = formatDateToDDMMYYYY(new Date());
    var form = document.getElementById("bookingsForm"); // or use `dateInput.form` if inside the form
    if (form) {
        validateBookingSearch(form, '/oprs-web/avail/services.do');
    }
}

function formatDateToDDMMYYYY(date) {
    const day = String(date.getDate()).padStart(2, '0'); // Get day and pad with leading zero
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Get month (0-indexed) and pad with leading zero
    const year = date.getFullYear(); // Get full year

    return `${day}/${month}/${year}`; // Construct and return formatted date
}


function removePaxRow(act, idx, divId) {

	$('#'+ act +  idx + "tr" ).detach();
	if(document.getElementById(act+idx+"fr") != null){
		$('#'+ act +  idx + "fr" ).detach();
	}
}

function addNewPaxRow(act, idx, divId, tdId, seatIndx, seatType, isSingleLadyEnabled,isSingleLadyAllowedForThisBus) {
	var _rEle, _nStrEle;
	var nStr = act + idx ;
	var readOnlyStr= '';
	var disabled='';
	var seniorCitizonVal='';
	if(act!="Forward"){
		disabled='style="opacity: 1.5;pointer-events: none;cursor: default;"';
		readOnlyStr='readonly="readonly"';
	} 
	_nStrEle = '</div></div>';
	if(document.getElementById('nationality')!=null){
		var countriesListOptions=document.getElementById('nationality').innerHTML;
		_nStrEle = '<tr id="' + nStr + "fr" + '">'
			+'<td class="hiddenForeignerId" id="foreignerPno'+nStr+'">'
			+ '		<input type="text" name="passportNo" placeholder="Passport or Travel Document number" id="passportNo'+nStr+'" class="form-control"  size="15"  maxlength="20"   readonly="readonly" class="requiredfield"/>'						
			+ '</td><td class="hiddenForeignerId" id="foreignerPadd'+nStr+'">'
			+ '     <textarea name="foreignerAddress"  placeholder="Address in India (including hotels):" id="foreignerAddress'+nStr+'"  class="form-control w-100" maxlength="100" rows="1" cols="30"  readonly="readonly" wrap="hard" class="requiredfield" style="width: 170px;"/>'
			+ '</td><td class="hiddenForeignerId" id="foreignerpDob'+nStr+'">'
			+ '     <input type="text" name="dob" placeholder="Date of Birth as in Passport" id="dob'+nStr+'"	class="dateRequiredfield" id="dob'+nStr+'" size="11" maxlength="10" value=""  readonly="readonly"   /> '
			+ '</td>'
			+ '</tr>'
		;
	}
	_rEle = '<tr id="' + nStr + "tr" + '"><td>' 
				+ '<input type="hidden" name="categoryCodeId" id="categoryCodeId' + nStr + '" value="'+ ADULT_ID +'" />'
				+ '<select name="genderCodeId" id="genderCodeId' + nStr + '" class="requiredfield" onChange="isGeneralLadyBooking(\''+act+'\', \''+tdId+'\', \''+seatIndx+'\', \''+idx+'\', \''+seatType+'\',  \''+divId+'\', \''+isSingleLadyEnabled+'\', \''+isSingleLadyAllowedForThisBus+'\')">'
				+ '<option value="">Select One</option>'
				+ '<option value="24">MALE</option>'
				+ '<option value="25">FEMALE</option>'
				+ '</select>'
			+ '</td><td>'
				+ '<input type="text" name="passengerName" id="passengerName' + nStr + '" maxlength="150" size="16" class="requiredfield" onkeyup="validateAlphabet(this, this.name);">'
			+ '</td>'
			+ '<td>'
				+ '<input type="text" name="passengerAge" id="passengerAge' + nStr + '" maxlength="2" size="2" class="requiredfield" onkeyup="calculateLayoutFares(\''+act+'\');">'
			+ '</td>'
			+ '<td>'
				+ '<input type="text" name="seatDetails" id="seatDetails' + nStr + '" size="1" class="seatNormalField" readonly="readonly">'
			+ '</td>'
			+ '<td>' 
			+ '<select name="nationality" '+disabled+' id="nationality'+nStr+'" class="form-control custom-select" onchange="enabledPassPortNo(\'' + nStr + '\')" class="requiredfield b-d-point-select" >'
			+ countriesListOptions
			+'</select>'
			+ '</td>' 
			+ '</tr>'
		;
		
	$('#'+divId+' tr:last').after(_rEle+_nStrEle);
}

function addNewPaxConcessRow(act, idx, divId, tdId, seatIndx, seatType, isSingleLadyEnabled,isSingleLadyAllowedForThisBus){
	var _rEle,_nStrEle,_nationEle;
	var nStr = act + idx ;
	var readOnlyStr= '';
	var disabled='';
	var concessionList = document.getElementById('concessionId_'+act).innerHTML;
	_nStrEle = '</div></div>';
	_nationEle = '<div></div>';
	if(act!="Forward"){
		readOnlyStr='readonly="readonly"';
		disabled='style="opacity: 1.5;pointer-events: none;cursor: default;"';
	} 
	if(document.getElementById('nationality')!=null){
		var countriesListOptions=document.getElementById('nationality').innerHTML;
		_nStrEle = '<tr id="' + nStr + "fr" + '">'
			+'<td class="hiddenForeignerId" id="foreignerPno'+nStr+'">'
			+ '		<input type="text" name="passportNo" placeholder="Passport or Travel Document number" id="passportNo'+nStr+'" class="form-control"  size="15"  maxlength="20"   readonly="readonly" class="requiredfield"/>'						
			+ '</td><td class="hiddenForeignerId" id="foreignerPadd'+nStr+'">'
			+ '     <textarea name="foreignerAddress"  placeholder="Address in India (including hotels):" id="foreignerAddress'+nStr+'"  class="form-control w-100" maxlength="100" rows="2" cols="30"  readonly="readonly" wrap="hard" class="requiredfield" style="width: 170px;"/>'
			+ '</td><td class="hiddenForeignerId" id="foreignerpDob'+nStr+'">'
			+ '     <input type="text" name="dob" placeholder="Date of Birth as in Passport" id="dob'+nStr+'"	class="dateRequiredfield" id="dob'+nStr+'" size="11" maxlength="10" value=""  readonly="readonly"   /> '
			+ '</td>'
			+ '</tr>'
		;
	}
	_rEle = '<tr id="' + nStr + "tr" + '"><td>' 
	+ '<input type="hidden" name="categoryCodeId" id="categoryCodeId' + nStr + '" value="'+ ADULT_ID +'" />'
	+ '<select name="genderCodeId" id="genderCodeId' + nStr + '" class="requiredfield" onChange="isGeneralLadyBooking(\''+act+'\', \''+tdId+'\', \''+seatIndx+'\', \''+idx+'\', \''+seatType+'\',  \''+divId+'\', \''+isSingleLadyEnabled+'\', \''+isSingleLadyAllowedForThisBus+'\')">'
	+ '<option value="">Select One</option>'
	+ '<option value="24">MALE</option>'
	+ '<option value="25">FEMALE</option>'
	+ '</select>'
	+ '</td><td>'
	+ '<input type="text" name="passengerName" id="passengerName' + nStr + '" maxlength="150" size="16" class="requiredfield" onkeyup="validateAlphabet(this, this.name);">'
	+ '</td>'
	+ '<td>'
	+ '<input type="text" name="passengerAge" id="passengerAge' + nStr + '" maxlength="2" size="2" class="requiredfield" onkeyup="calculateLayoutFares(\''+act+'\');">'
	+ '</td>'
	+ '<td>'
	+ '<input type="text" name="seatDetails" id="seatDetails' + nStr + '" size="1" class="seatNormalField" readonly="readonly">'
	+ '</td>'
	+ '<td>'
	+ '<select name="concessionIds" id="concessionIds'+nStr+'" class="requiredfield b-d-point-conselect" onchange="validatePaxSeniorSitizenCon(\'' + nStr + '\',\'' + act + '\', this.value);">'
	+ ''
	+concessionList
	+'<br>'
	+'</select>'
	+ '</td>'
	+ '<td>'
	+ '<input type="text" name="cardNumbers" id="cardNumber' + nStr + '"  class="marginCardNumber"  value ="-" onblur="validateConcessionCard(\'' + nStr + '\',\'' + act + '\', this.value);" maxlength="50" size="12"  disabled="disabled"> <div id="passengerDiv'+ nStr +'"></div>'
	+ '</td>'
;
	if(document.getElementById('nationality')!=null){
	_nationEle ='' + '<td>'
	+ '<select name="nationality" '+disabled+' id="nationality'+nStr+'" class="option_width form-control custom-select" onchange="enabledPassPortNo(\'' + nStr + '\')" class="requiredfield b-d-point-select" >'
	+ countriesListOptions
	+'</select>'
	+ '</td>'
	+ '</tr>'
	;
	}
	else {
	_nationEle ='' + '</tr>'
		;
	}
$('#'+divId+' tr:last').after(_rEle+_nationEle+_nStrEle);
	
}


function validatePaxSeniorSitizenCon(journeyType, index,value){
	if(document.getElementById("seniorSitizenConcIdForward") != null){
		var seniorSitiConId = document.getElementById("seniorSitizenConcIdForward").value;
		if(seniorSitiConId == value){
			var age = document.getElementById("seniorSitizenAgeForward").value;
			var enteredAge = document.getElementById("passengerAge"+journeyType).value;
			if(enteredAge < age){
				alert("Senior Sitizen age should be not less than "+age);
				document.getElementById("passengerAge"+journeyType).value = "";
				document.getElementById('concessionIds'+journeyType).selectedIndex = "-1";
				return false;
			}
		}
	}
	
	var genConcessionId = document.getElementById("genPublicConcId").value;
	if(genConcessionId == value || value == -1){
		if(document.getElementById("cardNumber"+journeyType) != null){
			document.getElementById("cardNumber"+journeyType).value = "-";
			document.getElementById("cardNumber"+journeyType).disabled = true;
		}
	} else {
		document.getElementById("cardNumber"+journeyType).disabled = false;
		document.getElementById("cardNumber"+journeyType).value = "";
	}
	
}



function setTotalSeatsDetails(t) {
	var services = 0, seats = 0;
	var ob;
	
	ob = document.getElementById(t + "TotalServices");
	if(ob != null) {
		services = parseInt(ob.value);
	}
	
	
	ob = document.getElementById(t + "TotalSeats");
	if(ob != null) {
		seats = parseInt(ob.value);
	}
	
	if(document.getElementById(t + "TotalServicesId") != null)
		document.getElementById(t + "TotalServicesId").innerHTML = services;
	if(document.getElementById(t + "TotalSeatsId") != null)
		document.getElementById(t + "TotalSeatsId").innerHTML = seats;
}

/* FILTERs for listing page */
function delFil(filterTypeid, clrType, position) {
    if (position === undefined || position == 1) var position = '';
    if (clrType == "ClearAll") {
        $('.FilSearch').each(function() {
            if ($(this).attr("title") == filterTypeid) {
                $(this).prop('checked', false);
                $("#ActFil" + $(this).value).hide();
            }
        });
        $("." + filterTypeid + "Active").remove();
        if (position == '2') {
            if (filterTypeid == "TravelsNameR")
                opf2 = 0;
            else if (filterTypeid == "BustypesR")
                btf2 = 0;
            else if (filterTypeid == "BoardingPointR")
                bpf2 = 0;
            else if (filterTypeid == "DroppingPointR")
                dpf2 = 0;
        } else {
            if (filterTypeid == "TravelsName")
                opf = 0;
            else if (filterTypeid == "Bustypes")
                btf = 0;
            else if (filterTypeid == "BoardingPoint")
                bpf = 0;
            else if (filterTypeid == "DroppingPoint")
                dpf = 0;
        }
    } else {
        $("#" + clrType + filterTypeid).prop('checked', false);
        if (position == '2')
            $("#ActFil2" + clrType + filterTypeid).remove();
        else
            $("#ActFil" + clrType + filterTypeid).remove();
        if (position == '2')
            chekfils2(clrType, -1);
        else
            chekfils(clrType, -1);
    }
    FilSearch('ClearAll', '', '', position);
}

function chekfils(filtype, val) {
    if (filtype == "TravelsName")
        opf = opf + val;
    else if (filtype == "Bustypes")
        btf = btf + val;
    else if (filtype == "BoardingPoint")
        bpf = bpf + val;
    else if (filtype == "DroppingPoint")
        dpf = dpf + val;
}

function chekfils2(filtype, val) {
    if (filtype == "TravelsNameR")
        opf2 = opf2 + val;
    else if (filtype == "BustypesR")
        btf2 = btf2 + val;
    else if (filtype == "BoardingPointR")
        bpf2 = bpf2 + val;
    else if (filtype == "DroppingPointR")
        dpf2 = dpf2 + val;
}

function FilSearch(thisname, val, Checked, position) {
	var rSet = '.rSet';
    if (position === undefined || position == 1) var position = '';
	
	if(position == 2){ 
		rSet = rSet + "Return";
	} else {
		rSet = rSet + "Forward";
	}
	FILTER_TYPE = rSet;
    if (thisname != 'ClearAll') {
        if (Checked.substring(0, 4) == "CHKD") {
            if (position == '2')
                $("#ACTIVEFILTERS2").append('<span id="ActFil2' + Checked.substring(4) + val + '" class="' + Checked.substring(4) + 'Active" onclick="delFil(\'' + val + '\',\'' + Checked.substring(4) + '\',\'' + position + '\');" style="padding-right:10px; cursor: pointer; color:#000; padding:2px 5px;">' + thisname + '<span style="color:#FF0000;padding-left:3px;">x</span></span>&nbsp;');
            else
                $("#ACTIVEFILTERS").append('<span id="ActFil' + Checked.substring(4) + val + '" class="' + Checked.substring(4) + 'Active" onclick="delFil(\'' + val + '\',\'' + Checked.substring(4) + '\',\'' + position + '\');" style="padding-right:10px; cursor: pointer; color:#000; padding:2px 5px;">' + thisname + '<span style="color:#FF0000;padding-left:3px;">x</span></span>&nbsp;');
            if (position == '2')
                chekfils2(Checked.substring(4), 1);
            else
                chekfils(Checked.substring(4), 1);
        } else {
            if (position == '2') {
                if ($("#ActFil2" + Checked + val))
                    $("#ActFil2" + Checked + val).remove();
            } else {
                if ($("#ActFil" + Checked + val))
                    $("#ActFil" + Checked + val).remove();
            }
            if (position == '2')
                chekfils2(Checked, -1);
            else
                chekfils(Checked, -1);
        }
    }
    $("#seatSelect" + position).hide();
    var bustp_filter = "";
    var travNm_filter = "";
    var brdpnts_filter = "";
    var drppnts_filter = "";
    $(".FilSearch").each(function() {
        tempval = '';
        if (position == '2') {
            if ($(this).attr("title") == "BustypesR") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '') {
                    bustp_filter = bustp_filter + tempval + ",";
                }
            }
            if ($(this).attr("title") == "TravelsNameR") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    travNm_filter = travNm_filter + tempval + ",";
            }
            if ($(this).attr("title") == "BoardingPointR") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    brdpnts_filter = brdpnts_filter + tempval + ",";
            }
            if ($(this).attr("title") == "DroppingPointR") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    drppnts_filter = drppnts_filter + tempval + ",";
            }
        } else {
            if ($(this).attr("title") == "Bustypes") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '') {
                    bustp_filter = bustp_filter + tempval + ",";
                }
            }
            if ($(this).attr("title") == "TravelsName") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    travNm_filter = travNm_filter + tempval + ",";
            }
            if ($(this).attr("title") == "BoardingPoint") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    brdpnts_filter = brdpnts_filter + tempval + ",";
            }
            if ($(this).attr("title") == "DroppingPoint") {
                tempval = (this.checked ? $(this).val() : "");
                if (tempval != '')
                    drppnts_filter = drppnts_filter + tempval + ",";
            }
        }
    });
    bustp_filter = bustp_filter.substring(0, bustp_filter.length - 1);
    travNm_filter = travNm_filter.substring(0, travNm_filter.length - 1);
    brdpnts_filter = brdpnts_filter.substring(0, brdpnts_filter.length - 1);
    drppnts_filter = drppnts_filter.substring(0, drppnts_filter.length - 1);
	
    $(rSet).each(function(i, service) {
        var bps = $(service).attr('brdp');
        var dps = $(service).attr('drpp');
        var bt = $(service).attr('bt');
        var travNm = $(service).attr('tn');
        var totalServiceListlayout = $(rSet);
        var stcount = $(service).attr('stcount');
        var updatecount = i;
        if(updatecount ===0) {
			serviceDeduction = 0;
			serviceToAdd = 0;
			seatDeduction = 0;
			seatToAdd = 0;
		}
        var show1 = true;
        var show2 = true;
        var show3 = true;
        var show4 = true;
        if (bustp_filter != "") {
            var bty_filters = bustp_filter.split(",");
            var a = $.inArray(bt, bty_filters);
            if (a >= 0) {} else
                show1 = false;
        }
        if (travNm_filter != "") {
            var tnm_filters = travNm_filter.split(",");
            var a = $.inArray(travNm, tnm_filters);
            if (a >= 0) {} else
                show2 = false;
        }
        if (brdpnts_filter != "") {
            var bpoints_chek = bps.split(",");
            var a = 0;
            var brdpnts_filters = brdpnts_filter.split(",");
            for (var i = 0; i < brdpnts_filters.length; i++) {
                a = -1;
                a = $.inArray(brdpnts_filters[i], bpoints_chek);
                if (a >= 0)
                    break;
            }
            if (a >= 0) {} 
            else show3 = false;
        }
        if (drppnts_filter != "") {
            var dpoints_chek = dps.split(",");
            var b;
            var drppnts_filters = drppnts_filter.split(",");
            for (var i = 0; i < drppnts_filters.length; i++) {
                b = -1;
                b = $.inArray(drppnts_filters[i], dpoints_chek);
                if (b >= 0)
                    break;
            }
            if (b >= 0) {} else
                show4 = false;
        }
        if (show1 && show2 && show3 && show4) {
        	if(this.style.display === "none") {
				seatToAdd = seatToAdd+Number(this.attributes[3].value);
				serviceToAdd = serviceToAdd+1;
			}
			$(this).show();
        }
        else {
        	if(this.style.display != "none") {
				seatDeduction = seatDeduction+Number(this.attributes[3].value);
				serviceDeduction = serviceDeduction+1;
			}
			$(this).hide();
        }
        if(updatecount == (totalServiceListlayout.length - 1)) {
        	if(FILTER_TYPE ===".rSetForward") {
        		updateServicesAndSeatsCountFrwd(serviceToAdd, serviceDeduction,seatDeduction,seatToAdd);
        	} else {
        		updateServicesAndSeatsCountRetn(serviceToAdd, serviceDeduction,seatDeduction,seatToAdd);
        	}
		}
    });
    
    function updateServicesAndSeatsCountFrwd(serviceToAdd,serviceDeduction,seatDeduction,seatToAdd) {
		var totalAvailableService = document.getElementById('fwTotalServicesId').innerHTML;
		var totalSeatAvailable = document.getElementById('fwTotalSeatsId').innerHTML;
		totalAvailableService = Number(totalAvailableService)+serviceToAdd;
		totalAvailableService = Number(totalAvailableService)-serviceDeduction;
		totalSeatAvailable = Number(totalSeatAvailable)+seatToAdd;
		totalSeatAvailable = Number(totalSeatAvailable)-seatDeduction;
		document.getElementById('fwTotalServicesId').innerHTML = String(totalAvailableService);
		document.getElementById('fwTotalSeatsId').innerHTML = String(totalSeatAvailable);

	}
    
    function updateServicesAndSeatsCountRetn(serviceToAdd,serviceDeduction,seatDeduction,seatToAdd) {
		var totalAvailableService = document.getElementById('retTotalServicesId').innerHTML;
		var totalSeatAvailable = document.getElementById('retTotalSeatsId').innerHTML;
		totalAvailableService = Number(totalAvailableService)+serviceToAdd;
		totalAvailableService = Number(totalAvailableService)-serviceDeduction;
		totalSeatAvailable = Number(totalSeatAvailable)+seatToAdd;
		totalSeatAvailable = Number(totalSeatAvailable)-seatDeduction;
		document.getElementById('retTotalServicesId').innerHTML = String(totalAvailableService);
		document.getElementById('retTotalSeatsId').innerHTML = String(totalSeatAvailable);

	}
    if (position == "2") {
        if (opf2 > 0 || btf2 > 0 || bpf2 > 0 || dpf2 > 0)
            $("#ACTIVEFILTERS2").show();
        else
            $("#ACTIVEFILTERS2").hide();
        if (opf2 > 0) {
            $("#OpFid2").css("background-color", "#ffd672 ");
            $(".TravelsNameRActive").css("background-color", "#ffd672 ");
        } else
            $("#OpFid2").css("background-color", "#FFFFFF");
        if (btf2 > 0) {
            $("#BtFid2").css("background-color", "#89d283");
            $(".BustypesRActive").css("background-color", "#89d283");
        } else
            $("#BtFid2").css("background-color", "#FFFFFF");
        if (bpf2 > 0) {
            $("#BpFid2").css("background-color", "#fdd2ff");
            $(".BoardingPointRActive").css("background-color", "#fdd2ff");
        } else
            $("#BpFid2").css("background-color", "#FFFFFF");
        if (dpf2 > 0) {
            $("#DpFid2").css("background-color", "#ffd672");
            $(".DroppingPointRActive").css("background-color", "#ffd672");
        } else
            $("#DpFid2").css("background-color", "#FFFFFF");
    } else {
        if (opf > 0 || btf > 0 || bpf > 0 || dpf > 0) {
            if ($("#ACTIVEFILTERS"))
                $("#ACTIVEFILTERS").show();
        } else {
            if ($("#ACTIVEFILTERS"))
                $("#ACTIVEFILTERS").hide();
        }
        if (opf > 0) {
            $("#OpFid").css("background-color", "#ffd672 ");
            $(".TravelsNameActive").css("background-color", "#ffd672 ");
        } else
            $("#OpFid").css("background-color", "#FFFFFF");
        if (btf > 0) {
            $("#BtFid").css("background-color", "#89d283");
            $(".BustypesActive").css("background-color", "#89d283");
        } else
            $("#BtFid").css("background-color", "#FFFFFF");
        if (bpf > 0) {
            $("#BpFid").css("background-color", "#fdd2ff");
            $(".BoardingPointActive").css("background-color", "#fdd2ff");
        } else
            $("#BpFid").css("background-color", "#FFFFFF");
        if (dpf > 0) {
            $("#DpFid").css("background-color", "#ffd672");
            $(".DroppingPointActive").css("background-color", "#ffd672");
        } else
            $("#DpFid").css("background-color", "#FFFFFF");
    }
}

function enableSelectBoxes(position) {
	var srvListDiv;
    if (position == 2) srvListDiv = "#ReturnAvailableServicesDiv ";
    else srvListDiv = "#ForwardAvailableServicesDiv ";
    $(srvListDiv + 'div.selectBoxs' + position).each(function() {

        $(this).children('span.selected').html($(this).children('div.selectOptions').find('span.Clear').attr("value"));
        $(this).attr('value', $(this).children('div.selectOptions').children('label.selectOption:first').attr('value'));
        $(this).children('span.selected,span.selectArrow').click(function() {
            if ($(this).parent().children('div.selectOptions').css('display') == 'none') {
                $(srvListDiv + 'div.selectOptions').css('display', 'none');
                $('.p1').show();
                $('.p2').hide();
                $(this).parent().children('div.selectOptions').css('display', 'block');
                $(this).parent().find('.p1').hide();
                $(this).parent().find('.p2').show();
            } else {
                $(this).parent().children('div.selectOptions').css('display', 'none');
                $(this).parent().find('.p1').show();
                $(this).parent().find('.p2').hide();
            }
        });
    });
    $(srvListDiv + ".FilSearch").change(function() {
        if ($(this).prop("checked"))
            var Checked = 'CHKD' + $(this).attr("title");
        else
            var Checked = $(this).attr("title");
        if ($(this).attr("position")) var pos = $(this).attr("position");
        else var pos = '';

        FilSearch($(this).attr("name"), $(this).val(), Checked, pos)
    });
}

function enableSelectBoxesLink(position) {
	var srvListDiv;
    if (position == 2) srvListDiv = "#ForwardEndAvailableServicesDiv ";
    else srvListDiv = "#ForwardAvailableServicesDiv ";
    $(srvListDiv + 'div.selectBoxs' + position).each(function() {

        $(this).children('span.selected').html($(this).children('div.selectOptions').find('span.Clear').attr("value"));
        $(this).attr('value', $(this).children('div.selectOptions').children('label.selectOption:first').attr('value'));
        $(this).children('span.selected,span.selectArrow').click(function() {
            if ($(this).parent().children('div.selectOptions').css('display') == 'none') {
                $(srvListDiv + 'div.selectOptions').css('display', 'none');
                $('.p1').show();
                $('.p2').hide();
                $(this).parent().children('div.selectOptions').css('display', 'block');
                $(this).parent().find('.p1').hide();
                $(this).parent().find('.p2').show();
            } else {
                $(this).parent().children('div.selectOptions').css('display', 'none');
                $(this).parent().find('.p1').show();
                $(this).parent().find('.p2').hide();
            }
        });
    });
    $(srvListDiv + ".FilSearch").change(function() {
        if ($(this).prop("checked"))
            var Checked = 'CHKD' + $(this).attr("title");
        else
            var Checked = $(this).attr("title");
        if ($(this).attr("position")) var pos = $(this).attr("position");
        else var pos = '';

        FilSearch($(this).attr("name"), $(this).val(), Checked, pos)
    });
}
function closeModifySearch(divId, fwDate, retDate) {
	hidediv(divId);
	var ob = document.getElementById("txtJourneyDate");
	if(ob != null && validateDate(fwDate)) {
		ob.value = fwDate;
		showdiv('ForwardAvailableServicesDiv');
		showdiv('fwInfoLeftId');
	}
	
	var ob = document.getElementById("txtReturnJourneyDate");
	if(ob != null && validateDate(retDate)) {
		ob.value = retDate;
		showdiv('ReturnAvailableServicesDiv');
		showdiv('retInfoLeftId');
	}
	
	var uc = 'unSelectedDivCs';
	addRemoveCss('fwInfoLeftId', uc, false);
	addRemoveCss('retInfoLeftId', uc, true);
}

function setSelectedColor() {
	if(document.getElementById("ebs") != null){
		document.getElementById("ebs").className = "pgw-ebs";
	}	
	if(document.getElementById("hdfc") != null){
		document.getElementById("hdfc").className = "pgw-hdfc";
	}
	if(document.getElementById("PhenePe") != null){
		document.getElementById("PhenePe").className = "pgw-ebs";
	}
	if(document.getElementById("amazonPay") != null){
		document.getElementById("amazonPay").className = "pgw-amazon";
	}
	if(document.getElementById("Gpay") != null){
		document.getElementById("Gpay").className = "pgw-ebs";
	}
	if(document.getElementById("apsrtcWallet") != null){
		document.getElementById("apsrtcWallet").className = "pgw-ebs";
	}
	if(document.getElementById("upitp") != null){
		document.getElementById("upitp").className = "pgw-upi-tp";
	}
	if(document.getElementById("sbi") != null){
		document.getElementById("sbi").className = "pgw-sbi";
	}
	if(document.getElementById("idfc") != null){
		document.getElementById("idfc").className = "pgw-idfc";
	}
	if(document.getElementById("idfc_upi") != null){
		document.getElementById("idfc_upi").className = "pgw-idfc-upi";
	}
	var cs = 'pgw-selected';
	var v = document.getElementById("pgId").value;
	if(v == '4') {
		document.getElementById("hdfc").className = cs;
	} else if(v == '1') {
		document.getElementById("ebs").className = cs;
	} else if(v == '6') {
		document.getElementById("PhenePe").className = cs;
	} else if(v == '7') {
		document.getElementById("amazonPay").className = cs;
	} else if(v == '8') {
		document.getElementById("Gpay").className = cs;
	} else if(v == '100') {
		document.getElementById("apsrtcWallet").className = cs;
	}else if(v == '12') {
		document.getElementById("upitp").className = cs;
	}else if(v == '51') {
		document.getElementById("sbi").className = cs;
	}else if(v == '53'){
		document.getElementById("idfc").className = cs;		
	}else if(v == '54'){
		document.getElementById("idfc_upi").className = cs;		
	}
	if(v == '8'){
		var modal = document.getElementById("GpayMobileNoPopUp");
		if (modal.style.display == "none") {
			modal.style.display = "block";
		}
	}
}
function setSelectedPg(v) {
	document.getElementById("pgId").value = v;
	setSelectedColor();
}

function continueReturnBkg() {
	if(!validateSubmitBookingLayout()) {
		return false;
	}
	var acttype = "Forward";
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
		acttype = "Return";
	}
 	if(document.getElementById('srisailamAccommodationId') != null && document.getElementById('srisailamAccommodationId').value != ''){
		if(($('#srisailamAccommodationId').length == 0  || ($('#srisailamAccommodationId').length > 0 
	 			&& document.getElementById('srisailamAccommodationId').value == ''))
	 			|| (($('#SrslmAccomadationDiv').css('display') != 'none') 
	 					&& ($('#idProofPopUp'+acttype).css('display') == 'block'))){
	
			alert("Now, please select the return journey service.");
			
			hidediv('ForwardAvailableServicesDiv');
			showdiv('ReturnAvailableServicesDiv');
			
			var uc = 'unSelectedDivCs';
			addRemoveCss('fwInfoLeftId', uc, true);
			addRemoveCss('retInfoLeftId', uc, false);
			accomPrice=0;// For return set this one to zero value.
	 	}else if(document.getElementById('paxProofId') != null){
	 		if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
 	 	 		getIdProofPopUp("idProofPopUpReturn");
 	 		}else{
 	 			getIdProofPopUp("idProofPopUpForward");
 	 		}
	 	}else{
	 		alert("Now, please select the return journey service.");
	 		
	 		hidediv('ForwardAvailableServicesDiv');
	 		showdiv('ReturnAvailableServicesDiv');
	 		
	 		var uc = 'unSelectedDivCs';
	 		addRemoveCss('fwInfoLeftId', uc, true);
	 		addRemoveCss('retInfoLeftId', uc, false);
	 		accomPrice=0;// For return set this one to zero value.	
	 	}
 	}else{
 	if(($('#ttdAccommodationId').length == 0  || ($('#ttdAccommodationId').length > 0 
 			&& document.getElementById('ttdAccommodationId').value == ''))
 			|| (($('#TtdAccomadationDiv').css('display') != 'none') 
 					&& ($('#idProofPopUp'+acttype).css('display') == 'block'))){

		alert("Now, please select the return journey service.");
		
		hidediv('ForwardAvailableServicesDiv');
		showdiv('ReturnAvailableServicesDiv');
		
		var uc = 'unSelectedDivCs';
		addRemoveCss('fwInfoLeftId', uc, true);
		addRemoveCss('retInfoLeftId', uc, false);
		accomPrice=0;// For return set this one to zero value.
 	}else if(document.getElementById('paxProofId') != null){
 		if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
	 	 		getIdProofPopUp("idProofPopUpReturn");
	 		}else{
	 			getIdProofPopUp("idProofPopUpForward");
	 		}
 	}else{
 		alert("Now, please select the return journey service.");
 		
 		hidediv('ForwardAvailableServicesDiv');
 		showdiv('ReturnAvailableServicesDiv');
 		
 		var uc = 'unSelectedDivCs';
 		addRemoveCss('fwInfoLeftId', uc, true);
 		addRemoveCss('retInfoLeftId', uc, false);
 		accomPrice=0;// For return set this one to zero value.	
 	}
 	}
}



function addRemoveCss(divId, cssName, adOrR) {
	$( "#" + divId ).toggleClass( cssName, adOrR );
}

function validateMyTicket(formObj, fmId) {
	var v = document.getElementById("id").value;
	if(v == null || v == '' || v == '0') {
		alert("Please enter valid ticket number to continue.");
		return false;
	}
	
	if(!validateMobileNo(document.getElementById("mobileNo"))) {
		return false;
	}
	submitFormAction(formObj.action, fmId);
}

function copyPrimaryPaxName() {
	var ob = document.getElementById("bookedByName");
	if(!validateAlphabet(ob, "Primary Passenger Name")) {
		return false;
	}
	if(document.getElementById(("passengerNameForward0")) != null) {
		document.getElementById(("passengerNameForward0")).value = ob.value;
	}
}
/** DOM PRINTER END * */

function calculateTotalFare(requestType) {
	
	var acc = 0, dinner=0, totConc = 0, concCount = 0, retConc=0;
	
	var toll = parseFloat(document.getElementById(requestType + "TollsPrice").value);
	var srt = parseFloat(document.getElementById(requestType + "SrtFee").value);
	var bTxn = parseFloat(document.getElementById(requestType + "BnkTxnAmt").value);
	
	var totalPax = parseFloat(document.getElementById(requestType +"SeatTotalPax").value);
	srt = srt * totalPax;
	toll = toll * totalPax;
	
	var basic = parseFloat(document.getElementById(requestType + "SeatBasicFare").value);
	var levies = parseFloat(document.getElementById(requestType + "SeatLevy").value);
	var totConc = parseFloat(document.getElementById(requestType + "SeatConc").value);
	var origBasicFare = parseFloat(document.getElementById(requestType + "SeatOrgBasicFare").value);
	
	if(document.getElementById('mTotPrice'+requestType) != null)
		dinner = parseFloat(document.getElementById('mTotPrice'+requestType).value);
	
	var totFare = (basic + srt  + toll + levies + acc + dinner) ;
	
	if(document.getElementById('totalTtdAccAmount') != null){
		var ttdAccAmount = document.getElementById('totalTtdAccAmount').value;
		totFare = parseFloat(parseFloat(totFare) + parseFloat(ttdAccAmount));
		acc = acc + parseFloat(ttdAccAmount);
	}
	
	if(document.getElementById('totalLinkAccAmt') != null){
		var totalLinkAccAmt = document.getElementById('totalLinkAccAmt').value;
		totFare = parseFloat(parseFloat(totFare) + parseFloat(totalLinkAccAmt));
		acc = acc + parseFloat(totalLinkAccAmt);
	}
	
	if(document.getElementById('totalSrisailamAccAmount') != null){
		var srslmAccAmount = document.getElementById('totalSrisailamAccAmount').value;
		totFare = parseFloat(parseFloat(totFare) + parseFloat(srslmAccAmount));
		acc = acc + parseFloat(srslmAccAmount);
	}
	
	bTxn = Math.ceil((totFare * bTxn ) / 100);
	totFare = totFare + bTxn;
	
	document.getElementById(requestType + "BasicFare").innerHTML = basic;
	document.getElementById(requestType+ "OrigBasicFare").innerHTML = origBasicFare;
	document.getElementById(requestType + "SRT").innerHTML = srt;
	document.getElementById(requestType + "Toll").innerHTML = toll;
	document.getElementById(requestType + "Levies").innerHTML = levies;
	if(document.getElementById(requestType + "Accomdation") != null) {
		document.getElementById(requestType + "Accomdation").innerHTML = acc;
	}
	if(document.getElementById(requestType + "Dinner") != null) {
		document.getElementById(requestType + "Dinner").innerHTML = dinner;
	}
	
	if(document.getElementById(requestType + "Concession") != null) {
		document.getElementById(requestType + "Concession").innerHTML = totConc;
	}
	document.getElementById(requestType + "BankTransact").innerHTML = bTxn;
	
	document.getElementById(requestType+'totFare').innerHTML = totFare;
	
}

function calculateDinner(requestType,size) {	
	amt = 0;
	for(var i = 0; i < size; i++) { 
		if(document.getElementById('mQty'+requestType+i).value != ''){
			amt = amt + parseFloat(document.getElementById('mPrice'+requestType+i).value*
					document.getElementById('mQty'+requestType+i).value);
		}
	}
	document.getElementById('mTotPrice'+requestType).value = amt;
	calculateTotalFare(requestType);
}

function swapValues() {
	var temp = document.getElementById("fromPlaceName").value;
	var tempStartPlcId = document.getElementById("startPlaceId").value;
	var tempStartPlcCode = document.getElementById("startPlaceId").value;
	
	if(document.getElementById("toPlaceName").value != 'To'){
		document.getElementById("fromPlaceName").value = document.getElementById("toPlaceName").value ;
		document.getElementById("startPlaceId").value = document.getElementById("endPlaceId").value ;
		document.getElementById("fromPlaceCode").value = document.getElementById("toPlaceCode").value ;
	} else{
		document.getElementById("fromPlaceName").value = 'From';
		document.getElementById("startPlaceId").value = '' ;
		document.getElementById("fromPlaceCode").value = '' ;
	}
	if(temp != 'From'){
		document.getElementById("toPlaceName").value = temp;
		document.getElementById("endPlaceId").value = tempStartPlcId;
		document.getElementById("toPlaceCode").value = tempStartPlcCode;
	} else{
		document.getElementById("toPlaceName").value = 'To';
	}
}

function getWalletCash(divName){
	var walletObj;
	walletObj = document.getElementById("addWalletAmount");
	var amount;
	if(walletObj != null){
		amount = walletObj.value;
		walletObj.readOnly = true;
	} else{
		walletObj.readOnly = false;
	}
	var path =  "/wallet/addPaymentList.do?addWalletAmount=" + amount;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function getWalletCashForCopax(divName){
	var walletObj;
	walletObj = document.getElementById("addWalletAmount");
	var amount;
	if(walletObj != null){
		amount = walletObj.value;
		walletObj.readOnly = true;
	} else{
		walletObj.readOnly = false;
	}
	var path =  "/wallet/addPaymentListforCopax.do?addWalletAmount=" + amount;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function pgWalletSubmitAction(path, formObj) {
	var pgObj;
	var pgchk = false;
	for(var i=1; i<=3; i++) {
		pgObj = document.getElementById(("pgId"+i));
		if(pgObj == null) {
			break;
		} else if(pgObj.checked == true) {
			pgchk = true;
			break;
		}
	}
	if(pgchk) {
		alert("Please select payment gateway to continue.");
		return false;
	}
	if(document.getElementById("termsChk").checked == false) {
		alert("Please accept terms and conditions.");
		return false;
	}
	path = path +"?addWalletAmount=" + document.getElementById("addWalletAmount").value;
	
	formObj.action = path;
	formObj.submit();
}

function pgWalletSubmitActionCopax(path, formObj) {
	var pgObj;
	var pgchk = false;
	for(var i=1; i<=3; i++) {
		pgObj = document.getElementById(("pgId"+i));
		if(pgObj == null) {
			break;
		} else if(pgObj.checked == true) {
			pgchk = true;
			break;
		}
	}
	if(pgchk) {
		alert("Please select payment gateway to continue.");
		return false;
	}
	if(document.getElementById("termsChk").checked == false) {
		alert("Please accept terms and conditions.");
		return false;
	}
	path = path +"?toupCopax=1" +
			"&addWalletAmount=" + document.getElementById("addWalletAmount").value+"" +
			"&mobileNo=" + document.getElementById("mobileNo").value
			;
	
	formObj.action = path;
	formObj.submit();
}

function cancelCouponUsage(divName){
	var couponUsageIdObj;
	var cashbackCoupon;
	couponUsageObj = document.getElementById("couponUsageId");
	if(couponUsageObj != null){
		couponUsageId = couponUsageObj.value;
	}
	var path =  "/ajax/wallet/couponUsage/cancel.do?couponUsageId=" + couponUsageId;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function cancelCouponUsageHire(divName){
	var couponUsageIdObj;
	var cashbackCoupon;
	couponUsageObj = document.getElementById("couponUsageId");
	if(couponUsageObj != null){
		couponUsageId = couponUsageObj.value;
	}
	var path =  "/ajax/hire/wallet/couponUsage/cancel.do?couponUsageId=" + couponUsageId;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function isValidNumber(txtObj) {
	var val = txtObj.value;
	if(txtObj.value == "0.00") {
		return false;
	}
	if(validNumber(val)) {
		return true;
	} else {
		txtObj.value = "0";
		txtObj.focus();
		alert("Please enter valid number.");
		return false;
	}
}


function showWalletDetails(walletAmt){
	var id = 0, concPlusId = 0, bookingId = 0, concPlusRtId = 0;
	var returnBookingAmount = parseFloat(0);
	if(document.getElementById('retTotalAmountHid') != null){
		returnBookingAmount = parseFloat(document.getElementById('retTotalAmountHid').value);
	}
	var totalAmt = document.getElementById('totalAmountHid').value;
	if(document.getElementById('walletChk') !=null
			&& document.getElementById('walletChk').checked == true){
		if(parseFloat(walletAmt) >= (parseFloat(totalAmt) + returnBookingAmount) ){
			showdiv("ShowWalletSave");
			hidediv("pggwid");
		} else {
			showdiv("ShowWalletSave");
			showdiv('pggwid');
		}
		
	} else {
		hidediv("ShowWalletSave");
		showdiv("pggwid");
	}
}

function openTrackBus(buttonObj) {
		 var srvcCode = "", txtJourneyDate="",url = "";
		 var ob = document.getElementById("serviceCode");
			formObj = ob.form;
		    if(document.getElementById('serviceCode') != null && document.getElementById('serviceCode').value != '') {
			srvcCode = document.getElementById('serviceCode').value;
		    } 
		    if(document.getElementById('txtJourneyDate') != null && document.getElementById('txtJourneyDate').value != '') {
			txtJourneyDate = document.getElementById('txtJourneyDate').value;
		    } 
		    var contextPath = document.getElementById("contextPath").value;
			var path = contextPath + '/services/cancelList.do';
			formObj.action = path;
			formObj.submit();
			
	
}
function dynamicUrl(path) {
    var url="",txtJourneyDate="",srvcCode="";
    if(document.getElementById('txtJourneyDate') != null && document.getElementById('txtJourneyDate').value != '') {
	    txtJourneyDate = document.getElementById('txtJourneyDate').value;
	} else{
	    alert("Please select JourneyDate");
	    document.getElementById("txtJourneyDate").focus();
	    return false;
	}
	if(document.getElementById('serviceCode') != null && document.getElementById('serviceCode').value != '') {
		srvcCode = document.getElementById('serviceCode').value;
	} else {
		alert("Please select service No");
	    document.getElementById("serviceCode").focus();
	    return false;
	}
    path = path + "?serviceCode=" + srvcCode + "&TxtJourneyDate=" + txtJourneyDate
	popUpWin(path, '_trackBus');
	
}
function disableResend(button, disableTime) {
	var oldValue = button.value;
	//convert to milliseconds
	disableTime = parseFloat(disableTime) * 1000;
	button.setAttribute('disabled', true);
	button.className='resendBtn';
    setTimeout(function(){
        button.value = oldValue;
        button.removeAttribute('disabled');        
        button.className='resendBtnEn';
    }, disableTime)
}
function lockoutSubmit(button, disableTime) {
    disableResend(button, disableTime);
    var path =  "/wallet/walletLoginOTP.do?otpType=3";
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function calendarMnYrDate(id) {
	$('#'+id).datepicker({ numberOfMonths: 1
		, dateFormat: 'dd/mm/yy'
		, minDate: '0'
		, changeMonth: true
		, changeYear: true
		, yearRange: '2010:2030'}).val();
}

function continueLinkReturnBkg() {
	if(!validateSubmitBookingLayout()) {
		return false;
	}
	if(($('#ttdAccommodationId').length == 0  || ($('#ttdAccommodationId').length > 0 
 			&& document.getElementById('ttdAccommodationId').value == ''))
 			|| (($('#TtdAccomadationDiv').css('display') != 'none') 
 					&& ($('#idProofPopUp').css('display') == 'block'))){

		alert("Now, please select the return journey service.");
		
		hidediv('ForwardLinkServiceDiv');
		showdiv('ReturnLinkServiceDiv');
		
		var uc = 'unSelectedDivCs';
		addRemoveCss('fwInfoLeftId', uc, true);
		addRemoveCss('retInfoLeftId', uc, false);
		accomPrice=0;// For return set this one to zero value.
 	}else if(document.getElementById('paxProofId') != null){
 		if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
	 	 		getIdProofPopUp("idProofPopUpReturn");
	 		}else{
	 			getIdProofPopUp("idProofPopUpForward");
	 		}
 	}else{
 		alert("Now, please select the return journey service.");
 		
 		hidediv('ForwardLinkServiceDiv');
 		showdiv('ReturnLinkServiceDiv');
 		
 		var uc = 'unSelectedDivCs';
 		addRemoveCss('fwInfoLeftId', uc, true);
 		addRemoveCss('retInfoLeftId', uc, false);
 		accomPrice=0;// For return set this one to zero value.
 	}
	
}

function setTextRewardPoints(value){
	if(document.getElementById("eligibleRewardPointsHid") != null)
		document.getElementById("eligibleRewardPointsHid").value = value;
}
function checkRedeemRewardEnable(){
	if(document.getElementById("OTPSuccessDiv") != null && document.getElementById("OTPSuccessDiv").style.display != 'none'){
		var otp = document.getElementById("otpCode");
		if(otp == null || otp.value == ""){
			alert("Please Enter OTP that you received on the Mobile Number provided then click on Submit to continue");
			return false;
		}
	}
	if(document.getElementById("redeemCheck") != null && document.getElementById("redeemCheck").checked == false
			&& document.getElementById("redeemRewardPoints") != null){
		document.getElementById("redeemRewardPoints").value = 0;
	}
	return true;
}

function validateTTDDarsanPassengers(requestType){
	var aPax = 0, cPax = 0, totPax = 0, remainingCapacity = 0;
	var max = parseInt(document.getElementById("maxAgeCh").value);
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			
			if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax;
	if(document.getElementById("remainingCapacity") != null)
		remainingCapacity = parseInt(document.getElementById("remainingCapacity").value);
	if(document.getElementById("totalTtdAccAmount") != null && totPax > remainingCapacity){
		alert("selected seats more than ttd capacity, please select other date");
		return false;
	}
	return true;
}

function rewardDisableResend(button, disableTime) {
	var oldValue = button.value;
	//convert to milliseconds
	disableTime = parseFloat(disableTime) * 1000;
	button.setAttribute('disabled', true);
	button.className='resendBtn';
    setTimeout(function(){
        button.value = oldValue;
        button.removeAttribute('disabled');        
        button.className='resendBtnEn';
    }, disableTime)
}

function trackTransandItem(bankRefNo, revenue, name, affiliation, tax, category, sku, quantity) {
	ga('require', 'ecommerce');
	
	var transaction = {
	          'id': bankRefNo,  // Transaction ID.
	          'affiliation': affiliation,  // Affiliation or store name.
	          'revenue': revenue,		// Grand Total.
	          'tax': tax              
	        };
	
	var additems ={
			'id': bankRefNo, 
			'name': name,
			'category': category,
			'sku': sku,  
			'price': revenue/quantity,
			'quantity': quantity   //Quantity 
		};
	
	ga('ecommerce:addTransaction', transaction);
	ga('ecommerce:addItem', additems);
	ga('ecommerce:send');

}

/*
 *  New function related to single lady 
 */

function getSingleLady() {
	try{
		var slady = "";
		var sob = document.getElementById("singleLady");
		if(sob != null && sob.value != '' && sob.checked == true) {
			sob.value = "1";
			slady = sob.value;
			if(document.getElementById("adultMale") != null) 
				document.getElementById("adultMale").value = 0;
			if(document.getElementById("adultFemale") != null)
				document.getElementById("adultFemale").value = o.value;
			if(document.getElementById("childMale") != null)
				document.getElementById("childMale").value = 0;
			if(document.getElementById("childFemale") != null)
				document.getElementById("childFemale").value = 0;
		} else if(sob != null) {
			sob.value = "0";
			slady = sob.value;
		}
		if(sob == null){
			slady = "0";
		}
	}catch(e){
	}
	
	
	return slady;
}

function isGeneralLadyBooking(requestType, tdId, seatIndx, currentIdx, seatType, tblId) {
	try{
		var isSingleLadyEnabled = document.getElementById("singleLadyEnabled"+ requestType);
		if(isSingleLadyEnabled.value == "false"){
			return false;
		}
		
		if(seatType != null && seatType != '' && seatType == 'B') {
			return false;
		}
		var isSingleLadyAllowedForThisBus = document.getElementById("singleLadyEnabledForBus"+ requestType);
		if(isSingleLadyAllowedForThisBus.value == "false"){
			return false;
		}
		
		if(document.getElementById(("genderCodeId" + requestType + currentIdx)).value == MALE_ID){
			return false;
		}
		
		if(document.getElementById(("genderCodeId" + requestType + currentIdx)).value == FEMALE_ID){
			showActionMsg(tdId,seatType,requestType,currentIdx, tblId,seatIndx);
		}
	}catch(e){
		
	}
	return false;
}


function showActionMsg(tdId,seatType,requestType,indx, tblId, seatIndx){
	try{
		document.getElementById((requestType + seatIndx)).className = "selectedSeatClass" + seatType;
		var tmsg =  "You are trying to book a seat as General Lady. " +
		            "There may be a possibility that male can also book seat beside you. " +
		            "Please choose OK (or) Continue to proceed further or else book the ticket using Single Lady option.";
		var b = confirm(tmsg);
		// if not confirmed then do not allow the user to continue the seat selection.
		if(!b) {
			document.getElementById((requestType + seatIndx)).className = "availSeatClass" + seatType;
			document.getElementById(("seatDetails" + requestType + indx)).value = "";
			document.getElementById(("genderCodeId" + requestType + indx)).value = "";
			document.getElementById(("passengerName" + requestType + indx)).value = "";
			document.getElementById(("passengerAge" + requestType + indx)).value = "";
			removePaxRow(requestType, indx, tblId);
			return false;
		}
		var fvs = document.getElementById("femaleSeatSpanId" + requestType);
		if(fvs != null) {
			fvs.innerHTML = tmsg;
			fvs.className = "errormsg";
		}
	}catch(e){
		
	}
}

function dispCalendar(id,minDtae,maxDate) {
	$('#'+id).datepicker({ numberOfMonths: 1
		, dateFormat: 'dd/mm/yy'
		, minDate: toDate(minDtae,"dd/mm/yyyy", "/")
		, maxDate: toDate(maxDate,"dd/mm/yyyy", "/")
		}).val();
}

function toDate(date,format, delimiter) {
    var formatedDate = null;
    var formatLowerCase = format.toLowerCase();
    var formatItems = formatLowerCase.split(delimiter);
    var dateItems = date.split(delimiter);
    var monthIndex = formatItems.indexOf("mm");
    var monthNameIndex = formatItems.indexOf("mmm");
    var dayIndex = formatItems.indexOf("dd");
    var yearIndex = formatItems.indexOf("yyyy");
    var d = dateItems[dayIndex];
    if (d < 10) {
    	d = "0"+ d;
    }
    if (monthIndex > -1) {
        var month = parseInt(dateItems[monthIndex]);
        month -= 1;
        if (month < 10) {
            month = "0" + month;
        }
        formatedDate = new Date(dateItems[yearIndex], month, d);
    } else if (monthNameIndex > -1) {
        var monthName = dateItems[monthNameIndex];
        month = getMonthIndex(monthName);
        if (month < 10) {
            month = "0" + month;
        }
        formatedDate = new Date(dateItems[yearIndex], month, d);
    }
    return formatedDate;
}



function pop(div) {
	if(document.getElementById(div)){
		document.getElementById(div).style.display = 'block';
	}else{
		if(window.opener){
			console.log("child window opened");
		}
		window.opener.document.getElementById(div).style.display = 'block';
	}
}
function hide(div) {
	if(document.getElementById(div) != null){
		document.getElementById(div).style.display = 'none';
	}
	enableScroll();
}

// left: 37, up: 38, right: 39, down: 40,
// spacebar: 32, pageup: 33, pagedown: 34, end: 35, home: 36
var keys = {
	37 : 1,
	38 : 1,
	39 : 1,
	40 : 1
};

function preventDefault(e) {
	e = e || window.event;
	if (e.preventDefault)
		e.preventDefault();
	e.returnValue = false;
}

function preventDefaultForScrollKeys(e) {
	if (keys[e.keyCode]) {
		preventDefault(e);
		return false;
	}
}

function disableScroll() {
	if (window.addEventListener) // older FF
		window.addEventListener('DOMMouseScroll', preventDefault, false);
	window.onwheel = preventDefault; // modern standard
	window.onmousewheel = document.onmousewheel = preventDefault; // older
																	// browsers,
																	// IE
	window.ontouchmove = preventDefault; // mobile
	document.onkeydown = preventDefaultForScrollKeys;
}

function enableScroll() {
	if (window.removeEventListener)
		window.removeEventListener('DOMMouseScroll', preventDefault, false);
	window.onmousewheel = document.onmousewheel = null;
	window.onwheel = null;
	window.ontouchmove = null;
	document.onkeydown = null;
}


function loadMap(latitude, longitude, hopName, hopType, hopTime,  hopDuration, actionType){
	if(actionType == "fw"){
		if(document.getElementById("mapDiv") && document.getElementById("mapDiv").style.display == "none"){
			document.getElementById("mapDiv").style.display = "";
		}
	}else{
		if(document.getElementById("mapDivReturn") && document.getElementById("mapDivReturn").style.display == "none"){
			document.getElementById("mapDivReturn").style.display = "";
		}
	}
	initMap(latitude,longitude,hopName,hopType, hopTime,  hopDuration, actionType);
}

function initMap(latitude,longitude,hopName,hopType, hopTime,  hopDuration, actionType) {
	  var myCenter = new google.maps.LatLng(latitude,longitude);
	  if(actionType == "fw"){
		  var mapCanvas = document.getElementById("map");
	  }else{
		  var mapCanvas = document.getElementById("mapReturn");
	  }
	  var mapOptions = { mapTypeControl: false, center: myCenter, zoom: 16, mapTypeId:google.maps.MapTypeId.ROADMAP,
			  styles:[
			          {
			              featureType: "all",
			              elementType: "labels",
			              stylers: [
			                  { visibility: "on" }
			              ]
			          }
			      ]
	  };
	  var map = new google.maps.Map(mapCanvas, mapOptions);
	  var marker = new google.maps.Marker({position:myCenter, map:map, title:hopName
		  });
	  marker.setMap(map);
      
      var infowindow = new google.maps.InfoWindow({
         content: hopName + " - " + hopTime + "<br/>"
         		  + "Duration " + hopDuration +" mins"	
      });
			
      infowindow.open(map,marker);
}

function loadHops(latitude, longitude, hopName, hopType, hopTime,  hopDuration, mapUrl, mapKey, actionType){
	
	if (! window.scriptLoaded) {
		   var script = document.createElement('script');
		   script.src = mapUrl+"?key="+mapKey;
		   document.getElementsByTagName('head')[0].appendChild(script);
		   window.scriptLoaded = true;
	}
	
	setTimeout(function(){
		loadMap(latitude, longitude, hopName, hopType, hopTime,  hopDuration, actionType);
	}, 500);
}

function getIdProofPopUp(popId) {
	var modal = document.getElementById(popId);
	if (modal.style.display == "none") {
		modal.style.display = "block";
	}
	document.getElementsByClassName("popClose")[0].onclick = function() {
		$("[name=paxIdProof]").remove();
		modal.style.display = "none";
		
	}
	if(document.getElementsByClassName("popClose")[2] != null){
		document.getElementsByClassName("popClose")[2].onclick = function() {
			$("[name=paxIdProof]").remove();
			modal.style.display = "none";
		}
	}
	window.onclick = function(event) {
		if (event.target == modal) {
			 $("[name=paxIdProof]").remove();
			modal.style.display = "none";
		}
	}
	if(document.getElementById("isLinkEndBooking") != null && document.getElementById("isLinkEndBooking").value == '1'){
		populatePaxCardDetails("Return");		
	}else{
		populatePaxCardDetails("Forward");
	}
}

function populatePaxCardDetails(requestType){
	var size =  document.getElementsByName("passengerName").length;; 
	// set seat details and calculate total price details
	var seatObj, nm, ad; 
	ad = false;
	var pax = 0;
	var idProofOptions=document.getElementById('idProofTypes').innerHTML;
	for(var i=0; i<size; i++) {
		nm = document.getElementById("passengerName" + requestType + i);
		seatObj = document.getElementById("seatDetails" + requestType + i);
		if(seatObj == null) { continue; }

	 _rEle = '<tr id="paxIdProof" name="paxIdProof">' 
	+ '<td>'
		+ '<input type="text"  value='+nm.value+' maxlength="150" size="16" class="requiredfield" readonly="readonly">'
	+ '</td>'
	+ '<td>'
		+ '<input type="text"  value='+seatObj.value+' size="1" class="seatNormalField" readonly="readonly">'
	+ '</td>'
	+ '<td>'
	+ '<select name="idProofType" id="idProofType'+requestType + i+'"  class="requiredfield" >'
	+	idProofOptions	+
	+'</select>'
	+ '</td>'
	+'<td>'
	+ '<input type="text" name= "idProof" id="idProof'+requestType + i+'"  maxlength="150" size="20" class="requiredfield" onblur="validateAdhaar(\''+requestType + i+'\', this.value);">'
	+ '</td>'
	+ '</tr>'
	;
     var tableId = '#idProofTB'+requestType+' tr:last'
	 $(tableId).after(_rEle);
     
	}
}

function validateAdhaar(requestType, val){
	if(val !=''){
		var divName ="ValidateAdharDivId";
		var proofId = 0;
		if(document.getElementById('idProofType'+requestType) != null){
			proofId = document.getElementById('idProofType'+requestType).value;
		}
		var path ="/ajax/validate/adhaar.do?cardNumber="+val+"&proofTypeId="+proofId+"&requestType="+requestType;
		
		ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}
}

function setAdhaaCardDetails(isValidate, requestType){
	if(isValidate !=null && isValidate != '' && isValidate == 0){
		document.getElementById('idProof'+requestType).value = null;
		alert("Please enter valid adhar card number..");
		return false;
	}
}

function setConcCardDetails(concCards, passengerName, genderType, index, isValidate){

	
	if(concCards != null){
		if(isValidate == 1){
			if(passengerName != null && passengerName != "" && document.getElementById('passengerName'+index) != null){
				document.getElementById('passengerName'+index).value = passengerName;
			} else {
				document.getElementById('passengerName'+index).value = "";
			}
			if(genderType != null && genderType != "" && document.getElementById('genderCodeId'+index) != null){
				document.getElementById('genderCodeId'+index).value = genderType;
			}  else {
				document.getElementById('genderCodeId'+index).selectedIndex = "-1";
			}
			if((passengerName == null || passengerName == "") && (genderType == null || genderType == "")){
				document.getElementById('concessionIds'+index).selectedIndex = "-1";
				document.getElementById("cardNumber" + index).value = "";
				document.getElementById("cardNumber" + index).disabled = true;
				alert("Please enter valid APSRTC CardID");
			}
		} else if(isValidate == 2){
			document.getElementById('passengerAge'+index).value = "";
			document.getElementById('concessionIds'+index).selectedIndex = "-1";
			document.getElementById("cardNumber" + index).value = "";
			document.getElementById("cardNumber" + index).disabled = true;
			alert("Child is not aplicable to this concession..");
		}
		
	} else {
		if(document.getElementById('passengerName'+index) != null)
			document.getElementById('passengerName'+index).value = "";
		if(document.getElementById('genderCodeId'+index) != null)
			document.getElementById('genderCodeId'+index).selectedIndex = "-1";
		document.getElementById('concessionIds'+index).selectedIndex = "-1";
		if(passengerName != null && passengerName != "" && genderType != null && genderType != ""){
			alert("Please enter valid APSRTC CardID");
		}
	}
}
//copied from ksrtc
function validateMyTicket(formObj, fmId, path) {
	var isTranxSuccess;
	if(document.querySelectorAll('[id="home-tab"][class*="nav-link active"]').length==1){
		isTranxSuccess = 1;
	}else {
		isTranxSuccess = 0;
	}
	
	var v = document.getElementById("id").value;
	if(v == null || v == '' || v == '0') {
		alert("Please enter valid ticket number to continue.");
		return false;
	}
	
	if(!validateMobileNo(document.getElementById("mobileNo"))) {
		return false;
	}
	path = path + "?isTranxSuccess=" +isTranxSuccess;
	formObj.action = path;
	formObj.submit();
}
function changeServiceStatus(){
	document.getElementById("isTranxSuccess_9").checked = true;
	document.getElementById("isTranxSuccess_7").checked = false;
	document.getElementById("isTranxSuccess_8").checked = false;
	document.getElementById("serviceStatus_1").checked = true;
	hidediv('PnrDivId');
	hidediv('ObRefDivId');
	hidediv('ByTripcodeId');
	showdiv('ByServiceStatus');
	showdiv('ByPnrNoId');
}
function changeObRef(){
	document.getElementById("isTranxSuccess_3").checked = false;
	document.getElementById("isTranxSuccess_4").checked = true;
	document.getElementById("isTranxSuccess_6").checked = false;
	document.getElementById("TransactionStatus_1").checked = true;
	

	hidediv('PnrDivId');
	showdiv('ObRefDivId');
	showdiv('ByObRefenceId');
	hidediv('ByMobileNo');
	hidediv('ByEmailId');
	hidediv('ByServiceStatus');
}
function searchServiceStatus(){
	if(document.getElementById("serviceStatus_1").checked == true){
		document.getElementById("serviceStatus_1").checked = true;
		document.getElementById("serviceStatus_2").checked = false;
		hidediv('ByTripcodeId');
		showdiv('ByServiceStatus');
		showdiv('ByPnrNoId');
		
	}else {
		document.getElementById("serviceStatus_1").checked = false;
		document.getElementById("serviceStatus_2").checked = true;
		hidediv('ByPnrNoId');
		showdiv('ByTripcodeId');
		
	}

}
function searchTranxStatus(){
	document.getElementById("isTranxSuccess_1").checked = true;
	if(document.getElementById("TransactionStatus_1").checked == true){
		document.getElementById("TransactionStatus_1").checked = true;
		document.getElementById("TransactionStatus_2").checked = false;
		document.getElementById("TransactionStatus_3").checked = false;
		showdiv('ByObRefenceId');
		hidediv('ByMobileNo');
		hidediv('ByEmailId');
		
	}else if(document.getElementById("TransactionStatus_2").checked == true){
		document.getElementById("TransactionStatus_1").checked = false;
		document.getElementById("TransactionStatus_2").checked = true;
		document.getElementById("TransactionStatus_3").checked = false;
		hidediv('ByObRefenceId');
		showdiv('ByMobileNo');
		hidediv('ByEmailId');
		
	}else{
		document.getElementById("TransactionStatus_1").checked = false;
		document.getElementById("TransactionStatus_2").checked = false;
		document.getElementById("TransactionStatus_3").checked = true;
		hidediv('ByObRefenceId');
		hidediv('ByMobileNo');
		showdiv('ByEmailId');
		
	}
	
}
function changepnrNo(){
	document.getElementById("isTranxSuccess_3").checked = false;
	document.getElementById("isTranxSuccess_2").checked = false;
	document.getElementById("isTranxSuccess_1").checked = true;
	showdiv('PnrDivId');
	hidediv('ObRefDivId');
	hidediv('ByObRefenceId');
	hidediv('ByMobileNo');
	hidediv('ByEmailId');
	hidediv('ByServiceStatus');
}
//unchanged
/*function getTranxDetails(formObj, fmId, path) {
	var isTranxSuccess;
	if(document.querySelectorAll('[id="home-tab"][class*="nav-link active"]').length==1){
		isTranxSuccess = 1;
	}else {
		isTranxSuccess = 0;
	}
	var v, bankRefNo = 0, mobileNo = 0, email= 0, tranxDate= 0;
	if(document.querySelectorAll('[href="#OB-reference"][class*="nav-link active"]').length==1){
		v = document.getElementById("bankRefNo");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid bankRefNo to continue.");
			return false;
		}else {
			bankRefNo = v.value;
		}		
	}else if(document.querySelectorAll('[href="#by-mobile"][class*="nav-link active"]').length==1){
		v = document.getElementById("tranxMobileNo");
		if(false){//!validateMobileNo(v)) {
			alert("Please enter valid mobileNo to continue.");
			return false;
		}else {
			mobileNo = v.value;
		}
		v = document.getElementById("tranxDate");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid transaction Date to continue.");
			return false;
		}else {
			tranxDate = v.value;
		}
	}else{
		v = document.getElementById("email");
		if(v == null || v.value == '' || v.value == '0' || !validEmail(v.value)) {
			alert("Please enter valid email to continue.");
			return false;
		}else {
			email = v.value;
		}
		v = document.getElementById("tranxDate1");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid transaction Date to continue.");
			return false;
		}else {
			tranxDate = v.value;
		}
	}

	path = path + "?isTranxSuccess=" +isTranxSuccess
				+ "&bankRefNo=" +bankRefNo
				+ "&mobileNo=" +mobileNo
				+ "&email=" +email
				+ "&tranxDate=" +tranxDate
				;
	formObj.action = path;
	formObj.submit();
}*/
//changed
function getTranxDetails(formObj, fmId, path) {
	var isTranxSuccess;
	if(true){
		isTranxSuccess = 1;
	}else {
		isTranxSuccess = 0;
	}
	var v, bankRefNo = 0, mobileNo = 0, email= 0, tranxDate= 0;
	if (document.getElementById("TransactionStatus_1").checked) {
		v = document.getElementById("bankRefNo");
		if (v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid bankRefNo to continue.");
			return false;
		} else {
			bankRefNo = v.value;
		}
		v = document.getElementById("obMobileNo");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter Mobile to continue.");
			return false;
		}else {
			mobileNo = v.value;
		}
	}
		
	else if(document.getElementById("TransactionStatus_2").checked){
		v = document.getElementById("tranxMobileNo");
		if(v == null || v.value == '' || v.value == '0' || !validateMobileNo(v)){
			alert("Please enter valid mobileNo to continue.");
			return false;
		}else {
			mobileNo = v.value;
		}
		v = document.getElementById("tranxDate");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid transaction Date to continue.");
			return false;
		}else {
			tranxDate = v.value;
		}
	}else{
		v = document.getElementById("email");
		if(v == null || v.value == '' || v.value == '0' || !validEmail(v.value)) {
			alert("Please enter valid email to continue.");
			return false;
		}else {
			email = v.value;
		}
		v = document.getElementById("tranxDate1");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid transaction Date to continue.");
			return false;
		}else {
			tranxDate = v.value;
		}
	}
	formObj.action = path;
	formObj.submit();
}
function getServiceDetails(formObj, fmId, path) {
	
	var v, pnrPrefixWithTktNo = 0, serviceCode = 0, txtDepartureDate;
	
	if(document.getElementById("serviceStatus_1").checked){
		v = document.getElementById("pnrPrefixWithTktNo1");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid PNR Number to continue.");
			return false;
		}else {
			pnrPrefixWithTktNo = v.value;
		}		
	}else {
		v = document.getElementById("serviceCode");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid Trip code to continue.");
			return false;
		}else {
			serviceCode = v.value;
		}
		v = document.getElementById("txtDepartureDate");
		if(v == null || v.value == '' || v.value == '0') {
			alert("Please enter valid Departure Date to continue.");
			return false;
		}else {
			txtDepartureDate = v.value;
		}
	}

	formObj.action = path;
	formObj.submit();
}
function enabledPassPortNo(objTxt){
	if(document.getElementById('nationality'+objTxt).value!='IN'){
	var hiddenForeignerId=document.getElementsByClassName('hiddenForeignerId');
	while (hiddenForeignerId.length) hiddenForeignerId[0].classList.remove("hiddenForeignerId");

	for(i=0;i<document.querySelectorAll("[id^='nationalityForward']").length;i++){

	if(document.querySelectorAll("[id^='nationalityForward']")[i].value=='IN'){
	if(document.getElementById('foreignerPnoForward'+i) !=null){
		document.getElementById('foreignerPnoForward'+i).classList.add("hiddenForeignerId");
		document.getElementById('foreignerPaddForward'+i).classList.add("hiddenForeignerId");
		document.getElementById('foreignerpDobForward'+i).classList.add("hiddenForeignerId");
	}
	}
	}
	/*var hiddenForeignerId=document.getElementsByClassName('hiddenForeignerId');

	for(var k=0;k<hiddenForeignerId.length;k++){
	hiddenForeignerId[k].classList.remove("hiddenForeignerId");
	}*/

	document.getElementById('passportNo'+objTxt).removeAttribute('readonly');
	document.getElementById('foreignerAddress'+objTxt).removeAttribute('readonly');
	document.getElementById('dob'+objTxt).removeAttribute('readonly');
	if(document.getElementById('idProofs'+objTxt)!=null && document.getElementById('idProofNum'+objTxt) != null){
		document.getElementById('idProofs'+objTxt).setAttribute('style','opacity: 0.5;pointer-events: none;cursor: default;');
		document.getElementById('idProofs'+objTxt).value = '';
		document.getElementById('idProofNum'+objTxt).setAttribute('readonly','readonly');
		document.getElementById('idProofNum'+objTxt).value='';
	}
	

	$('#dob'+objTxt).datepicker({
	   defaultDate: "+1w",
	   changeMonth: true,
	   changeYear: true,
	   dateFormat: "dd/mm/yy",
	   maxDate: serverdate,
	   yearRange: "-100:+0"
	})
	return false;


	}
	else {
	hideForeigner(objTxt);
	if(document.getElementById('idProofs'+objTxt)!=null && document.getElementById('idProofNum'+objTxt) != null){
		document.getElementById('idProofs'+objTxt).removeAttribute('style');
		document.getElementById('idProofNum'+objTxt).removeAttribute('readonly');
		}
		
	}
	if(objTxt.match('Forward')!=null){	
	var disabled=false;
	var countIndians=0;
	for(i=0;i<document.querySelectorAll("[id^='nationalityForward']").length;i++){
	if(document.querySelectorAll("[id^='nationalityForward']")[i].value=='IN'){
	countIndians++;
	if(document.getElementById('foreigner'+objTxt) != null)
	document.getElementById('foreigner'+objTxt).classList.add("hiddenForeignerId");
	}
	}	
	if(document.querySelectorAll("[id^='foreignerAddressForward']").length && countIndians==document.querySelectorAll("[id^='foreignerAddressForward']").length){
	var hiddenForeignerId=document.getElementsByClassName('hiddenForeigner');
	for(var k=0;k<hiddenForeignerId.length;k++){
	hiddenForeignerId[k].classList.add("hiddenForeignerId");
	}
	}	
	}
	if(objTxt.match('Return')!=null){	
	for(i=0;i<document.querySelectorAll("[id^='foreignerAddressReturn']").length;i++){
	document.querySelectorAll("[id^='foreignerAddressReturn']")[i].setAttribute('readonly','readonly');
	document.querySelectorAll("[id^='foreignerAddressReturn']")[i].classList.add("hiddenForeignerId");

	document.querySelectorAll("[id^='passportNoReturn']")[i].setAttribute('readonly','readonly');
	document.querySelectorAll("[id^='passportNoReturn']")[i].classList.add("hiddenForeignerId");

	document.querySelectorAll("[id^='dobReturn']")[i].setAttribute('readonly','readonly');
	document.querySelectorAll("[id^='dobReturn']")[i].classList.add("hiddenForeignerId");
		if(document.querySelectorAll("[id^='idProofsReturn']")[i] != null && document.querySelectorAll('idProofNum'+objTxt) !=null){
			document.querySelectorAll("[id^='idProofsReturn']")[i].removeAttribute('style');
			document.querySelectorAll('idProofNumReturn'+objTxt).removeAttribute('readonly');
			}	
		}
	}
}

function hideForeigner(objTxt, concVal){
	document.getElementById('foreignerAddress'+objTxt).setAttribute('readonly','readonly');
	document.getElementById('passportNo'+objTxt).setAttribute('readonly','readonly');
	document.getElementById('dob'+objTxt).setAttribute('readonly','readonly');
	
	document.getElementById('foreignerAddress'+objTxt).value='';
	document.getElementById('passportNo'+objTxt).value='';
	document.getElementById('dob'+objTxt).value='';
	
	document.getElementById('foreignerAddress'+objTxt).classList.add("hiddenForeignerId");
	document.getElementById('passportNo'+objTxt).classList.add("hiddenForeignerId");
	document.getElementById('dob'+objTxt).classList.add("hiddenForeignerId");
	document.getElementById('dob'+objTxt).classList.add("hiddenForeignerId");
	if(document.getElementById('foreigner'+objTxt) != null)
		document.getElementById('foreigner'+objTxt).classList.add("hiddenForeignerId");
	
	var objTxt=objTxt;
	var nationObjects=document.querySelectorAll("[id*='nationality"+objTxt.substring(0,objTxt.length-1)+"']");
	var len=nationObjects.length;
	
	var disabledAll=false;
	for(var i=0;i<len;i++){
		if(nationObjects[i].value!='IN')
			disabledAll=true;
	} 
	var isPaxConceAllowed = document.getElementById("paxConcessionAllowed").value;
	if(isPaxConceAllowed == "true" && concVal!=undefined && concVal.value !=  '1466060086837'){
		disabledAll=false;
	}
	/*if(!disabledAll){
		var hiddenForeignerId=document.getElementsByClassName('hiddenForeigner');
		for(var k=0;k<hiddenForeignerId.length;k++){
			hiddenForeignerId[k].classList.add("hiddenForeignerId");
		}
	}*/
}
function foreignPassengerValidation(reqType){
	
	var passportObj,addressObj,dobObj;
	passportObj=document.getElementById('passportNo'+reqType);
	addressObj=document.getElementById('foreignerAddress'+reqType);
	dobObj=document.getElementById('dob'+reqType);
	if(passportObj!= null && passportObj.value.trim()==""){
		alert("Please Enter Passport No.");
		passportObj.focus();
		return false;
	} if(addressObj!= null && addressObj.value.trim()==""){
		alert("Please Enter Address.");
		addressObj.focus();
		return false;
	}if(dobObj!= null && dobObj.value.trim()==""){
		alert("Please Select DOB.");
		dobObj.focus();
		return false;
	} 	
	else{
		return true;
	}
}


function verifyTravelHistoryOTP(path,divName,fromId,formObj){
	if(!validateMobileNo(document.getElementById("mobileNo"))) {
		document.getElementById('verifyOTPBtnsubmit').style='';
		document.getElementById('mobileNo').style='';
		return false;
	}
	if(fromId == 1){
		document.getElementById('verifyOTPBtnsubmit').style='opacity: 0.5;pointer-events: none;cursor: default;';
		document.getElementById('mobileNo').style='opacity: 0.5;pointer-events: none;cursor: default;';
		path= path + 'mobileNo=' + document.getElementById('mobileNo').value;
		ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	} else if(fromId == 2){
		if(document.getElementById('otpCode').value == "" || document.getElementById('otpCode').value == "0") {
			alert("Please enter OTP");
			document.getElementById('otpCode').focus();
			return false;
		}
		
		document.getElementById('verifyOTPBtn').style='opacity: 0.5;pointer-events: none;cursor: default;';
		path= path + 'mobileNo=' + document.getElementById('mobileNo').value;
		path= path + '&otpCode=' + document.getElementById('otpCode').value;
		
		formObj.action = path;
		formObj.submit();
	} else {
		path= path + 'mobileNo=' + document.getElementById('mobileNo').value;
		ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}
	
}

function verifyTravelHistory(form,path) {
	
	if(document.getElementById("txtJourneyDatePop") && (document.getElementById("txtJourneyDatePop").value =="" 
			|| document.getElementById("txtJourneyDatePop").value =='Journey On')) {
		alert("Please select Journey Date");
		return;
	}
	if(!document.getElementById('termsChk').checked) {
		alert("Please agree terms & conditions");
		return;
	}
	if(document.getElementById("prepopulatedJourneyPopUp")) {
		document.getElementById("prepopulatedJourneyPopUp").style.display="none";
	}
	var ob = document.getElementById("txtJourneyDate");
	formObj = ob.form;
	document.getElementById("txtJourneyDate").value = document.getElementById("txtJourneyDatePop").value;
	path= path + '?covidBkgEnable=' + document.getElementById('covidBkgEnable').value;
	validateBookingSearch(formObj, path);
}

function resetPopUpDateTxt(o, v) {
	if(o != null) {
		o.value = v;
	}
	$('#txtJourneyDatePop').datepicker({ numberOfMonths: 2
		, dateFormat: 'dd/mm/yy'
		, minDate: '0'
		, maxDate: "+30d"
		}).val();
}

function removeEroorMsg() {
	if (document.getElementById("mailErrId") && document.getElementById("mailErrId").style.display !='none') {
		document.getElementById("mailErrId").style.display='none';
	}
}

function buttonVisible(name, act) {
	if(document.getElementById(name) != null)
		document.getElementById(name).disabled = act;
}

function submitResendOtp(formObj, path) {
	formObj.action = path;
	buttonVisible("ReSendsubmitBtn", "disabled");
	formObj.submit();
}

function verifyUserMobile(formObj, path) {
	var ob = document.getElementById("mobileVerifyOtp");
	if (ob && ob.value == "") {
		alert("Please enter valid OTP");
		return false;
	}
	formObj.action = path;
	formObj.submit();
}

function verifyUserEmail(formObj, path) {
	var ob = document.getElementById("emailVerifyOtp");
	if (ob && ob.value == "") {
		alert("Please enter valid OTP");
		return false;
	}
	formObj.action = path;
	formObj.submit();
}


function convertToCameCaselString(data_pickupPoint) {
	if(data_pickupPoint!=null && data_pickupPoint!="" && data_pickupPoint!= undefined){
		var str = data_pickupPoint;
		var parts = str.trim().split(" ");
		var camelCaseString = "";
		var temp = "";
		for (i = 0; i < parts.length; i++) {
			if (parts[i] != null && parts[i].trim().length > 0) {
				temp = parts[i].trim();
				var spaces = "";
				if (temp.length != parts[i].length) {
					var startCharIndex = parts[i].charAt(temp.indexOf(0));
					spaces = parts[i].substring(0, startCharIndex);
				}
				temp = temp.substring(0, 1).toUpperCase() + spaces
						+ temp.substring(1).toLowerCase() + " ";
				camelCaseString += temp;
			} else
				camelCaseString += parts[i] + " ";
		}
		return camelCaseString;
	}else{
		return "";
	}
}



function hideTddDiv() {
	if(document.getElementById("TtdSearchAccDiv")) {
		document.getElementById("TtdSearchAccDiv").style.display = 'none';
	}
	if(document.getElementById("duration")) {
		document.getElementById("duration").checked = false;
	}
	if(document.getElementById("accomodationIdForward")) {
		document.getElementById("acFlagForward").checked = true;
	}else {
		if(document.getElementById("acFlagReturn")) {
			document.getElementById("acFlagReturn").checked = true;
		}
	}
	if(document.getElementById('ttdAccommodationId')) {
		document.getElementById('ttdAccommodationId').value == '';
	}
}
function enableReturnJourney(div, formObj){
	closeDiscountModal();
	divFlipFlop(div, formObj);
	document.getElementById('txtReturnJourneyDate').focus();
}
function changeMinDate(div,minDate){
	$( "#"+div ).datepicker( "option", "minDate",minDate,"dd/mm/yyyy", "/");
}
function closeDiscountModal() {
	hidediv('returnDiscountModal');
}

function searchSrslmAccDetails(path, divName, requestType, dateMinRange, dateMaxRange){
	var srisailamAccJourneyDate, serviceId;
	var aPax = 0, cPax = 0, totPax = 0;
	var tripNo = 0;
	var startdateParts = null;
	var enddateParts = null;
	var darshanDateParts = null;
	var startDate = null;
	var endDate = null;
	var darshanDate = null;
	if(dateMinRange && dateMaxRange) {
		startdateParts = dateMinRange.split("/");
		enddateParts = dateMaxRange.split("/");
		startDate = new Date(+startdateParts[2], startdateParts[1] - 1, +startdateParts[0]);
		endDate = new Date(+enddateParts[2], enddateParts[1] - 1, +enddateParts[0]);
	}
	var max = parseInt(document.getElementById("maxAgeCh").value);
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			
			if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax;
	if(totPax == 0){
		alert("Please select seat..");
		return false;
	}
	

	var Obj = document.getElementById("srisailamAccJourneyDate");
	console.log(srisailamAccJourneyDate);
	if(Obj == null) {
		alert("Please select date to continue..");
		return false;
	} else {
		srisailamAccJourneyDate = Obj.value;
	}
	if(srisailamAccJourneyDate == ""){
		alert("Please select Darshan Date.");
		return false;
	}
	darshanDateParts = srisailamAccJourneyDate.split("/");
	darshanDate = new Date(+darshanDateParts[2], darshanDateParts[1] - 1, +darshanDateParts[0]);
	if(startDate && endDate) {
		if(!(darshanDate >= startDate && darshanDate <= endDate)) {
			alert("Please select available Darshan Date.");
			return false;
		}
	}
	
	if(document.getElementById("SrslmSearchAccDiv")) {
		document.getElementById("SrslmSearchAccDiv").style.display = '';
	}
	Obj = document.getElementById("ForwardServiceId");
	if(Obj != null){
		serviceId = Obj.value;
	}
	if(requestType == 'Return'){
		Obj = document.getElementById("ReturnServiceId");
		if(Obj != null){
			serviceId = Obj.value;
		}
	}
	if(requestType == 'Return'){
		Obj = document.getElementById("retTripNo");
		if(Obj != null)
			tripNo = Obj.value;
	} else {
		Obj = document.getElementById("forwardTtripNo");
		if(Obj != null)
			tripNo = Obj.value;
	}
	path =  path +"?serviceId=" +serviceId
	+ "&srisailamAccJourneyDate=" + srisailamAccJourneyDate
	+"&totalNoPassengers="+totPax
	+"&RequestType="+requestType
	+"&tripNo=" + tripNo
	;
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function setSrslmAccomodationDetails(requestType, srslmAccId, slot) {

	if(srslmAccId == 0){
		if(document.getElementById('srisailamAccommodationId') != null)
			document.getElementById('srisailamAccommodationId').value = "";
		
		if(document.getElementById('totalSrisailamAccAmount') != null){
			document.getElementById('totalSrisailamAccAmount').value = 0;
			setTtdAccomodationAmount('Forward');
			document.getElementById('SrslmAccomadationDiv').style.display = "none";
		}
		return false;
	}
	showdiv('SrslmAccomadationDiv');
	
if(requestType == 'Forward'){
	document.getElementById('srisailamAccFlag').value = 0;
}else{
	document.getElementById('srisailamAccFlag').value = 1;
}
	divName = "SrslmAccomadationDiv";
	var srisailamAccJourneyDate, serviceId;
	var Obj = document.getElementById("srisailamAccJourneyDate");
	if(Obj != null) {
		srisailamAccJourneyDate = Obj.value;
	}

	if(srisailamAccJourneyDate == ""){
		alert("Please select Darshan Date.");
		return false;
	}

	Obj = document.getElementById("ForwardServiceId");
	if(Obj != null){
		serviceId = Obj.value;
	}
	
	var aPax = 0, cPax = 0, totPax = 0;
	var max = parseInt(document.getElementById("maxAgeCh").value);
	var maxSslmAgeCh = parseInt(document.getElementById("maxSslmAgeCh").value);
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			
			if(ob.value != null && ob.value != "" && ob.value >= maxSslmAgeCh){
				++aPax;
			}
			else if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} 
			else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax;
	document.getElementById('srisailamAccommodationId').value = srslmAccId;
	var tripNo;
	if(document.getElementById("forwardTtripNo") != null)
		tripNo = document.getElementById("forwardTtripNo").value;
	
	var darshandPlaceId = document.getElementById('endPlaceId').value;
	if(document.getElementById('isLinkStartBooking') != null 
			&& document.getElementById('isLinkStartBooking').value == '1'
			&& document.getElementById('linkPlaceId') != null
			&& document.getElementById('linkPlaceId').value != ''){
		darshandPlaceId = document.getElementById('linkPlaceId').value;
	}

	var journeyDate = document.getElementById('txtJourneyDate').value;
	var startPlaceId = document.getElementById('startPlaceId').value;
	if(document.getElementById('isLinkEndBooking') != null 
			&& document.getElementById('isLinkEndBooking').value == '1'
			&& document.getElementById('endPlaceId') != null
			&& document.getElementById('endPlaceId').value != ''){
		startPlaceId = document.getElementById('linkPlaceId').value;
		darshandPlaceId = document.getElementById('endPlaceId').value;
		Obj = document.getElementById("ReturnServiceId");
		if(Obj != null){
			serviceId = Obj.value;
		}
		Obj = document.getElementById("retTripNo");
		if(Obj != null){
			tripNo = Obj.value;
		}
	}

	var path =  "/srslm/search/slot.do?srisailamAccommodationId=" + srslmAccId
	+"&srslmSlot=" + slot
	+"&totalNoPassengers="+totPax
	+"&srisailamAccJourneyDate=" + srisailamAccJourneyDate
	+"&serviceId=" + serviceId
	+ "&txtJourneyDate=" + journeyDate
	+ "&startPlaceId=" + startPlaceId
	+ "&endPlaceId=" + darshandPlaceId
	+ "&concessionId=" + document.getElementById('concessionId').value
	+ "&tripNo=" + tripNo
	+ "&requestType=" + requestType    
	;

	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	/*if(price !=''){
		accomPrice = price;
		calculateTotalFare(actName);
	} else {
		accomPrice = 0;
		calculateTotalFare(actName);
	}
	if(id == '') {
		document.getElementById("acmdtPrice" + actName).value = 0.00;
	}*/
}

function srslmAlert(reqType){

	if(document.getElementById("alertSrslm")!= null){
		if((document.getElementById("alertSrslm").value=="1" && reqType=="Forward")
			  ||(document.getElementById("alertSrslm").value=="1" && reqType=="Return" && document.getElementById('isFirstLinkSrslm') != null && document.getElementById('isFirstLinkSrslm').value == '')){

			
		alert("Srisailam Sparsa Darshanam, Athi Seegra Darshanam, Seegra Darshanam tickets to avail the Darshan of Lord Sri Bhramaramba Mallikarjuna Swamy are available for this service. You can book now.");
		}
	}
}

function printSrslmTickets(formObj) {
	hide('srslmPrintDv_0');
	printPageByDiv("srslmPrintDv_0");
	
	divObj = document.getElementById("srslmPrintDv_1");
	if(divObj != null) {
		hide('srslmPrintDv_1');
		printPageByDiv("srslmPrintDv_1");
	}
}

function toggleElements() {
    var checkbox = document.getElementById("returnJourney");
    var elementsToShowOrHide = document.getElementById("returnJourneyDev");

        // If checkbox is checked, display the element; otherwise, hide it
        if (checkbox.checked) {
        	elementsToShowOrHide.style.display = "block";
        } else {
        	elementsToShowOrHide.style.display = "none";
        }
}

function openBookingDetails(event, direction) {
	  var i;
	  var x = document.getElementsByClassName("journeyDirection");
	  for (i = 0; i < x.length; i++) {
	    x[i].style.display = "none";  
	  }
	  
	  var tablinks = document.getElementsByName("detailsShowButton");
	  for (i = 0; i < x.length; i++) {
	    tablinks[i].className = "rjtCanInActLink";
	  }
	  document.getElementById(direction).style.display = "block";  
	  event.currentTarget.className='rjtCantabLink';
}

function loadFields(div) {
	document.getElementById('PnrDivId').innerHTML = '';
	ajaxCommonActionSubmit("/ticket/waitlist/load/fields.do?fwDiv=" + div,
			"PnrDivId", DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function loadTransactionStatusFields(div) {
	document.getElementById('TransactionStatusSubDiv').innerHTML = '';
	ajaxCommonActionSubmit("/ticket/waitlist/load/fields.do?fwDiv=" + div,
			"TransactionStatusSubDiv", DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function loadServiceStatusStatusFields(div) {
	document.getElementById('ServiceStatusSubDiv').innerHTML = '';
	ajaxCommonActionSubmit("/ticket/waitlist/load/fields.do?fwDiv=" + div,
			"ServiceStatusSubDiv", DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function enableToggle(){
	if(document.getElementById('whatsapp-toggle') != null){
		  var whatsappImg = document.getElementById('whatsapp-img');
		  var whatsappFlag = document.getElementById('whatsappFlag');
		  if (whatsappImg.src.includes("whatup-yes.png")) {
			whatsappImg.src = "../../oprs-web/_assets/images/new/whatup-no.png";
		    whatsappFlag.value="0";
		  } else {
			whatsappImg.src = "../../oprs-web/_assets/images/new/whatup-yes.png";
		    whatsappFlag.value="1";
		  }
	}
}
function validatePkgBookingSearch(formObj, path,startPlaceId,endPlaceId,startPlaceName,endPlaceName) {
	/*if(startPlaceId == "" || startPlaceId == "0") {
		alert("Please select start place.");
		return false;
	}*/
	document.getElementById("startPlaceId").value = startPlaceId;
	document.getElementById("endPlaceId").value=endPlaceId;
	document.getElementById("fromPlaceName").value = startPlaceName;
	document.getElementById("toPlaceName").value = endPlaceName;
	document.getElementById("txtJourneyDate").value = '22/04/2025';
	
	formObj.action = path;
	formObj.submit();
}

function submitCustFeedBack(formObj, path) {
           if(validateCustFeedForm()) {
			submitFormAction(path, formObj);
           }
       }
       
       // Form Validation
       function validateCustFeedForm() {
           clearErrorStyles();
           
           var isValid = true;
           var errorMsg = "";
           
           // Journey Date validation
           var journeyDate = document.getElementById('txtJourneyDate').value;
           if(journeyDate.trim() == '') {
               addErrorStyle('txtJourneyDate');
               errorMsg += "Journey Date is required.\n";
               isValid = false;
           }
           
           // Passenger Name validation
           var passengerName = document.getElementById('paxName').value;
           if(passengerName.trim() == '') {
               addErrorStyle('paxName');
               errorMsg += "Passenger Name is required.\n";
               isValid = false;
           } else if(passengerName.trim().length < 2) {
               addErrorStyle('passengerName');
               errorMsg += "Passenger Name must be at least 2 characters.\n";
               isValid = false;
           }
           
           // Mobile Number validation
           var mobileNo = document.getElementById('mobileNo').value;
           if(mobileNo.trim() == '') {
               addErrorStyle('mobileNo');
               errorMsg += "Mobile Number is required.\n";
               isValid = false;
           } else if(!/^\d{10}$/.test(mobileNo)) {
               addErrorStyle('mobileNo');
               errorMsg += "Mobile Number must be exactly 10 digits.\n";
               isValid = false;
           }
           
           // Vehicle Number validation
           var vehicleNo = document.getElementById('vehicleNo').value;
           if(vehicleNo.trim() == '') {
               addErrorStyle('vehicleNo');
               errorMsg += "Vehicle Number is required.\n";
               isValid = false;
           }
           
           // Travel From validation
           var travelledFrom = document.getElementById('travelledFrom').value;
           if(travelledFrom.trim() == '') {
               addErrorStyle('travelledFrom');
               errorMsg += "Travel From is required.\n";
               isValid = false;
           }
           
           // Travel To validation
           var travelledTo = document.getElementById('travelledTo').value;
           if(travelledTo.trim() == '') {
               addErrorStyle('travelledTo');
               errorMsg += "Travel To is required.\n";
               isValid = false;
           }		             
           
           // Remarks validation
           var remarks = document.getElementById('remarks').value;
           if(remarks.trim() == '') {
               addErrorStyle('remarks');
               errorMsg += "Complaints/Remarks is required.\n";
               isValid = false;
           }
           
           var selectedFeild = document.getElementById('selectedFeild').value;
           if(selectedFeild == '1') {
               addErrorStyle('Grievance');
               errorMsg += "Please Select Any Grievance Type.\n";
               isValid = false;
           }
           
           /*if (!crewChecked && !fareChecked && !busChecked && !cleanChecked) {
		                 errorMsg += "Please provide at least one rating.\n";
		                 isValid = false;
		             }*/
           
           if(!isValid) {
               alert("Please correct the following errors:\n\n" + errorMsg);
               return false;
           }
           
           return true;
       }
       
       // Get selected radio button value
       function getSelectedRadioValue(radioName) {
           var radios = document.getElementsByName(radioName);
           for (var i = 0; i < radios.length; i++) {
               if (radios[i].checked) {
                   return radios[i].value;
               }
           }
           return null;
       }
       
       // Update rating text display
       function updateRatingText(category, value) {
           var textElement = document.getElementById(category + 'RatingText');
           if(textElement) {
               if(category === 'fare') {
                   // Handle Yes/No for fare
                   var fareTexts = {
                       'yes': 'Fare was charged',
                       'no': 'No fare charged'
                   };
                   textElement.innerHTML = '(' + fareTexts[value] + ')';
                   textElement.style.color = value === 'no' ? '#28a745' : '#dc3545';
               } else {
                   // Handle ratings for other categories
                   var ratingTexts = {
                       '1': 'Poor',
                       '2': 'Below Average', 
                       '3': 'Average',
                       '4': 'Good',
                       '5': 'Excellent'
                   };
                   textElement.innerHTML = '(' + ratingTexts[value] + ')';
                   textElement.style.color = getRatingColor(value);
               }
           }
       }
       
       // Get color based on rating value
       function getRatingColor(value) {
           var colors = {
               '1': '#dc3545',
               '2': '#fd7e14',
               '3': '#ffc107',
               '4': '#20c997',
               '5': '#28a745'
           };
           return colors[value] || '#666';
       }
       
       // Add error styling to fields
       function addErrorStyle(fieldId) {
           var field = document.getElementById(fieldId);
           if(field) {
               field.classList.add('error-field');
           }
       }
       
       // Clear error styling
       function clearErrorStyles() {
           var fields = ['txtJourneyDate', 'passengerName', 'mobileNo', 'vehicleNo', 'travelledFrom', 'travelledTo'];
           for(var i = 0; i < fields.length; i++) {
               var field = document.getElementById(fields[i]);
               if(field) {
                   field.classList.remove('error-field');
               }
           }
       }
       
       // Reset Form
       function resetForm() {
           document.getElementById('custFeedBackForm').reset();
           clearErrorStyles();
           document.getElementById('remarksCounter').innerHTML = '0/500';
           document.getElementById('remarksCounter').style.color = '#666';
           
           // Clear rating texts
           document.getElementById('crewRatingText').innerHTML = '';
           document.getElementById('fareRatingText').innerHTML = '';
           document.getElementById('busRatingText').innerHTML = '';
           document.getElementById('cleanRatingText').innerHTML = '';
       }
       
       // Character counter for remarks
       function updateRemarksCounter() {
           var remarks = document.getElementById('remarks');
           var counter = document.getElementById('remarksCounter');
           
           if(remarks && counter) {
               var len = remarks.value.length;
               counter.innerHTML = len + '/100';
               
               if(len > 100) {
                   remarks.value = remarks.value.substring(0, 100);
                   counter.innerHTML = '100/100';
               }
               
               if(len > 80) {
                   counter.style.color = 'red';
               } else if(len > 60) {
                   counter.style.color = 'orange';
               } else {
                   counter.style.color = '#666';
               }
           }
       }
       
       // Mobile number input validation (only numbers)
       function validateMobileInput(event) {
           var charCode = (event.which) ? event.which : event.keyCode;
           if (charCode > 31 && (charCode < 48 || charCode > 57)) {
               return false;
           }
           return true;
       }
       
       // Initialize when page loads
       document.addEventListener('DOMContentLoaded', function() {
           var remarks = document.getElementById('remarks');
           if(remarks) {
               remarks.addEventListener('keyup', updateRemarksCounter);
               remarks.addEventListener('change', updateRemarksCounter);
           }
           
           // Add event listeners for mobile validation
           var mobileField = document.getElementById('mobileNo');
           if(mobileField) {
               mobileField.addEventListener('keypress', validateMobileInput);
           }
           
           // Add event listeners for rating updates
           addRatingListeners('crewBehaviour', 'crew');
           addYesNoListeners('anyFareCharged', 'fare'); // Changed to Yes/No listener
           addRatingListeners('busCondition', 'bus');
           addRatingListeners('cleanNess', 'clean');
       });
       
       // Add rating change listeners
       function addRatingListeners(radioName, prefix) {
           for(var i = 1; i <= 5; i++) {
               var radio = document.getElementById(prefix + '_star' + i);
               if(radio) {
                   radio.addEventListener('change', function() {
                       updateRatingText(prefix, this.value);
                   });
               }
           }
       }
       
       // Add Yes/No change listeners
       function addYesNoListeners(radioName, prefix) {
           var yesRadio = document.getElementById(prefix + '_yes');
           var noRadio = document.getElementById(prefix + '_no');
           
           if(yesRadio) {
               yesRadio.addEventListener('change', function() {
                   updateRatingText(prefix, this.value);
               });
           }
           
           if(noRadio) {
               noRadio.addEventListener('change', function() {
                   updateRatingText(prefix, this.value);
               });
           }
       }
       
       
       (function(w){
			if (typeof w.clearData !== 'function') {
				w.clearData = function clearData(elementCodeId, elementValueId, elementHiddenId, eventObject) {
					var keyCode = (eventObject && eventObject.which) ? eventObject.which : (eventObject && eventObject.keyCode) ? eventObject.keyCode : -1;
					if (keyCode === 27) {
						if (elementCodeId) { var codeEl = document.getElementById(elementCodeId); if (codeEl) codeEl.value = ''; }
						if (elementValueId) { var valueEl = document.getElementById(elementValueId); if (valueEl) valueEl.value = ''; }
						if (elementHiddenId) { var hiddenEl = document.getElementById(elementHiddenId); if (hiddenEl) hiddenEl.value = ''; }
					}
				};
			}
			if (typeof w.initAutocompleteFromValues !== 'function' && w.jQuery && typeof jQuery.fn.autocomplete === 'function' && typeof vhcleJsondata !== 'undefined') {
				jQuery(function(){
					var values = (vhcleJsondata || []).map(function(v){ return v && v.value ? v.value : v; });
					jQuery('#vehicleNo').autocomplete({ source: values, minLength: 1 });
				});
			}
		})(window);

		// Mobile number validation functions
		function validateMobileNumber(event) {
			var keyCode = (event.which) ? event.which : event.keyCode;
			// Allow only numbers (0-9), backspace, delete, tab, escape, enter
			if (keyCode == 8 || keyCode == 9 || keyCode == 27 || keyCode == 13 || keyCode == 46 || (keyCode >= 48 && keyCode <= 57)) {
				return true;
			}
			return false;
		}

		// Add input event listener for mobile number field
		document.addEventListener('DOMContentLoaded', function() {
			var mobileInput = document.getElementById('mobileNo');
			if (mobileInput) {
				mobileInput.addEventListener('input', function() {
					this.value = this.value.replace(/[^0-9]/g, '');
				});
			}
			
			// Add input event listeners for text-only fields
			var travelFromInput = document.getElementById('travelledFrom');
			var travelToInput = document.getElementById('travelledTo');
			
			if (travelFromInput) {
				travelFromInput.addEventListener('input', function() {
					this.value = this.value.replace(/[^a-zA-Z\s]/g, '');
				});
			}
			
			if (travelToInput) {
				travelToInput.addEventListener('input', function() {
					this.value = this.value.replace(/[^a-zA-Z\s]/g, '');
				});
			}
		});

		// Function to update remarks counter and limit characters
		function updateRemarksCounter(textarea, maxLength) {
			var currentLength = textarea.value.length;
			var counter = document.getElementById('remarksCounter');
			
			// Update the counter display
			counter.textContent = currentLength + '/' + maxLength;
			
			// If text exceeds max length, truncate it
			if (currentLength > maxLength) {
				textarea.value = textarea.value.substring(0, maxLength);
				counter.textContent = maxLength + '/' + maxLength;
			}
		}

		function validateMobileFormat(input) {
			var mobileNo = input.value.trim();
			if (mobileNo !== '') {
				// Check if it's exactly 10 digits
				if (!/^\d{10}$/.test(mobileNo)) {
					alert('Please enter a valid 10-digit mobile number');
					input.focus();
					input.value = '';
					return false;
				}
				// Check if it starts with valid digits (6, 7, 8, 9)
				if (!/^[6-9]/.test(mobileNo)) {
					alert('Mobile number should start with 6, 7, 8, or 9');
					input.focus();
					input.value = '';
					return false;
				}
			}
			return true;
		}

		// Text-only validation functions
		function validateTextOnly(event) {
			var keyCode = (event.which) ? event.which : event.keyCode;
			// Allow alphabets (A-Z, a-z), space, backspace, delete, tab, escape, enter
			if (keyCode == 8 || keyCode == 9 || keyCode == 27 || keyCode == 13 || keyCode == 46 || keyCode == 32 || 
				(keyCode >= 65 && keyCode <= 90) || (keyCode >= 97 && keyCode <= 122)) {
				return true;
			}
			return false;
		}

		function validateTextFormat(input) {
			var text = input.value.trim();
			if (text !== '') {
				// Check if it contains only alphabets and spaces
				if (!/^[a-zA-Z\s]+$/.test(text)) {
					alert('Please enter only alphabets and spaces');
					input.focus();
					input.value = '';
					return false;
				}
				// Check if it has at least 2 characters
				if (text.length < 2) {
					alert('Please enter at least 2 characters');
					input.focus();
					return false;
				}
			}
			return true;
		}
       



