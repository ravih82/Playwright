function fileUpload(path) {
	var requestId = 0
	var obj;
	var dataFile = document.getElementById("dataFile");
	var obj = document.getElementById("requestId");
	if(obj!= null && obj.value !=''){
		requestId = obj.value;
	}

	if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		alert('The File APIs are not fully supported in this browser.');
		return;
	}

	if (!dataFile) {
		alert("Um, couldn't find the fileinput element.");
	} else if (!dataFile.files) {
		alert("This browser doesn't seem to support the `files` property of file inputs.");
	} else if (!dataFile.files[0]) {
		alert("Please select a file before clicking 'Load'");
	} /*else {
		file = dataFile.files[0];
		
		alert("fileName is :: " + file);
		fr = new FileReader();
		fr.onload = receivedText;
		// fr.readAsText(file);
		fr.readAsDataURL(file);
	}*/

	if (path.indexOf("?") > 0) {
		path += "&";
	} else {
		path += "?";
	}

	var newPath = path + 'requestId=' + requestId;
	//alert("newPath = " + newPath);
	document.getElementById("fileNameStr").value = newPath;
	
	var fd = new FormData();

	fd.append("dataFile", $("#dataFile")[0].files[0]);
	$.ajax({
		url : newPath,
		type : 'POST',
		cache : false,
		data : fd,
		processData : false,
		contentType : false,
		beforeSend : function() {
			$("#output").html("Uploading, please wait....");
			$("#output").attr("class", "hire-upload-msg");
			$("#fileUploadContanierDiv").css('visibility','hidden');
			if($("#fileUploadContanierButton") != null)
				$("#fileUploadContanierButton").css('visibility','hidden');
		},
		success : function(data) {
			if  (data.indexOf("errormsg") < 0) {
				//$("#output").html("Upload success.");
				//$("#output").attr("class", "hire-upload-msg");
				document.getElementById("fileNameStr").value = data;
				$("#output").html(data +" has been uploaded successfully."+"<a href='javascript:removeFile();'>Remove</a>");
				$("#output").attr("class", "hire-upload-msg");		
			}else{
				$("#output").html(data);
				$("#output").attr("class", "");
				$("#fileUploadContanierDiv").css('visibility','visible');
				if($("#fileUploadContanierButton") != null)
					$("#fileUploadContanierButton").css('visibility','visible');
			}			
		},
		complete : function(data) {
			$("#dataFile").val('');
			//document.getElementById("fileNameStr").value = data.responseText;
			//$("#output").html(data.responseText +" has been uploaded successfully."+"<a href='javascript:removeFile();'>Remove</a>");
			//$("#output").attr("class", "hire-upload-msg");
		},
		error : function() {
			alert("ERROR in upload");
			document.getElementById("fileNameStr").value = "";
			$("#output").html("");
			$("#output").attr("class", "");
			$("#fileUploadContanierDiv").css('visibility','visible');
			if($("#fileUploadContanierButton") != null)
				$("#fileUploadContanierButton").css('visibility','visible');
		}
	});

}

function removeFile(){
	document.getElementById("fileNameStr").value = "";
	$("#output").html("");
	$("#output").attr("class", "");
	$("#fileUploadContanierDiv").css('visibility','visible');
	if($("#fileUploadContanierButton") != null)
		$("#fileUploadContanierButton").css('visibility','visible');
}



function busPassPhotoUpload(path) {
	var requestId = 0
	var obj;
	var dataFile = document.getElementById("dataFile");
	

	if (!window.File || !window.FileReader || !window.FileList || !window.Blob) {
		alert('The File APIs are not fully supported in this browser.');
		return;
	}

	if (!dataFile) {
		alert("Um, couldn't find the fileinput element.");
	} else if (!dataFile.files) {
		alert("This browser doesn't seem to support the `files` property of file inputs.");
	} else if (!dataFile.files[0]) {
		alert("Please select a file before clicking 'Load'");
	} /*else {
		file = dataFile.files[0];
		
		alert("fileName is :: " + file);
		fr = new FileReader();
		fr.onload = receivedText;
		// fr.readAsText(file);
		fr.readAsDataURL(file);
	}*/

	var newPath = path;
	//alert("newPath = " + newPath);
	document.getElementById("fileNameStr").value = newPath;
	
	var fd = new FormData();

	fd.append("dataFile", $("#dataFile")[0].files[0]);
	$.ajax({
		url : newPath,
		type : 'POST',
		cache : false,
		data : fd,
		processData : false,
		contentType : false,
		beforeSend : function() {
			$("#output").html("Uploading, please wait....");
			$("#output").attr("class", "hire-upload-msg");
			$("#fileUploadContanierDiv").css('visibility','hidden');
			if($("#fileUploadContanierButton") != null)
				$("#fileUploadContanierButton").css('visibility','hidden');
		},
		success : function(data) {
			if  (data.indexOf("errormsg") < 0) {
				//$("#output").html("Upload success.");
				//$("#output").attr("class", "hire-upload-msg");
				document.getElementById("fileNameStr").value = data;
				$("#output").html(data +" has been uploaded successfully."+"<a href='javascript:removeFile();'>Remove</a>");
				$("#output").attr("class", "hire-upload-msg");		
			}else{
				$("#output").html(data);
				$("#output").attr("class", "");
				$("#fileUploadContanierDiv").css('visibility','visible');
				if($("#fileUploadContanierButton") != null)
					$("#fileUploadContanierButton").css('visibility','visible');
			}			
		},
		complete : function(data) {
			document.getElementById("fileNameStr").value = data.responseText;
			$("#output").html(data.responseText +" has been uploaded successfully."+"<a href='javascript:removeFile();'>Remove</a>");
			$("#output").attr("class", "hire-upload-msg");
		},
		error : function() {
			alert("ERROR in upload");
			document.getElementById("fileNameStr").value = "";
			$("#output").html("");
			$("#output").attr("class", "");
			$("#fileUploadContanierDiv").css('visibility','visible');
			if($("#fileUploadContanierButton") != null)
				$("#fileUploadContanierButton").css('visibility','visible');
		}
	});

}

function removebusPassPhotoUpload(){
	document.getElementById("dataFile").value = "";
	$("#output").html("");
	$("#fileUploadContanierButton").css('pointer-events','auto');
	$("#output").attr("class", "");
	document.getElementById("fileName").value = "";
}
