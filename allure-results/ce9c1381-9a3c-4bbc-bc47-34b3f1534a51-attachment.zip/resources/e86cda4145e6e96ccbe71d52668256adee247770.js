/*
 * Author		: Rajasekhar
 * Description 	: Dojo Ajax JavaScripts for Abhibus OPRS Project
 */

/** ************************ Jquery AJAX stuff start ************************** */



var sortTermGlobal;	

var DIV_DEFAULT_WIDTH = "100%",DIV_DEFAULT_HEIGHT = "100%";
// refreshId -- refresh id is used to get the information of current page
var selectedIds = "", refreshId = "",parameter1 = "", parameter2 = "";
var _TAB = '9', _ESC = '27',_ETR = '13', _DEL = '46';
var _Z0 = 48, _N9 = 57, _A = 65, _Z = 90, _BSPC = 8, _SPC = 32;
var refreshInt = 3;
var divPosition = 'relative';
function getCurrentIndex(curIdx, divName) {
	if(curIdx > 0)
		return curIdx;
	// modify the display content as per regular expression matching string
	var table = document.getElementById(divName+"Tbl");
	var row, col;
	var found = false;
	for (var i = 0; table != null && (row = table.rows[i]); i++) {
	   //iterate through rows
	   //rows would be accessed using the "row" variable assigned in the for loop
	   for (var j = 0; (col = row.cells[j]); j++) {
		   //iterate through columns
		   //columns would be accessed using the "col" variable assigned in the for loop
		   if(col.style.display != 'none') {
			   return i;
		   }
	   }
	}// end of rows for loop
	return 0;
}

function respHandlerAjaxJS(txtIdDest, txtCodeSrc, txtNameDest, eventObj, divName) {
	var found = false, t, aStr;
	var rexp = "";
	var tgtId;
	if(window.event) {
		// IE
		tgtId = window.event.srcElement.id;
	} else {
		tgtId = eventObj.target.id;
	}
	rexp = document.getElementById(tgtId).value;
	if(rexp == null || rexp == '') {
		return found;
	}
	rexp = LTrim(RTrim(rexp));
	var pat = new RegExp(rexp.toUpperCase());
	var tStr = "", len = rexp.length;
	// modify the display content as per regular expression matching string
	var table = document.getElementById(divName+"Tbl");
	var row, col;
	for (var i = 0; table != null && (row = table.rows[i]); i++) {
	   //iterate through rows
	   //rows would be accessed using the "row" variable assigned in the for loop
	   for (var j = 0; (col = row.cells[j]); j++) {
		   //iterate through columns
		   //columns would be accessed using the "col" variable assigned in the for loop
		   aStr = col.innerHTML;
		   var vAry = aStr.split("&nbsp;");
		   tStr = LTrim(RTrim(vAry[0]));
		   if(tStr.length == 0) 
			   continue;
		   if(tStr.length > len) {
			   tStr = tStr.substring(0, len);
		   }
		   t = pat.test(tStr);
		   
		   if(t) {
			   found = true;
			   col.style.display = 'block';
			   showdiv(divName);
		   } else {
			   // remove the items from response div display
			   col.style.display = 'none';
		   }
	   }
	}// end of rows for loop
	return found;
}


/**
 * This function is used to submit an ajax action. This method takes path and
 * division names as parameter.
 */
function submitCommonAjaxAction(path, lookupId, divName) {
	var	divWidth = "100%";
	var vHeight = "30%";
	// set the given lookupId to submit in ajax action
	selectedIds = lookupId;

	ajaxCommonActionSubmit(path, divName, divWidth, vHeight);
}// end of submitCommonAjaxAction(?, ?);

/**
 * This function is used to submit an ajax action. This method takes path and
 * division names as parameter.
 */
function submitAjaxAction(path, divName) {
	var	divWidth = "100%";
	var vHeight = "30%";

	ajaxCommonActionSubmit(path, divName, divWidth, vHeight);
}// end of submitAjaxAction(?, ?);

/**
 * This function is used to submit an ajax action. This method takes path and
 * division names as parameter.
 */
function submitAjaxActionDefaultWidth(path, divName) {
	vHEIGHT = "100%";
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, vHEIGHT);
}// end of submitAjaxActionDefaultWidth(?, ?);


function showLoadingTxt(vHeight, divWidth, divName) {
	var pgr = document.getElementById('progressBarDiv');
	if(pgr != null 
			&& pgr.style.display == 'block') {
		return false;
	}
	$(divName).innerHTML = "<span class='loadingBgClr'>Loading...</span>";
	$(divName).style.overflow = 'auto';
	$(divName).style.height = vHeight;
	$(divName).style.width = divWidth;
	$(divName).style.position = divPosition;
	showdiv(divName);
}


// this method is used to process the add product details action
function processCommonAjaxResponse(response, divName, vWidth, vHeight) {
	
	if('LoadLinkTicketDiv' == divName){
		return true;
	}
	if(document.getElementById("progressBarDiv") != null) {
		hidediv("progressBarDiv");
	}
	$(divName).show();	
	
	divPosition='relative';
}// end of processCommonAjaxResponse();
/** *******************************  ******************************* **/
/** **************** COMMON AJAX actions ends here ***************** **/
/** *******************************  ******************************* **/
/**
 * This method is used to set the sort details of the a form, and calls the ajax
 * action submit method.
 */
function ajaxSort(path, sortId,  divName) {
	
	var previousId = document.getElementById("sortId").value;
	var previousOrder = document.getElementById("sortOrder").value;
	var nextId = sortId;
	var nextOrder = "ASC";
	
	if ((previousId != null) && (previousId == nextId)) {
		if ((previousOrder != null) && (previousOrder == "ASC")) {
			nextOrder = "DESC";
		} else {
			nextOrder = "ASC";
		}
	}
	
	// set the required parameters.
	parameter1 = nextId;
	parameter2 = nextOrder;
	
	if(document.getElementById("startIndex") != null) {
		// set the start index
		startIndexValue = document.getElementById("startIndex").value;
	} else {
		startIndexValue = "0";
	}
	
	// submit the pagination action to get the next page.
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	
}// end of ajaxSort()

/**
 * Ajax function to get the next page based on the index value.
 * 
 * @param path --
 *            the action path that needs to be submited
 * @param indexVal --
 *            the starting inedex value where the page starts
 * @param divName --
 *            division name
 */
function ajaxGotoIndex(path, indexVal, divName) {
	// get the start index value.
	startIndexValue = indexVal;

	// submit the pagination action to get the next page.
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	
}// end of ajaxGotoIndex()

/**
 * Ajax function to get the next page based on the index value.
 * 
 * @param path --
 *            the action path that needs to be submited
 * @param indexVal --
 *            the starting inedex value where the page starts
 * @param divName --
 *            division name
 */
function ajaxGotoNext20PageIndex(path, indexVal, next20page, divName) {
	// get the start index value.
	startIndexValue = indexVal;
	parameter1 = next20page;
	
	// submit the pagination action to get the next page.
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	
}// end of ajaxGotoIndex()

/*
 * This function used for paging based on the start index
 */
function ajaxGotoNext20Index(startIdx, path, divName) {
	if (startIdx.length < 1) {
		startIdx = 0;
	}
	// next 20 page value as start index value
	parameter1 = startIdx;
	// set the start index value
	startIndexValue = (startIdx - 1) * 10;
	// submit the ajax action
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

/*
 * This function used for paging based on the start index
 */
function ajaxGotoPrevious20Index(startIdx, path, divName) {
	if (startIdx.length < 1) {
		startIdx = 0;
	}
	// set next 20 page value with new value
	parameter1 = startIdx - 19;
	// set the start index value
	startIndexValue = (startIdx - 20) * 10;
	// submit the ajax action
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	
}
/** ************************************************************************** **/


/**
 * Function to replace all single quotes back
 */
function replaceAllSingleQuotes(str2Replace) {
	while(str2Replace.search("###") != -1) {
		str2Replace = str2Replace.replace("###", "\'");
	}
	return str2Replace;
}

//function to test the value is empty or not
function isEmpty(val) {
	if(val == '' || val.length < 1) {
		return true;
	}
	return false;
}// end of is empty function.

function hideDivision(divName) {
	
	if($(divName) == null || $(divName) == "") {
		return false;
	}

 	if ($(divName).style.display == 'block' || $(divName).style.display == '') {
			// hide the given form
			$(divName).style.display = 'none';
	}
 	//////////////////////////////////////////////
 	// get all the elements within the division.
 	var childNodeArry = $(divName).childNodes;
	for (var i = 0; i < childNodeArry.length; i++) {
		if(childNodeArry[i].id != null ||  childNodeArry[i].id != "") {
			// remove elements in the division.
			if(childNodeArry[i].parentNode != null)
				childNodeArry[i].parentNode.removeChild(childNodeArry[i]);
		}
	}
	
}// end of hideDivision() method

function showdiv(id) {
	if(document.getElementById(id) == null) {
		return false;
	}
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'block';
	} else {
		if (document.layers) { // Netscape 4
			document.id.display = 'block';
		} else { // IE 4
			document.all.id.style.display = 'block';
		}
	}
}

function hidediv(id) {
	if(document.getElementById(id) == null) {
		return false;
	}
	if (document.getElementById) { // DOM3 = IE5, NS6
		document.getElementById(id).style.display = 'none';
	} else {
		if (document.layers) { // Netscape 4
			document.id.display = 'none';
		}
		else { // IE 4
			document.all.id.style.display = 'none';
		}
	}
}

function isRadioButtonChecked(formObj) {
	var inputArray = document.getElementsByTagName("input");
	var size = inputArray.length;
	var checked = false;
	for (var j=0; j < size;j++) {
		if (inputArray[j].type == "radio") {
			checked = inputArray[j].checked;
			if(checked == true) {
				return checked;
			}
		}
	}// end of for loop
	return checked;
}// end of checkRadioChecked()

function showProgressBar(divName, bgDiv) {
	var waitDisplayDiv = document.getElementById(divName); // progress bar division
	if(waitDisplayDiv == null) { return false; } 
	waitDisplayDiv.style.left = (document.body.clientWidth/2) - 200;
	waitDisplayDiv.style.display = '';
	document.body.scrollTop = 0;
  
	showBackground(bgDiv);
}

function showBackground(bgDivName) {
	var waitDiv = document.getElementById(bgDivName); // background Division
    if (! document.body) {
      	waitDiv.style.height = 100;
      	waitDiv.style.width = 200;
    } else {
		waitDiv.style.height = document.body.clientHeight;
		waitDiv.style.width = document.body.clientWidth;
    }
    waitDiv.style.display = '';
    document.body.scrollTop = 0;
}


function getVersionList(val,path,divName){
	selectedIds = LTrim(RTrim(val));
	submitAjaxAction(path,divName);
}

function setVersionList(val,divName) {
	document.getElementById("versionNo").value = val;
	hideDivision(divName);
}

function setRowDataFromAjaxDiv(charCode, divName, txtIdDest, txtObjSrc, txtNameDest) {
	
	var currentIdenx = document.getElementById("currentIndex").value;
	if(document.getElementById("maxSize") == null || document.getElementById("maxSize").value == "") {
		// alert("Property \"maxSize\" is not defined.");
		return false;
	} 
		
	var maxSize = parseInt(document.getElementById("maxSize").value);
	if(maxSize == 0) {
		alert("Property \"maxSize\" value not set.");
		return false;
	}
	var curIdx;
	
	if(currentIdenx == null || currentIdenx == "") {
		curIdx = -1; 
	} else {
		curIdx = parseInt(currentIdenx);
	}
	
	
	if(charCode == '40') {
		curIdx = ++curIdx;
	} else { 
		curIdx = --curIdx;
	}
	
	if(curIdx >= maxSize) {	
		curIdx = --curIdx;
	} else if (curIdx < 0)  {
		curIdx = 0;
	}
	
	document.getElementById("currentIndex").value = curIdx;
	if(document.getElementById(("ajxId_" + curIdx)) == null) {
		return false;
	}
	document.getElementById(txtIdDest).value = document.getElementById(("ajxId_" + curIdx)).value;
	if(txtNameDest != "") {
		document.getElementById(txtNameDest).value = document.getElementById(("ajxName_" + curIdx)).value;
//		document.getElementById(txtNameDest).focus();
	}
	txtObjSrc.value = document.getElementById(("ajxCode_" + curIdx)).value;
}

function populateTextBoxValues(id, codeVal, nameVal, divName) {
	var txtIdDestName = document.getElementById("txtIDSrc").value;
	var txtCodeDestName = document.getElementById("txtCodeSrc").value;
	var txtNameDestName = "";
	
	if(document.getElementById("txtNameSrc") != null) {
		txtNameDestName = LTrim(document.getElementById("txtNameSrc").value);
	}
	
	document.getElementById(txtIdDestName).value = id;
	document.getElementById(txtCodeDestName).value = codeVal;
	
	if(txtNameDestName != "" && txtNameDestName.length > 0 && document.getElementById(txtNameDestName) != null) {
		document.getElementById(txtNameDestName).value = nameVal;
	} else {
		document.getElementById(txtCodeDestName).focus();
	}
	hideDivision(divName);
}

function defaultToCurrentIdexValue(curIdx, txtCodeSrc, txtIdDest, txtNameDest, divName) {

	var txtObjSrc = document.getElementById(txtCodeSrc);
	curIdx = getCurrentIndex(curIdx, divName);
	if(document.getElementById(("ajxId_" + curIdx)) == null || txtObjSrc.value == "") {
		return false;
	}
	
	
	if(document.getElementById(txtIdDest).value != "") {
		return false;
	}
	document.getElementById(txtIdDest).value = document.getElementById(("ajxId_" + curIdx)).value;
	txtObjSrc.value = document.getElementById(("ajxCode_" + curIdx)).value;
	
	if(txtNameDest != "" && document.getElementById(txtNameDest) != null) {
		document.getElementById(txtNameDest).value = document.getElementById(("ajxName_" + curIdx)).value;
//		document.getElementById(txtNameDest).focus();
	}
	hideDivision(divName);
}

function isNonFnKeyPress(charCode) {
	var intCode = parseInt(charCode);
	if((intCode >= _Z0 && intCode <= _N9)
			|| (intCode >= _A && intCode <= _Z)
			|| intCode == _SPC || intCode == _BSPC)
		return false;
	return true;
}
function isNOajaxAction(txtCodeSrc, txtNameDest, lenChek) {
	var length = 0;
	var ob = document.getElementById(txtCodeSrc);
	if(ob != null) {
		length = ob.value.length;
	}
	if(length == 0) {
		ob = document.getElementById(txtNameDest);
		if(ob != null)
			length = ob.value.length;
	}
	if(lenChek == ""){lenChek = 2;}
	if(length == 0 || length < lenChek){return true;}
	return false;
}
function commonAutoCompleteAction(path, txtIdDest, txtCodeSrc, txtNameDest, eventObj, divName) {
	
	var txtObjSrc = document.getElementById(txtCodeSrc);
	var lookupId = txtObjSrc.value;
	
	var charCode = (eventObj.which) ? eventObj.which : event.keyCode;
	if(charCode == _TAB || charCode == _ETR) {
		var idVal = document.getElementById(txtIdDest).value;
		if(idVal == "")
			setTextValuesByIndex(0, txtIdDest, txtCodeSrc, txtNameDest, '', divName);
		return true;
	} else if(charCode == _ESC) {
		document.getElementById(txtIdDest).value = "";
		document.getElementById(txtCodeSrc).value = "";
		document.getElementById(txtNameDest).value = "";
		hideDivision(divName);
		return false;
	} else if((charCode != _BSPC && charCode != _DEL) && isNonFnKeyPress(charCode)) {
		return false;
	}
	document.getElementById(txtIdDest).value = "";
	if(isNOajaxAction(txtCodeSrc, txtNameDest, refreshInt)) {
		return false;
	}
	// set the given lookupId to submit in ajax action
	selectedIds = lookupId;// 
	if(path.indexOf("?") > 0) {
		path += "&";
	} else {
		path += "?";
	}
	path = path + "txtIDSrc=" +  txtIdDest
			+ "&txtCodeSrc=" + txtObjSrc.name
			+ "&txtNameSrc=" + txtNameDest
	;
	var vWIDTH = "200px", vHEIGHT = "30%";
	divPosition='absolute';
	if(respHandlerAjaxJS(txtIdDest, txtCodeSrc, txtNameDest, eventObj, divName)) {
		return false;
	}
	// submit ajax action to set the states list.
	ajaxCommonActionSubmit(path, divName, vWIDTH, vHEIGHT); 
}// end of commonAutoCompleteAction()

function populateTextMoreValues(indx, divName) {
	var txtIdDest = document.getElementById("txtIDSrc").value;
	var txtCodeSrc = document.getElementById("txtCodeSrc").value;
	var txtNameDest = document.getElementById("txtNameSrc").value;
	var otherNames = document.getElementById("otherNames").value;
	setTextValuesByIndex(indx, txtIdDest, txtCodeSrc, txtNameDest, otherNames, divName);
}
function setTextValuesByIndex(curIdx, txtIdDest, txtCodeSrc, txtNameDest, otherNames, divName) {
	var txtObjSrc = document.getElementById(txtCodeSrc);
	curIdx = getCurrentIndex(curIdx, divName);
	document.getElementById(txtIdDest).value = document.getElementById(("ajxId_" + curIdx)).value;
	if(txtNameDest != "") {
		document.getElementById(txtNameDest).value = document.getElementById(("ajxName_" + curIdx)).value;
	}
	txtObjSrc.value = document.getElementById(("ajxCode_" + curIdx)).value;
	if(otherNames.length > 0) {
		if(otherNames.indexOf(",") > 0) {
			otherNameArray = otherNames.split(",");
			otherValueArray = (document.getElementById(("ajxOthers_" + curIdx)).value).split(",");
			for(var j = 0; j < otherNameArray.length; j++) {
				if(document.getElementById(otherNameArray[j]) != null) {
					document.getElementById(otherNameArray[j]).value = otherValueArray[j];
				}
			}
		} else {
			if(document.getElementById(otherNames) != null) {
				document.getElementById(otherNames).value = document.getElementById(("ajxOthers_" + curIdx)).value;
			}
		}
	}
	hideDivision(divName);
}
function manyParamsAutoCompleteAction(path, txtIdDest, txtCodeSrc, txtNameDest, otherNames, eventObj, divName) {
	
	var txtObjSrc = document.getElementById(txtCodeSrc);
	var charCode = (eventObj.which) ? eventObj.which : event.keyCode;
	if(charCode == _TAB || charCode == _ETR) {
		var idVal = document.getElementById(txtIdDest).value;
		if(idVal == "")
			setTextValuesByIndex(0, txtIdDest, txtCodeSrc, txtNameDest, otherNames, divName);
		return false;
	} else if(charCode == _ESC) {
		document.getElementById(txtIdDest).value = "";
		document.getElementById(txtCodeSrc).value = "";
		document.getElementById(txtNameDest).value = "";
		hideDivision(divName);
		return false;
	} else if(isNonFnKeyPress(charCode)) {
		return false;
	}
	document.getElementById(txtIdDest).value = "";
	
	if(path.indexOf("?") > 0) {
		path += "&";
	} else {
		path += "?";
	}
	path = path + "txtIDSrc=" +  txtIdDest
			+ "&txtCodeSrc=" + txtObjSrc.name
			+ "&txtNameSrc=" + txtNameDest
			+ "&otherNames=" + otherNames
	;
	var vWIDTH = "960px", vHEIGHT = "30%";
	divPosition='absolute';
	// submit ajax action to set the states list.
	ajaxCommonActionSubmit(path, divName, vWIDTH, vHEIGHT); 
}// end of manyParamsAutoCompleteAction()
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function getSelectedRadio(buttonGroup) {
   // returns the array number of the selected radio button or -1 if no button is selected
   if (buttonGroup[0]) { // if the button group is an array (one button is not an array)
      for (var i=0; i<buttonGroup.length; i++) {
         if (buttonGroup[i].checked) {
            return i;
         }
      }
   } else {
      if (buttonGroup.checked) { return 0; } // if the one button is checked, return zero
   }
   // if we get to this point, no radio button is selected
   return -1;
} // Ends the "getSelectedRadio" function

function getSelectedRadioValue(buttonGroup) {
   // returns the value of the selected radio button or "" if no button is selected
   var i = getSelectedRadio(buttonGroup);
   if (i == -1) {
      return "";
   } else {
      if (buttonGroup[i]) { // Make sure the button group is an array (not just one button)
         return buttonGroup[i].value;
      } else { // The button group is just the one button, and it is checked
         return buttonGroup.value;
      }
   }
   return "";
} // Ends the "getSelectedRadioValue" function

function getBookingPlacesList(path, eventObj, divName, txtIdDest, txtCodeSrc, txtNameDest) {
	path = path + "&startPlaceId=" + document.getElementById("startPlaceId").value;
	commonAutoCompleteAction(path, txtIdDest, txtCodeSrc, txtNameDest, eventObj, divName);
}

function getAvailableServiceList(actType, searchType) {
	DIV_DEFAULT_WIDTH = "100%";
	var paramStr = "";
	showdiv("progressBarDiv");
	paramStr = "?txtJourneyDate=" + document.getElementById("txtJourneyDate").value
	;
	var divName = "ForwardAvailableServicesDiv";
	if(actType == '1') {
		path = "/return/booking/avail/services.do";
		// return journey parameters
		paramStr = paramStr 
					+ "&startPlaceId=" + document.getElementById("endPlaceId").value
					+ "&endPlaceId=" + document.getElementById("startPlaceId").value
					+ "&txtReturnJourneyDate=" + document.getElementById("txtReturnJourneyDate").value
					+ "&ajaxAction=ret"
					
				;
		divName = "ReturnAvailableServicesDiv";
	} else {
		// forward journey parameters
		path = "/forward/booking/avail/services.do";
		paramStr = paramStr
				+ "&startPlaceId=" + document.getElementById("startPlaceId").value
				+ "&endPlaceId=" + document.getElementById("endPlaceId").value
				+ "&txtLinkJourneyDate=" + document.getElementById("txtLinkJourneyDate").value
				+ "&ajaxAction=fw"
				;
	}
	if(document.getElementById("covidBkgEnable"))
		paramStr= paramStr	+ "&covidBkgEnable=" + document.getElementById("covidBkgEnable").value
		
	path = path + paramStr + "&qryType=" + searchType;
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function getBookingSearchType() {
	var searchType = "";
	if(document.getElementById("searchType") != null) {
		searchType = document.getElementById("searchType").value;
	} else if(document.getElementById("searchType_1").checked == true) {
		searchType = document.getElementById("searchType_1").value;
	} else if(document.getElementById("searchType_2").checked == true) {
		searchType = document.getElementById("searchType_2").value;
	} else if(document.getElementById("searchType_3") != null) {
		searchType = document.getElementById("searchType_3").value;
	}
	return searchType;
}

function ajaxShowBoardingPoints(srid, sid, scId, rtPid, act, idx, ladiesSpecial) {

	if(ladiesSpecial != null && Number(ladiesSpecial) == 1) {
		var conf = confirm("Only Female are allowed for this service to book");
		if(!conf) {
			return false;
		}
	}
	if(document.getElementById("isLinkTicket") != null){
		document.getElementById("isLinkTicket").value = 0;
	}
	if(document.getElementById("startPlaceCode") != null){
		document.getElementById("startPlaceCode").checked = false;
	}
	var path, divName, dt, startId, endId;
	if(act == "Return") {
		divName = "ReturnBoardPtsDiv";
		dt = document.getElementById("txtReturnJourneyDate").value;
		path = "/ajax/return/layout/boardPoints.do?ajaxAction=rt&txtReturnJourneyDate=" + dt;
		startId = document.getElementById("endPlaceId").value;
		endId = document.getElementById("startPlaceId").value;
	} else {
		startId = document.getElementById("startPlaceId").value;
		endId = document.getElementById("endPlaceId").value;
		divName = "ForwardBoardPtsDiv";
		dt = document.getElementById("txtJourneyDate").value;
		path = "/ajax/forward/layout/boardPoints.do?ajaxAction=fw&txtJourneyDate=" + dt;
	}
	
	document.getElementById(act + "ServiceId").value = sid;
	document.getElementById("srvcRtId" + act).value = srid;
	document.getElementById("categoryId" + act).value = scId;
	
	path = path + "&serviceId=" + sid + "&startPlaceId=" + startId  + "&routeCode=" + srid + "&endPlaceId=" + endId + "&serviceCategoryId=" + scId;
	
	var remName = document.getElementById(act).value;
	removeDiv(remName, divName);
	var divTag = createDiv(divName);
    document.getElementById(("Layout" + act + idx)).appendChild(divTag);
    document.getElementById(act).value = ("Layout" + act + idx);
    showdiv("progressBarDiv");
    accomPrice=0;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);	
}

function ajaxShowBoardingPointsTrip(srid, sid, scId, rtPid, act, idx, ladiesSpl,tripId, tripNo,isItimService,cutOffTime) {
	if(document.getElementById("isLinkTicket") != null){
		document.getElementById("isLinkTicket").value = 0;
	}
	if(document.getElementById("startPlaceCode") != null){
		document.getElementById("startPlaceCode").checked = false;
	}
	var path, divName, dt, startId, endId;
	if(act == "Return") {
		divName = "ReturnBoardPtsDiv";
		dt = document.getElementById("txtReturnJourneyDate").value;
		path = "/ajax/return/layout/boardPoints.do?ajaxAction=rt&txtReturnJourneyDate=" + dt;
		if(tripId && tripId != "") {
			path = path+='&tripMasterId='+tripId
		}
		if(tripNo && tripNo != "") {
			path = path+='&tripNo='+tripNo
		}
		startId = document.getElementById("endPlaceId").value;
		endId = document.getElementById("startPlaceId").value;
		if(document.getElementById("retTripNo") != null){
			document.getElementById("retTripNo").value = tripNo;
		}
		if(document.getElementById("returnTripMasterId") != null){
			document.getElementById("returnTripMasterId").value = tripId;
		}
		
		var div = sid+"_departureTime_"+tripNo;
		if(document.getElementById(div) !=  null){
			path = path + "&retDepartTime=" + document.getElementById(div).value;
			if(document.getElementById("ReturnJourneyTime_1") !=  null)
				document.getElementById("ReturnJourneyTime_1").value =  dt+" "+document.getElementById(div).value;
		}
		div = sid+"_departureDay_"+tripNo;
		if(document.getElementById(div) !=  null){
			path = path + "&retDepartureDay=" + document.getElementById(div).value;
			if(document.getElementById("ReturnDepartureDay") !=  null)
				document.getElementById("ReturnDepartureDay").value =  document.getElementById(div).value;
		}
		
	} else {
		startId = document.getElementById("startPlaceId").value;
		endId = document.getElementById("endPlaceId").value;
		divName = "ForwardBoardPtsDiv";
		dt = document.getElementById("txtJourneyDate").value;
		path = "/ajax/forward/layout/boardPoints.do?ajaxAction=fw&txtJourneyDate=" + dt;
		if(tripId && tripId !="") {
			path = path+='&tripMasterId='+tripId
		}
		if(tripNo && tripNo != "") {
			path = path+='&tripNo='+tripNo
		}
		if(document.getElementById("forwardTtripNo") != null){
			document.getElementById("forwardTtripNo").value = tripNo;
		}
		if(document.getElementById("tripMasterId") != null){
			document.getElementById("tripMasterId").value = tripId;
		}
		var div = sid+"_arrivalTime_"+tripNo;
		if(document.getElementById(div) !=  null){
			path = path + "&fwArrivalTime=" + document.getElementById(div).value;
			if(document.getElementById("ForwardJourneyTime_2") !=  null)
				document.getElementById("ForwardJourneyTime_2").value =  dt+" "+document.getElementById(div).value;
		}
		div = sid+"_arrivalDay_"+tripNo;
		if(document.getElementById(div) !=  null){
			path = path + "&fwArrivalDay=" + document.getElementById(div).value;
			if(document.getElementById("ForwardArrivalDay") !=  null)
				document.getElementById("ForwardArrivalDay").value =  document.getElementById(div).value;
		}
	}
	
	

	
	document.getElementById(act + "ServiceId").value = sid;
	document.getElementById("srvcRtId" + act).value = srid;
	document.getElementById("categoryId" + act).value = scId;
	
	path = path + "&serviceId=" + sid + "&startPlaceId=" + startId  + "&routeCode=" + srid + "&endPlaceId=" + endId + "&serviceCategoryId=" + scId
	+ "&isItimService=" + isItimService + "&cutOffTime=" + cutOffTime ;
	
	var remName = document.getElementById(act).value;
	removeDiv(remName, divName);
	var divTag = createDiv(divName);
    document.getElementById(("Layout" + act + idx)).appendChild(divTag);
    document.getElementById(act).value = ("Layout" + act + idx);
    showdiv("progressBarDiv");
    accomPrice=0;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);	
}




function displayLayoutDiv(actName) {
	
	if(actName == 'Forward'){
		showdiv('ShowLayoutDiv');
	} else {
		showdiv('ShowReturnLayoutDiv');
	}
	
	var ajaxAction = "fw";
	var path = "/ajax/forward/layout/view.do?ajaxAction=" + ajaxAction;
	var journeyDate = document.getElementById("txtJourneyDate").value;
	var adultMale = 0, adultFemale = 0, childMale = 0, childFemale = 0;
	var stockNo = "", concessionId = "", srvcTypeCatgId = "";
	var divName = "ShowLayoutDiv";
	
	// Calling the function to get the singlelady Enabled or not
	var singleLady = getSingleLady();
	
	if(document.getElementById("ShowLayoutDiv") && document.getElementById("ShowLayoutDiv").style.display == "none"){
		document.getElementById("ShowLayoutDiv").style.display = "";
	}
	var sid = document.getElementById(actName + "ServiceId").value;
	var srid = document.getElementById("srvcRtId" + actName).value;
	var boardId = "", dropId = "";
	var t, searchType ;
	var tripNo;
	var isLinkEndBooking = "";
	if(document.getElementById("isLinkEndBooking") != null && document.getElementById("isLinkEndBooking").value == 1){
		//journeyDate = document.getElementById("txtJourneyDate").value;
		//retJourneyDate = document.getElementById("txtJourneyDate").value;
		isLinkEndBooking = document.getElementById("isLinkEndBooking").value;
		retJourneyDate = document.getElementById("txtReturnJourneyDate").value;
	}
	
	if(document.getElementById("txtReturnJourneyDate") != null)
		t = document.getElementById("txtReturnJourneyDate").value;
		
	
	if(t =! null && t != "" && t != "For Roundtrip" && validateDate(t)) {
		searchType = '1';
	} else {
		searchType = "0";
	}
	var isLinkStartBooking = '';
	var isLinkTicket = 0, linkPlaceId = 0, linkStartPlaceId = 0, linkEndPlaceId = 0;
	if(document.getElementById("isLinkTicket") != null)
		isLinkTicket = document.getElementById("isLinkTicket").value;
	if(actName == "Return") {
		boardId = document.getElementById(actName + "BoardId").value;
		dropId = document.getElementById(actName + "DroppingId").value;
		if(document.getElementById("linkPlaceIdRet") != null)
			linkPlaceId = document.getElementById("linkPlaceIdRet").value;
		
		if(document.getElementById("startPlaceId") != null)
			linkStartPlaceId = document.getElementById("startPlaceId").value;
		
		if(document.getElementById("endPlaceId") != null)
			linkEndPlaceId = document.getElementById("endPlaceId").value;
			
		if(document.getElementById("retTripNo") != null){
			tripNo = document.getElementById("retTripNo").value;
		}
		if(document.getElementById("returnTripMasterId") != null){
			tripMasterId = document.getElementById("returnTripMasterId").value;
		}
		
		if(document.getElementById("isLinkEndBooking") != null && document.getElementById("isLinkEndBooking").value == 1){
			if(document.getElementById("linkEndTripNo") != null){
				tripNo = document.getElementById("linkEndTripNo").value;
			}
			if(document.getElementById("linkEndTripMasterId") != null){
				tripMasterId = document.getElementById("linkEndTripMasterId").value;
			}
		}
		
		path = "/ajax/return/layout/view.do?ajaxAction=rt"
				+ "&startPlaceId=" + boardId
				+ "&endPlaceId=" + dropId
				+ "&isLinkTicket=" + isLinkTicket
				+ "&linkPlaceId=" + linkPlaceId
				+ "&linkStartPlaceId=" + linkEndPlaceId
				+ "&linkEndPlaceId=" + linkStartPlaceId
				+ "&tripNo=" + tripNo
				+ "&tripMasterId="+tripMasterId
				;
		
		if(document.getElementById("ForwardJourneyTime_2") != null)
			path = path + "&fwArrivalTime=" +document.getElementById("ForwardJourneyTime_2").value;
		if(document.getElementById("ForwardArrivalDay") != null)
			path = path + "&fwArrivalDay=" +document.getElementById("ForwardArrivalDay").value;
		
    	divName = "ShowReturnLayoutDiv";
    	journeyDate = document.getElementById("txtReturnJourneyDate").value;
    } else {
		boardId = document.getElementById(actName + "BoardId").value;
		dropId = document.getElementById(actName + "DroppingId").value;
		if(document.getElementById("linkPlaceId") != null)
			linkPlaceId = document.getElementById("linkPlaceId").value;
		
		if(document.getElementById("startPlaceId") != null)
			linkStartPlaceId = document.getElementById("startPlaceId").value;
		
		if(document.getElementById("endPlaceId") != null)
			linkEndPlaceId = document.getElementById("endPlaceId").value;
			
		if(document.getElementById("forwardTtripNo") != null){
			tripNo = document.getElementById("forwardTtripNo").value;
		}
		if(document.getElementById("forwardTtripNo") != null){
			tripMasterId = document.getElementById("forwardTtripNo").value;
		}
		
		if(document.getElementById("isLinkStartBooking") != null ){
			isLinkStartBooking = document.getElementById("isLinkStartBooking").value;
		}
		
		if(isLinkStartBooking != null && isLinkStartBooking == 1){
			searchType = 0;
			var dateNextJourney = journeyDate;
			if(document.getElementById("linkForwardDepartureTime") != null
					&& document.getElementById("linkForwardDepartureTime").value != ''
					&& document.getElementById("journeyForwardDurationTime") != null
					&& document.getElementById("journeyForwardDurationTime") != ''){
				var dptTime = journeyDate+document.getElementById("linkForwardDepartureTime").value;
				var jrDurationFwd = document.getElementById("journeyForwardDurationTime").value;
				var nextDate = getNextJourneyDate(dptTime, jrDurationFwd);
			}
			 document.getElementById("txtReturnJourneyDate").value = nextDate;
		}
		
		path = path + "&endPlaceId=" + dropId
					+ "&startPlaceId=" + boardId
					+ "&isLinkTicket=" + isLinkTicket
					+ "&linkPlaceId=" + linkPlaceId
					+ "&linkStartPlaceId=" + linkStartPlaceId
					+ "&linkEndPlaceId=" + linkEndPlaceId
					+ "&tripNo=" + tripNo
					+ "&tripMasterId="+tripMasterId
					+ "&isLinkStartBooking="+isLinkStartBooking
					;
	}
	var retJourneyDate = "";
	if(document.getElementById("txtReturnJourneyDate") != null)
		retJourneyDate = document.getElementById("txtReturnJourneyDate").value;
	if(retJourneyDate == null || retJourneyDate == "" || retJourneyDate == "For Roundtrip") {
		retJourneyDate = "";
	}
	if(document.getElementById("concessionId") != null)
		concessionId = document.getElementById("concessionId").value;
		
	if(document.getElementById("serviceCategoryId") != null)
		srvcTypeCatgId = document.getElementById("serviceCategoryId").value;
	
	if(boardId == null || boardId == "") {
		alert("Please select boarding point to continue.");
		return false;
	}
	if(dropId == null || dropId == "") {
		alert("Please select dropping point to continue.");
		return false;
	}
	if(concessionId == null || concessionId == "") {
		alert("Please select a concession to continue.");
		return false;
	}
	var forwardDynMap = "";
	var returnDynMap = "";
	if(document.getElementById("forwardDynFareDetails") != null){
		forwardDynMap = document.getElementById("forwardDynFareDetails").value;
	}
	if(document.getElementById("returnDynFareDetails") != null){
		returnDynMap = document.getElementById("returnDynFareDetails").value;
	}
	var layoutId = "";
	var returnLayoutId = "";
	if(document.getElementById("layoutId") != null){
		layoutId = document.getElementById("layoutId").value;
	}
	if(document.getElementById("returnLayoutId") != null){
		returnLayoutId = document.getElementById("returnLayoutId").value;
	}
	
	if(document.getElementById("isLinkEndBooking") != null && document.getElementById("isLinkEndBooking").value == 1){
		journeyDate = document.getElementById("txtReturnJourneyDate").value;
		retJourneyDate = document.getElementById("txtReturnJourneyDate").value;
	}

	showdiv("progressBarDiv");

	var linkForwardArrivalTimeStr = '';
	if(document.getElementById('linkForwardArrivalTimeStr') != null){
		linkForwardArrivalTimeStr = document.getElementById('linkForwardArrivalTimeStr').value;
	}
	
	if(document.getElementById(sid+"_departureDay_"+tripNo) != null) {
		path = path + "&departureDay=" + document.getElementById(sid+"_departureDay_"+tripNo).value
	}
	
    path = path + "&searchType=" + searchType
			+ "&concessionId=" + concessionId
    		+ "&serviceCategoryId=" + document.getElementById("categoryId" + actName).value
    		+ "&serviceId=" + document.getElementById(actName + "ServiceId").value
    		+ "&txtJourneyDate=" + journeyDate
    		+ "&txtReturnJourneyDate=" + retJourneyDate
    		+ "&srvcTypeCatgId=" + srvcTypeCatgId
    		+ "&layoutId=" + layoutId
    		+ "&returnLayoutId=" + returnLayoutId
    		+ "&singleLady=" + singleLady
    		+ "&isLinkEndBooking=" + isLinkEndBooking
			+ "&linkForwardArrivalTimeStr="+linkForwardArrivalTimeStr;

    if(document.getElementById("covidBkgEnable") != null) {
    	path = path+ "&covidBkgEnable="+document.getElementById("covidBkgEnable").value;
    }
    if(document.getElementById("maxDiscountAvail") != null) {
    	path = path+ "&maxDiscountAvail="+document.getElementById("maxDiscountAvail").value;
    }
    ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function showCancellServices() {
	var path = '/ajax/cancel/services/load.do?txtJourneyDate='
		+ document.getElementById('txtJourneyDate').value; 
	var divName = 'CancelledServiceDivId';
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function showCancellTicketsPage(val, mob,uid, rjc, rDivs) {
	var path = '/ajax/cancel/details/load.do'; 
	var divName = 'BookedTicketsDivId';
	if(document.getElementById("id") != null) {
		document.getElementById("id").value = val;
	}
	path = path + "?searchType=0"
				+ "&id=" + val
				+ "&mobileNo=" + mob
				+ "&uidNumber=" + uid
	if(rjc) {
		path += "&returnId=" + document.getElementById(rDivs+"returnId").value
			 + "&returnUidNumber=" + document.getElementById(rDivs+"returnUidNumber").value
		     + "&returnMobileNo=" + document.getElementById(rDivs+"returnMobileNo").value
		     + "&returnJourney=1";
	}
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function showTicketDetailsPage(divName) {
	var txtJourneyDate = "";
	if(document.getElementById("txtJourneyDate") != null)
		txtJourneyDate = document.getElementById("txtJourneyDate").value;
	var path = "/ajax/ticket/alter/load.do?searchType=0&id=" + document.getElementById("id").value
		+ "&stockKey=" + document.getElementById("stockKey").value
		+ "&stockNumber=" + document.getElementById("stockNumber").value
		+ "&txtJourneyDate=" + txtJourneyDate
	;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function getRefundDetailsWithRJT(divName, noOfJrnys) {
	var bookingType = 0;
	var returnSeats="", returnMPrice="", returnQty="", returnMobile="", returnUid="", returnId;
	var onwardSeats="", onwardMPrice="", onwardQty="", onwardMobile="", onwardUid="";
	while(bookingType < noOfJrnys){
	var i=0; 
	var obj = null, mPrice = "", qty = "";
	var ob = null, seats = "";
	var uid = "";
	var mobile = "";
	var typStr = "";
	
	if(bookingType==1){
		typStr = 'ret';
	}
	
	while(true) {
		obj = document.getElementById(typStr+"mPrice"+i);
		if(obj == null) break;
		if(i > 0) {mPrice += ","; qty += ",";}
		mPrice += obj.value;
		qty += document.getElementById(typStr+"mQty"+i).value;
		i++;
	}
	i=0;
	while(true) {
		ob = document.getElementById(typStr+"seatNos" + i);
		if(ob == null) break;
		else if(ob.checked == true) {
			if(seats.length > 0) seats += ",";
			seats += ob.value;
		}
		i++;
	}
 
	document.getElementById(typStr+"seatNosForward").value = seats;
	
	if(document.getElementById(typStr+"uidNumber") != null) {
		uid = document.getElementById(typStr+"uidNumber").value ;
	}
	if(document.getElementById(typStr+"mobileNo") != null) {
		mobile = document.getElementById(typStr+"mobileNo").value ;
	}
	var isPartial =0;
	if(document.getElementById("isPartialTkt") != null) {
		isPartial = document.getElementById("isPartialTkt").value ;
	}
	if(seats.length == 0 && isPartial != 1) {
		alert("Atleast one seat must be selected from onward and return for cancellation.");
		seats = document.getElementById(typStr+"seatNos0").value;
		document.getElementById(typStr+"seatNos0").checked = true;
		return false;
	}
	document.getElementById("seatNosForward").value = seats;

	if(bookingType == 1){
		returnSeats = seats;
		returnQty=qty;
		returnMPrice=mPrice;
		returnUid=uid;
		returnMobile=mobile;
		returnId=document.getElementById("returnId").value;
		returnUid=document.getElementById("returnUidNumber").value
		returnMobile=document.getElementById("returnMobileNo").value
		
	} else {
		onwardSeats=seats;
		onwardMPrice=mPrice;
		onwardQty=qty;
		onwardMobile=mobile;
		onwardUid=uid;
	}
	bookingType++;
	}
	if(bookingType == 2 && returnSeats != null && isPartial != 1){
		var returnSeats = returnSeats.split(",");
		var onwardSeats = onwardSeats.split(",");
		if(returnSeats.length != onwardSeats.length){
			alert("Onward journey selected seats and Return journey selected seats should equals");
			return false;
		}
	}
	var path = "/ticket/cancel/refund/calc/rjt.do?searchType=1"
		+ "&id=" + document.getElementById("id").value
		+ "&seats=" + onwardSeats
		+ "&mPricLs=" + onwardMPrice
		+ "&mSelQty=" + onwardQty
		+ "&showLayout=false"
		+ "&uidNumber=" + document.getElementById("uidNumber").value
		+ "&mobileNo=" + document.getElementById("mobileNo").value
		+ "&returnId=" + returnId
		+ "&returnSeats=" + returnSeats
		+ "&returnMPricLs=" + returnMPrice
		+ "&returnMSelQty=" + returnQty
		+ "&returnShowLayout=false"
		+ "&returnUidNumber=" + returnUid
		+ "&returnMobileNo=" + returnMobile
	;
	
	if(document.getElementById('PgwRefundAmountId')!=null){
		document.getElementById('PgwRefundAmountId').innerHTML='';
	}
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	showdiv(divName);
}

function getRefundDetails(divName) {
	var i=0; 
	var obj, mPrice = "", qty = "";
	while(true) {
		obj = document.getElementById("mPrice"+i);
		if(obj == null) break;
		if(i > 0) {mPrice += ","; qty += ",";}
		mPrice += obj.value;
		qty += document.getElementById("mQty"+i).value;
		i++;
	}
	i=0;
	var ob, seats = "";
	while(true) {
		ob = document.getElementById("seatNos" + i);
		if(ob == null) break;
		else if(ob.checked == true) {
			if(seats.length > 0) seats += ",";
			seats += ob.value;
		}
		i++;
	}
	if(seats.length == 0) {
		alert("Atleast one seat must be selected for partial cancellation.");
		seats = document.getElementById("seatNos0").value;
		document.getElementById("seatNos0").checked = true;
	} 
	document.getElementById("seatNosForward").value = seats;
	
	var uid = "";
	if(document.getElementById("uidNumber") != null) {
		uid = document.getElementById("uidNumber").value ;
	}
	var mobile = "";
	if(document.getElementById("mobileNo") != null) {
		mobile = document.getElementById("mobileNo").value ;
	}
	var path = "/ticket/cancel/refund/calc.do?searchType=1"
		+ "&id=" + document.getElementById("id").value
		+ "&seats=" + seats
		+ "&mPricLs=" + mPrice
		+ "&mSelQty=" + qty
		+ "&showLayout=false"
		+ "&uidNumber=" + uid
		+ "&mobileNo=" + mobile
	;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	showdiv(divName);
}
function showStaffDetailDiv(counterId) {
	var roleId = document.getElementById("roleId").value;
	var path = '/ajax/booking/counters/load.do?blockedType=1';
	if(roleId == 1002) {
		path = path + "&roleId=" + roleId 
				    + "&counterId=" + counterId;
		// enable this code when counter's is in use
		// submitAjaxAction(path, 'CountersDivId');
		showdiv("agentDetailsDivId");
	} else {
		hidediv("agentDetailsDivId");
	}
}
function validateFields(srcName, path, divId) {
	var srcObj = document.getElementById(srcName);
	if(path.indexOf("?") > 0) {
		path += "&";
	} else {
		path += "?";
	}
	path = path + srcName + "=" + srcObj.value;
	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

/* ************************** JQUERY Realted calls ************************** */
   /**
    * This function is used to take the divisiotn width, height as parameter along
    * with the path, division name. This function can be used for all types of ajax
    * action with six parameters, (can be extended in future if required).
    */
function ajaxCommonActionSubmit(path, divName, divWidth, vHeight) {
   	divPosition = 'relative';
   	//showLoadingTxt(vHeight, divWidth, divName);   	
   	
   	// get context path
   	var contextPath = document.getElementById("contextPath").value;
   	var rNum = new Date().getTime() + Math.floor((Math.random()*100)+1);
   	// form the exact url to be performed
   	var realPath =  contextPath + path + "&X=" + rNum;
   	var actionType = document.getElementById("ajaxAction").value;   	
   	
   	$.ajax({
        url: realPath,
        type: "POST",
        cache: false,
        data: ({parameter1: rNum, 
				parameter2: parameter2,
				actionType: actionType
				}),
        dataType: "html",        
        success: function(data) {
				$('#'+divName).html(data);     
				//request tracking in google-analytics
				ga('send', 'pageview', realPath.substr(0,realPath.indexOf("?")));
				processCommonAjaxResponse(data, divName, divWidth, vHeight);				
			}
   	});

}

function transferWalletMoney(path, divId){
	var mobileNo = '', email = '', walletTranserAmount = '', description  = '';
	var obj = document.getElementById("mobileNo");
	if(obj != null && obj.value != ""){
		mobileNo = obj.value;
		
	}
	obj = document.getElementById("email");
	if(obj != null && obj.value != ""){
		email = obj.value;
		
	}
	obj = document.getElementById("walletTranserAmount");
	if(obj != null && obj.value != ""){
		walletTranserAmount = obj.value;
		if(!isValidNumber(obj)) {
			return false;
		}
	}
	path = path + "?mobileNo=" + mobileNo
				+ "&email=" + email
				+ "&walletTranserAmount=" + walletTranserAmount;
	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function transferWalletMoneyToCopax(path, divId) {
	var mobileNo = '', otp = '', walletTranserAmount = '';
	var obj = document.getElementById("mobileNo");
	if(obj != null && obj.value != ""){
		mobileNo = obj.value;
	}
	
	obj = document.getElementById("walletTranserAmount");
	if(obj != null && obj.value != ""){
		walletTranserAmount = Number(obj.value);
		if(!isValidNumber(obj)) {
			return false;
		}
	}
	path = path + "?mobileNo=" + mobileNo
				+ "&toupCopax="+1
				+ "&walletTranserAmount=" + walletTranserAmount;
	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function validateTransferOTP(divName){
	
	var path = "/ajax/wallet/transfer/generateOTP.do?otpType=2";
	ajaxCommonActionSubmit(path, divName);
}

function pgwAmountAddToWallet(path, divId){
	
	var i=0; 
	var obj, mPrice = "", qty = "";
	while(true) {
		obj = document.getElementById("mPrice"+i);
		if(obj == null) break;
		if(i > 0) {mPrice += ","; qty += ",";}
		mPrice += obj.value;
		qty += document.getElementById("mQty"+i).value;
		i++;
	}
	i=0;
	var ob, seats = "";
	while(true) {
		ob = document.getElementById("seatNos" + i);
		if(ob == null) break;
		else if(ob.checked == true) {
			if(seats.length > 0) seats += ",";
			seats += ob.value;
		}
		i++;
	}
	if(seats.length == 0 && document.getElementById("seatNos0") != null) {
		seats = document.getElementById("seatNos0").value;
		document.getElementById("seatNos0").checked = true;
	} 
	document.getElementById("seatNosForward").value = seats;
	
	var uid = "";
	if(document.getElementById("uidNumber") != null) {
		uid = document.getElementById("uidNumber").value ;
	}
	var mobile = "";
	if(document.getElementById("mobileNo") != null) {
		mobile = document.getElementById("mobileNo").value ;
	}
	var walletRefundAmount = 0,pgwRefundAmount = 0, refundTotalAmount = 0;
	if(document.getElementById("checkPgwRefundToWallet").checked){
		checkPgwRefundToWallet = 1;
	} else {
		checkPgwRefundToWallet = 0;
	}
	path = path + "?searchType=1"
			+ "&id=" + document.getElementById("id").value
			+ "&seats=" + seats
			+ "&mPricLs=" + mPrice
			+ "&mSelQty=" + qty
			+ "&showLayout=false"
			+ "&uidNumber=" + uid
			+ "&mobileNo=" + mobile
			+ "&checkPgwRefundToWallet=" + checkPgwRefundToWallet;
	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}


function cashbackValidation(path,divId){
	var onwardTotalFare = 0.0, totalAmount = 0.0, returnTotalFare = 0.0;
	var calculateCashBackAmt = 0.0;
	
	var onwardTotalFareVal = document.getElementById("totalAmountHid");
	if(onwardTotalFareVal != null){
			onwardTotalFare = onwardTotalFareVal.value;
	}
	
	var retTotalFareVal = document.getElementById("retTotalAmountHid");
	if(retTotalFareVal != null){
		returnTotalFare = retTotalFareVal.value;
			
	}
	totalAmount = parseFloat(onwardTotalFare) + parseFloat(returnTotalFare);
	if(document.getElementById("calculateCashBackAmt") != null)
		calculateCashBackAmt = document.getElementById("calculateCashBackAmt").value;
	
	var cashbackCouponObj = document.getElementById('cashbackCoupon');
	var cashbackCoupon;
	if(cashbackCouponObj != null){
		cashbackCoupon = cashbackCouponObj.value;
	}
	var cashbackCouponObj = document.getElementById('bankRefNo');
	var bankRefNo;
	if(cashbackCouponObj != null){
		bankRefNo = cashbackCouponObj.value;
	}
	
	var concessionAmoun = 0.0, dynamicDiscountFare = 0.0;
	/*if(document.getElementById("totalAmountHid") != null)
	totalAmount = parseFloat(document.getElementById("totalAmountHid").value);*/
	if(document.getElementById("concessionAmountHid") != null)
		concessionAmoun = parseFloat(document.getElementById("concessionAmountHid").value);
	if(document.getElementById("dynamicDiscountFareHid") != null)
		dynamicDiscountFare = parseFloat(document.getElementById("dynamicDiscountFareHid").value);
	var walletSaveAmt = 0.0;
	if(document.getElementById("walletSaveAmount") != null)
		walletSaveAmt = document.getElementById("walletSaveAmount").value;
	
	
	path = path + "?cashbackCoupon="+ cashbackCoupon
				+ "&bankRefNo="+ bankRefNo
				+ "&calculateCashBackAmt="+ calculateCashBackAmt
				+ "&totalAmount="+ totalAmount
				+ "&concessionAmount="+ concessionAmoun
				+ "&dynamicDiscountFare="+ dynamicDiscountFare
				;

	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	//document.getElementById('cashbackCoupon').
}

function getSearchLinkTicketList(path, divName) { 
	var txtJourneyDate, endPlaceId, startPlaceId, txtReturnJourneyDate = "";
	hidediv("ForwardLinkServiceDiv");
	hidediv("ReturnLinkServiceDiv");
	showdiv("populateLinkPlacesDiv");
	//showdiv("progressBarDiv");
	if(document.getElementById("startPlaceId") != null && document.getElementById("startPlaceId").value){
		startPlaceId = document.getElementById("startPlaceId").value;
	} else {
		alert("Please enter start place..");
		return false;
	}
	if(document.getElementById("endPlaceId") != null && document.getElementById("endPlaceId").value){
		endPlaceId = document.getElementById("endPlaceId").value;
	}else {
		alert("Please enter end place..");
		return false;
	}

	
	if(document.getElementById("txtJourneyDate") != null && document.getElementById("txtJourneyDate").value){
		txtJourneyDate = document.getElementById("txtJourneyDate").value;
	}else {
		alert("Please select journey date..");
		return false;
	}
	if(document.getElementById("txtReturnJourneyDate") != null && document.getElementById("txtReturnJourneyDate").value){
		txtReturnJourneyDate = document.getElementById("txtReturnJourneyDate").value;
	}
	/*if(document.getElementById("searchType_3") != null 
			&& document.getElementById("searchType_3").checked == true){
		if(document.getElementById("txtReturnJourneyDate") != null && document.getElementById("txtReturnJourneyDate").value){
			txtReturnJourneyDate = document.getElementById("txtReturnJourneyDate").value;
		}else {
			alert("Please select return journey date..");
			return false;
		}
	}*/
	
	path = path + "?txtJourneyDate=" + txtJourneyDate
				+ "&txtReturnJourneyDate=" + txtReturnJourneyDate
	            + "&endPlaceId=" + endPlaceId
	            + "&startPlaceId=" + startPlaceId
				;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function getLinkAvailableServiceList(path, linkType, linkPlaceId, offlinePlace, linkRouteId, divName){
	
	/*hidediv("ForwardAvailableServicesDiv");
	hidediv("ReturnAvailableServicesDiv");*/
	hidediv("fwInfoLeftId");
	hidediv("retInfoLeftId");
	showdiv("ForwardLinkServiceDiv");
	showdiv("ReturnLinkServiceDiv");
	hidediv("populateLinkPlacesDiv");
	// forward journey parameters
	var arrivalDay = 0;
	var startPlaceId = 0, endPlaceId = 0;
	// Exaple :hyd---tpt---knpm  actual route
	//hyd--->sart, tpt--->end
	//tpt--->start, hyd--->end
	if(document.getElementById("isLinkTicket") != null)
		document.getElementById("isLinkTicket").value = 1;
	
	if(linkType == 'Forward'){
		if(document.getElementById("linkPlaceId") != null)
			document.getElementById("linkPlaceId").value = linkPlaceId;
		
		if(document.getElementById("offlinePlaceFw") != null)
			document.getElementById("offlinePlaceFw").value = offlinePlace;
		if(offlinePlace == 1){
			startPlaceId = linkPlaceId;
			if(document.getElementById("endPlaceId") != null)
				endPlaceId = document.getElementById("endPlaceId").value;

			if(document.getElementById("startPlaceId") != null)
				linkPlaceId = document.getElementById("startPlaceId").value;
		} else {
			if(document.getElementById("startPlaceId") != null)
				startPlaceId = document.getElementById("startPlaceId").value;
			
			endPlaceId = linkPlaceId;
			if(document.getElementById("endPlaceId") != null)
				linkPlaceId = document.getElementById("endPlaceId").value;

		}

	} else if(offlinePlace == 1){
		if(document.getElementById("offlinePlaceRt") != null)
			document.getElementById("offlinePlaceRt").value = offlinePlace;
		
		if(document.getElementById("linkPlaceIdRet") != null)
			document.getElementById("linkPlaceIdRet").value = linkPlaceId;
		
		startPlaceId = linkPlaceId;

		if(document.getElementById("startPlaceId") != null)
			endPlaceId = document.getElementById("startPlaceId").value;
		
		if(document.getElementById("endPlaceId") != null)
			linkPlaceId = document.getElementById("endPlaceId").value;


	} else {
		if(document.getElementById("offlinePlaceRt") != null)
			document.getElementById("offlinePlaceRt").value = offlinePlace;
		
		if(document.getElementById("linkPlaceIdRet") != null)
			document.getElementById("linkPlaceIdRet").value = linkPlaceId;
		
		if(document.getElementById("endPlaceId") != null)
			startPlaceId = document.getElementById("endPlaceId").value;
		
		endPlaceId = linkPlaceId;
		
		if(document.getElementById("startPlaceId") != null)
			linkPlaceId = document.getElementById("startPlaceId").value;

	}
	if(linkType == 'Forward'){
		if(document.getElementById("linkRouteId") != null)
			document.getElementById("linkRouteId").value = linkRouteId;
	} else {
		if(document.getElementById("linkRouteIdRet") != null)
			document.getElementById("linkRouteIdRet").value = linkRouteId;
	}
	if(linkType == 'Forward'){
		path = path + "?startPlaceId=" + startPlaceId
		+ "&endPlaceId=" + endPlaceId
		+ "&linkPlaceId=" + linkPlaceId
		+ "&txtJourneyDate=" + document.getElementById("txtJourneyDate").value
		+"&arrivalDay=" + arrivalDay 
		+ "&isLinkTicket=1"
		+ "&linkType=fw"
		+ "&ajaxAction=fw"
		+ "&offlinePlaceFw=" + offlinePlace
		+ "&linkRouteId=" + linkRouteId
		;
	} else {
		path = path +"?startPlaceId=" + startPlaceId
		+ "&endPlaceId=" + endPlaceId
		+ "&linkPlaceId=" + linkPlaceId
		+ "&txtJourneyDate=" + document.getElementById("txtJourneyDate").value
		+ "&txtReturnJourneyDate=" + document.getElementById("txtReturnJourneyDate").value
		+"&arrivalDay=" + arrivalDay 
		+ "&isLinkTicket=1"
		+ "&linkType=rt"
		+ "&ajaxAction=rt"
		+ "&offlinePlaceRt=" + offlinePlace
		+ "&linkRouteId=" + linkRouteId
		;
	}

	showdiv("progressBarDiv");
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	
	showdiv('modifySearchId');
	return true;
	
}

function ajaxShowLinkBoardingPoints(srid, sid, scId, rtPid, act, idx, ladiesSpl,tripId, tripNo,isItimService,cutOffTime,
	linkPlaceId, layoverTimeStr, linkForwardArrivalTimeStr, bookedSeatString, blockedSeatString) {
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
	    var b = confirm("The selected service journey date is " + document.getElementById("txtReturnJourneyDate").value +" and Layover Time is " + layoverTimeStr + "Hrs Continue .");
	    if(b == false) return;
	}
	
	if(document.getElementById('linkForwardArrivalTimeStr') != null && linkForwardArrivalTimeStr != ''){
		document.getElementById('linkForwardArrivalTimeStr').value = linkForwardArrivalTimeStr;
	}
	
	
	var path, divName, dt, startId, endId;
	if(document.getElementById("isLinkTicket") != null){
		document.getElementById("isLinkTicket").value = 1;
	}
	if(document.getElementById("startPlaceCode") != null){
		document.getElementById("startPlaceCode").checked = true;
	}
	
	if(document.getElementById("linkPlaceId") != null && linkPlaceId != null && linkPlaceId != ''){
		document.getElementById("linkPlaceId").value = linkPlaceId;
	}
	
	if(document.getElementById("linkPlaceId") != null && linkPlaceId == '' ){
		linkPlaceId = document.getElementById("linkPlaceId").value;
	}
	
	var path, divName, dt, startId, endId;
	var offlinePlace = '';
	if(act == "Return") {
		divName = "ReturnBoardPtsDiv";
		dt = document.getElementById("txtReturnJourneyDate").value;
		path = "/ajax/return/layout/boardPoints.do?ajaxAction=rt&txtReturnJourneyDate=" + dt;
		if(tripId && tripId != "") {
			path = path+='&tripMasterId='+tripId
		}
		if(tripNo && tripNo != "") {
			path = path+='&tripNo='+tripNo
		}
		/*startId = document.getElementById("endPlaceId").value;
		endId = document.getElementById("startPlaceId").value;*/
		if(document.getElementById("offlinePlaceRt") != null)
			offlinePlace = document.getElementById("offlinePlaceRt").value;
		if(offlinePlace == 1){

		if(document.getElementById("linkPlaceIdRet") != null)
			linkPlaceId = document.getElementById("linkPlaceIdRet").value;

			startId = linkPlaceId;

		if(document.getElementById("startPlaceId") != null)
				endId = document.getElementById("startPlaceId").value;

		} else {
	
//			if(document.getElementById("linkPlaceIdRet") != null)
//				linkPlaceId = document.getElementById("linkPlaceIdRet").value;

		startId = linkPlaceId;
		if(document.getElementById("endPlaceId") != null)
			endId = document.getElementById("endPlaceId").value;;
		}
		
		if(document.getElementById("linkEndTripNo") != null){
			document.getElementById("linkEndTripNo").value = tripNo;
		}
		if(document.getElementById("linkEndTripMasterId") != null){
			document.getElementById("linkEndTripMasterId").value = tripId;
		}
		if(document.getElementById("retTripNo") != null){
			document.getElementById("retTripNo").value = tripNo;
		}
		if(document.getElementById("returnTripMasterId") != null){
			document.getElementById("returnTripMasterId").value = tripId;
		}
		isLinkTicket = 0;
		document.getElementById("isLinkTicket").value = 0;
	} else {
		/*startId = document.getElementById("startPlaceId").value;
		endId = document.getElementById("endPlaceId").value;*/
		
		if(document.getElementById("txtReturnJourneyDate").value != '' && document.getElementById("endPlaceCodeRet") != null 
				&& document.getElementById("endPlaceCodeRet").checked == false){
			alert("Please Select Return service list..");
			return false;
			
		}
//		if(document.getElementById("linkPlaceId") != null)
//			linkPlaceId = document.getElementById("linkPlaceId").value;
		
//		if(document.getElementById("offlinePlaceFw") != null)
//			offlinePlace = document.getElementById("offlinePlaceFw").value;
//		if(offlinePlace == 1){
//			startId = linkPlaceId;
//			if(document.getElementById("endPlaceId") != null)
//				endId = document.getElementById("endPlaceId").value;
//			
//		} else {
//			if(document.getElementById("startPlaceId") != null)
//				startId = document.getElementById("startPlaceId").value;
//			
//			endId = linkPlaceId;
//
//		}
		
		if(document.getElementById("startPlaceId") != null)
			startId = document.getElementById("startPlaceId").value;
		endId = linkPlaceId;
		divName = "ForwardBoardPtsDiv";
		dt = document.getElementById("txtJourneyDate").value;
		path = "/ajax/forward/layout/boardPoints.do?ajaxAction=fw&txtJourneyDate=" + dt;
		if(tripId && tripId !="") {
			path = path+='&tripMasterId='+tripId
		}
		if(tripNo && tripNo != "") {
			path = path+='&tripNo='+tripNo
		}
		if(document.getElementById("forwardTtripNo") != null){
			document.getElementById("forwardTtripNo").value = tripNo;
		}
		if(document.getElementById("tripMasterId") != null){
			document.getElementById("tripMasterId").value = tripId;
		}
		var div = sid+"_arrivalTime_"+tripNo+"_connect";
		if(document.getElementById(div) !=  null){
			path = path + "&fwArrivalTime=" + document.getElementById(div).value;
			if(document.getElementById("ForwardJourneyTime_2") !=  null)
				document.getElementById("ForwardJourneyTime_2").value =  dt+" "+document.getElementById(div).value;
		}
		div = sid+"_arrivalDay_"+tripNo+"_connect";
		if(document.getElementById(div) !=  null){
			path = path + "&fwArrivalDay=" + document.getElementById(div).value;
			if(document.getElementById("ForwardArrivalDay") !=  null)
				document.getElementById("ForwardArrivalDay").value =  document.getElementById(div).value;
		}
		
		var fwdDepartureTimeDivId = sid+"_departureTime_"+tripNo+"_connect";
		if(document.getElementById(fwdDepartureTimeDivId) !=  null){
			if(document.getElementById("linkForwardDepartureTime") !=  null)
				document.getElementById("linkForwardDepartureTime").value =  document.getElementById(fwdDepartureTimeDivId).value;
		}
		
		var  durationTimeDiv = sid+"_durationTime_"+tripNo+"_connect";
		if(document.getElementById(durationTimeDiv) !=  null){
			if(document.getElementById("journeyForwardDurationTime") !=  null)
				document.getElementById("journeyForwardDurationTime").value =  document.getElementById(durationTimeDiv).value;
		}
		
		document.getElementById("isLinkStartBooking").value=1;
		isLinkTicket = 1;
	}
	
	document.getElementById(act + "ServiceId").value = sid;
	document.getElementById("srvcRtId" + act).value = srid;
	document.getElementById("categoryId" + act).value = scId;
	
		path = path + "&serviceId=" + sid + 
				 "&startPlaceId=" + startId  + 
				 "&routeCode=" + srid + 
				 "&endPlaceId=" + endId + 
				 "&serviceCategoryId=" + scId + 
				 "&isItimService=" + isItimService + 
				 "&cutOffTime=" + cutOffTime +
				 "&isLinkTicket=" + isLinkTicket
				 "&isLinkStartBooking=1"
				 "&linkPlaceId=" + linkPlaceId
				 "&bookedSeatString=+bookedSeatString"
				 "&blockedSeatString=" + blockedSeatString;

	var remName = document.getElementById(act).value;
	removeDiv(remName, divName);
	var divTag = createDiv(divName);
	if(act == "Return") {
	    document.getElementById(("Layout" + act + idx)).appendChild(divTag);
	    document.getElementById(act).value = ("Layout" + act + idx);
	}else{
		document.getElementById(("LTLayout" + act + idx)).appendChild(divTag);
    	document.getElementById(act).value = ("LTLayout" + act + idx);
	}
    showdiv("progressBarDiv");
    accomPrice=0;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);	
}

function redeemRewardPoints(path, divName){
	showdiv(divName);
	var rewardPoints = 0, retTotalAmountHid = 0.0, updatedRewardPoints = 0, eligibleRewardPoints = 0;
	if(document.getElementById("eligibleRewardPointsHid") != null && document.getElementById("eligibleRewardPointsHid").value != ''
		&& document.getElementById("eligibleRewardPointsHid").value != 0){
		updatedRewardPoints = document.getElementById("eligibleRewardPointsHid").value;
	} else {
		alert("Reward Points are not Zero..");
		return false;
	}
	
	if(document.getElementById("eligibleRewardPoints") != null){
		eligibleRewardPoints = document.getElementById("eligibleRewardPoints").value;
	}
	if(parseInt(updatedRewardPoints) > parseInt(eligibleRewardPoints)){
		alert("Please enter eligible reward points..");
		return false;
	}
	
	var ForwardOrigBasicFare = 0.0, ReturnOrigBasicFare = 0.0, basicFareHid = 0.0, basicFareHidRet = 0.0;
	if(document.getElementById("ForwardOrigBasicFare") != null){
		ForwardOrigBasicFare = document.getElementById("ForwardOrigBasicFare").innerHTML;
	}
	if(document.getElementById("ReturnOrigBasicFare") != null){
		ReturnOrigBasicFare = document.getElementById("ReturnOrigBasicFare").innerHTML;
	}
	//basicFareHid = parseFloat(ForwardOrigBasicFare) + parseFloat(ReturnOrigBasicFare);
	
	var mobileNum = null;
	if(document.getElementById("mobileNo")){
		mobileNum = document.getElementById("mobileNo").value;
	}
	basicFareHid = parseFloat(ForwardOrigBasicFare);
	basicFareHidRet = parseFloat(ReturnOrigBasicFare);
	path = path + "?eligibleRewardPoints="+eligibleRewardPoints
	            + "&basicFareHid=" + basicFareHid
	            + "&retTotalPrice=" + basicFareHidRet
	            + "&mobileNo=" + mobileNum
	            + "&updatedRewardPoints=" + updatedRewardPoints;

	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function cancelRedeemPoints(path, divName){
	showdiv(divName);
	hidediv("redeemSuccessDiv");
	var rewardPoints = 0;
	if(document.getElementById("rewardPoints") != null && document.getElementById("rewardPoints").value != ''
		&& document.getElementById("rewardPoints").value != 0){
		rewardPoints = document.getElementById("rewardPoints").value;
	} 
	var ForwardOrigBasicFare = 0.0, ReturnOrigBasicFare = 0.0, basicFareHid = 0.0, basicFareHidRet = 0.0;
	if(document.getElementById("ForwardOrigBasicFare") != null){
		ForwardOrigBasicFare = document.getElementById("ForwardOrigBasicFare").innerHTML;
	}
	if(document.getElementById("ReturnOrigBasicFare") != null){
		ReturnOrigBasicFare = document.getElementById("ReturnOrigBasicFare").innerHTML;
	}
	basicFareHid = parseFloat(ForwardOrigBasicFare);
	basicFareHidRet = parseFloat(ReturnOrigBasicFare);
	path = path + "?rewardPoints="+rewardPoints
				+ "&basicFareHid=" + basicFareHid
				+ "&retTotalPrice=" + basicFareHidRet
				;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}


function getOTPToMobile(path, divName){
	hidediv("ShowBtnRedeemDivID");
	showdiv("OTPSuccessDiv");
	var mobileNum = document.getElementById("mobileNo").value;
	if(mobileNum == "" || mobileNum == null){
		alert("Please Enter the Mobile Number");
		return false;
	}
	path = path + "?mobileNo="+mobileNum;
    ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function reSendOTP(path, divName, button, disableTime){
	rewardDisableResend(button, disableTime);
	hidediv("ShowBtnRedeemDivID");
	showdiv("OTPSuccessDiv");
	var mobileNum = document.getElementById("mobileNo").value;
	/*if(mobileNum == "" || mobileNum == null){
		alert("Please Enter the Mobile Number");
		return false;
	}*/
	path = path + "?mobileNo="+mobileNum;
    ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function validateAndSubmitOtp(path, divName){
	var otp = document.getElementById("otpCode").value;
	if(otp.trim().length < 6){
		alert("Please Enter Valid OTP..");
		return false;
	}
	hidediv("OTPSuccessDiv");
	var mobileNum = document.getElementById("mobileNo").value;
	
	var ForwardOrigBasicFare = 0.0, ReturnOrigBasicFare = 0.0, basicFareHid = 0.0, basicFareHidRet = 0.0;
	if(document.getElementById("ForwardOrigBasicFare") != null){
		ForwardOrigBasicFare = document.getElementById("ForwardOrigBasicFare").innerHTML;
	}
	if(document.getElementById("ReturnOrigBasicFare") != null){
		ReturnOrigBasicFare = document.getElementById("ReturnOrigBasicFare").innerHTML;
	}
	basicFareHid = parseFloat(ForwardOrigBasicFare);
	basicFareHidRet = parseFloat(ReturnOrigBasicFare);
	path = path + "?otpCode="+otp+ "&mobileNo= " + mobileNum 
	+ "&basicFareHid= " + basicFareHid
	+ "&retTotalPrice= " + basicFareHidRet
	;
    ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function getRewardRedeem(obj, divName){
	if(obj.checked == true){
		var selectedSeats = document.getElementsByName('seatDetails');
		if(parseInt(selectedSeats.length) < 1){
			alert("Please select seat to continue.");
			obj.checked = false;
			return false;
		}
		
		if(document.getElementById('PaxTblReturn') != null && document.getElementById("seatDetailsReturn0") == null){
			alert("Please select seat to continue.");
			obj.checked = false;
			return false;
		}
		
		showdiv(divName);
		hidediv("OTPSuccessDiv");
		var ForwardOrigBasicFare = 0.0, ReturnOrigBasicFare = 0.0, basicFareHid = 0.0, basicFareHidRet = 0.0;
		/*var mobileNo;
		if(document.getElementById("mobileNo") != null){
			mobileNo = document.getElementById("mobileNo").value;
		} else {
			alert("Please enter mobile No..")
			return false;
		}*/
		
		if(document.getElementById("ForwardOrigBasicFare") != null && document.getElementById("ForwardOrigBasicFare").innerHTML != ''){
			ForwardOrigBasicFare = document.getElementById("ForwardOrigBasicFare").innerHTML;
		}
		if(document.getElementById("ReturnOrigBasicFare") != null && document.getElementById("ReturnOrigBasicFare").innerHTML != ''){
			ReturnOrigBasicFare = document.getElementById("ReturnOrigBasicFare").innerHTML;
		}
		basicFareHid = parseFloat(ForwardOrigBasicFare);
		basicFareHidRet = parseFloat(ReturnOrigBasicFare);
		path = "/ajax/booking/showRedeemAmount.do?mobileNo="+mobileNo 
		+ "&basicFareHid=" + basicFareHid
		+"&retTotalPrice=" + basicFareHidRet;
	    ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	} else{
		hidediv(divName);
		hidediv("OTPSuccessDiv");
		hidediv("redeemSuccessDiv");
	}
	
}

/*
 *   The Following function is for Single Lady ..
 */

function enableSingleLady() {
	var sLady = document.getElementById('singleLady');
	
	if (sLady.checked == true) {
		sLady.value = "1";
	} else {
		sLady.value = "0";
	}
	hidediv('ShowLayoutDiv');
}

function enableRestPoints(serviceId, requestType){
	try{
		if(requestType == "Forward"){
			var path = "/ajax/disp/forward/restPoints.do?serviceId="+serviceId+"&ajaxAction=fw";
		    ajaxCommonActionSubmit(path, "RestPointsDivIdForward", DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
		}else{
			var path = "/ajax/disp/return/restPoints.do?serviceId="+serviceId+"&ajaxAction=rt";
		    ajaxCommonActionSubmit(path, "RestPointsDivIdReturn", DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
		}
	}catch(e){
		console.log("Error .... ", e);
	}

}

function calculateLayoutFares(requestType){
	var divName ="LayoutFare";
	var toll = parseFloat(document.getElementById(requestType + "TollsPrice").value);
	var srt = parseFloat(document.getElementById(requestType + "SrtFee").value);
	var bTxn = parseFloat(document.getElementById(requestType + "BnkTxnAmt").value);
	var conc = parseFloat(document.getElementById("concessionPercent").value);
	var concNoPassengers = parseFloat(document.getElementById("concNoPassengers").value);
	var concApplyToChild = parseFloat(document.getElementById("concApplyToChild").value);
	
	if(document.getElementById("retConc") != null)
		retConc = document.getElementById("retConc").value;
	
	
	var selectedSeats = document.getElementsByName('seatDetails');
    var oneWaySeatCount = parseInt(selectedSeats.length);
    var forwardSeatNos = new Array();
    var returnSeatNos = new Array();
    var j = 0;
    for(var i = 0; i < selectedSeats.length; i++){
        if(document.getElementById("seatDetailsForward" + i) != null)
            forwardSeatNos[i] = document.getElementById("seatDetailsForward" + i).value;
        else if(document.getElementById("seatDetailsReturn" + j) != null){
        	returnSeatNos[j] = document.getElementById("seatDetailsReturn" + j).value; 
        	j++;
        	
        }
    }
    var path =  "/fw/calculate/layout/fares.do?ajaxAction=fw";
    var adultFare = 0, childFare = 0, adultLevy = 0, childLevy = 0;
    
    if(document.getElementById("ForwardAdultFare") != null){
    	adultFare = document.getElementById("ForwardAdultFare").value;
    }
    if(document.getElementById("ForwardChildFare") != null){
    	childFare = document.getElementById("ForwardChildFare").value;
    }
    
    if(document.getElementById("ForwardAdultLevyFare") != null){
    	adultLevy = document.getElementById("ForwardAdultLevyFare").value;
    }
    if(document.getElementById("ForwardChildLevyFare") != null){
    	childLevy = document.getElementById("ForwardChildLevyFare").value;
    }
    
    if(requestType == "Return"){
    	ReturnSeatNos = returnSeatNos;
    	if(document.getElementById("ReturnAdultFare") != null){
        	adultFare = document.getElementById("ReturnAdultFare").value;
        }
        if(document.getElementById("ReturnChildFare") != null){
        	childFare = document.getElementById("ReturnChildFare").value;
        }
        
        if(document.getElementById("ReturnAdultLevyFare") != null){
        	adultLevy = document.getElementById("ReturnAdultLevyFare").value;
        }
        if(document.getElementById("ReturnChildLevyFare") != null){
        	childLevy = document.getElementById("ReturnChildLevyFare").value;
        }
    	
    	path =  "/rt/calculate/layout/fares.do?ajaxAction=rt";
    }
    var max = parseInt(document.getElementById("maxAgeCh").value);
	var ob;
	var aPax = 0, cPax = 0, totPax = 0;
	for(var i = 0; i < 20; i++) {
		ob = document.getElementById(("passengerAge" + requestType + i));
		if(ob != null) {
			if(ob.value != null && ob.value != "" && ob.value == 0) {
				ob.value = "";
				ob.focus();
				alert("Age should be greater than 0.");
				return false;
			}
			if(ob.value != null && ob.value != "" && ob.value <= max) {
				document.getElementById(("categoryCodeId" + requestType + i)).value = CHILD_ID;
				++cPax;
			} else {
				document.getElementById(("categoryCodeId" + requestType + i)).value = ADULT_ID;
				++aPax;
			}
			if(!isNumber(ob)) {
				continue;
			}
		}
	}
	totPax = aPax + cPax;
	if(totPax == 0){
		document.getElementById(requestType + "BasicFare").innerHTML = 0;
		document.getElementById(requestType+ "OrigBasicFare").innerHTML = 0;
		document.getElementById(requestType + "SRT").innerHTML = 0;
		document.getElementById(requestType + "Toll").innerHTML = 0;
		document.getElementById(requestType + "Levies").innerHTML = 0;
		if(document.getElementById(requestType + "Accomdation") != null) {
			document.getElementById(requestType + "Accomdation").innerHTML = 0;
		}
		if(document.getElementById(requestType + "Dinner") != null) {
			document.getElementById(requestType + "Dinner").innerHTML = 0;
		}
		
		if(document.getElementById(requestType + "Concession") != null) {
			document.getElementById(requestType + "Concession").innerHTML = 0;
		}
		document.getElementById(requestType + "BankTransact").innerHTML = 0;
		
		document.getElementById(requestType+'totFare').innerHTML = 0;
		return false;
	}
	
	path = path + "&srtFee="+ srt 
				+ "&tollFare="+ toll 
				+ "&bankTxnAmount="+bTxn
				+ "&concessionPercent="+conc
				+ "&adults=" + aPax
				+ "&childs=" + cPax
				+ "&seatNosForward=" + forwardSeatNos
				+ "&concNoPassengers=" + concNoPassengers
				+ "&concApplyToChild=" + concApplyToChild
				+ "&forwardAdultFare=" + adultFare
				+ "&forwardChildFare=" + childFare
				+ "&adultLevyFare=" + adultLevy
				+ "&childLevyFare=" + childLevy
				;
	
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function validateConcessionCard(index, requestType, cardNumber){
	
	if(cardNumber == null && cardNumber =="" )
		return false;
	
	var divName = "passengerDiv"+index;
	var concessionId = 0, age = 0, txtJourneyDate = "";
	if(document.getElementById("concessionIds"+index) != null) {
		concessionId = document.getElementById("concessionIds"+index).value;
	}
	if(document.getElementById("passengerAge"+index) != null) {
		age = document.getElementById("passengerAge"+index).value;
	}
	if(document.getElementById("txtJourneyDate") != null) {
				txtJourneyDate = document.getElementById("txtJourneyDate").value;
		}
	
	var path ="/pax/cardno/validate.do?cardNumber="+ cardNumber
				+'&concessionId='+ concessionId
				+'&index='+ index
				+'&childAge='+ age
				+'&txtJourneyDate='+ txtJourneyDate;

	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function validateObreferanceNo(bankRefNo) {
	var divName = "ShowTranxDetails";
	var bookingReferenceNo ="";
	if(document.getElementById("bookingReferenceNo").value != null){
		bookingReferenceNo = document.getElementById("bookingReferenceNo").value;
	}
	
	
	var path ="/tickets/status/obreference.do?isTranxSuccess=0"
				+ "&bankRefNo=" + bankRefNo
				+ "&bookingReferenceNo=" + bookingReferenceNo;
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function validateMobileWallet(path, divId){
	var mobileNo = '';
	var obj = document.getElementById("mobileNo");
	if(obj != null && obj.value != ""){
		mobileNo = obj.value;
	} else {
		alert("Enter valid Mobile No of Co-Passenger");
		obj.focus();
		return false;
	}
	path = path + "?mobileNo=" + mobileNo;
	ajaxCommonActionSubmit(path, divId, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}
function searchSlotServices(path, index, requestType, slotType, divName) {
	for(var i=0;i<4;i++) {
		if(i !=Number(index)) {
			if(document.getElementById("slotDelDiv600"+i)) {
				document.getElementById("slotDelDiv600"+i).style.opacity="1";
				document.getElementById("slotDelDiv600"+i).style.cursor="pointer";
			}
			
		}
	}
	document.getElementById("slotDelDiv600"+index).style.opacity="0.5";
	document.getElementById("slotDelDiv600"+index).style.cursor="default";
	if(requestType == "Return") {
		path = path + "?startPlaceId=" + document.getElementById("endPlaceId").value
		+"&endPlaceId="+document.getElementById("startPlaceId").value
		+"&txtJourneyDate="+document.getElementById("txtReturnJourneyDate").value
		+"&slotIndex="+index+"&slotJourneyType="+slotType
		+"&ajaxAction=ret";
	} else {
		path = path + "?startPlaceId=" + document.getElementById("startPlaceId").value
		+"&endPlaceId="+document.getElementById("endPlaceId").value
		+"&txtJourneyDate="+document.getElementById("txtJourneyDate").value
		+"&slotIndex="+index+"&slotJourneyType="+slotType
		+"&ajaxAction=fw";;
	}
	showdiv("progressBarDiv");
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	return true;
}

function slotRecalculateFares(path, form, index, divName, categoryId, slotId) {
	index = document.getElementById("selectedSlotIndex").value;
	var adultMale = 0, adultFemale = 0, childMale = 0, childFemale = 0;
	var searchType = "", stockNo = "", concessionId = "", serviceCategoryId = "";
	var ajaxAction = "fw";
	if(document.getElementById("totalAdult"+index) != null)
		adultMale = trim(document.getElementById("totalAdult"+index).value);
	if(document.getElementById("adultFemale") != null)
		adultFemale = trim(document.getElementById("adultFemale").value);
	if(document.getElementById("totalChild"+index) != null)
		childMale = trim(document.getElementById("totalChild"+index).value);
	if(document.getElementById("childFemale") != null)
		childFemale = trim(document.getElementById("childFemale").value);
	if(adultMale == '') adultMale = 0;
	if(adultFemale == '') adultFemale = 0;
	if(childMale == '') childMale = 0;
	if(childFemale == '') childFemale = 0;
	if(document.getElementById("concessionIdsForward"+index) != null)
		concessionId = document.getElementById("concessionIdsForward"+index).value;
	if(document.getElementById("serviceCategoryId") != null)
		serviceCategoryId = document.getElementById("serviceCategoryId").value;
	var ticketType = "";
	if(document.getElementById("ticketType") != null)
		ticketType = document.getElementById("ticketType").value ;
	var journeyDate = document.getElementById("txtJourneyDate").value;
	var passengerName = new Array();
	var passengerNameArray = document.getElementsByName('passengerName');
	for(var i = 0; i < passengerNameArray.length; i++){
		if(document.getElementById("passengerNameForward" + i) != null)
			passengerName[i] = document.getElementById("passengerNameForward" + i).value;
	}
	
	// if(valiateSlot(index)) {
		path =  path+ "?slotIndex=" +Number(index)
		+ "&ajaxAction=" + ajaxAction
		+ "&endPlaceId="+document.getElementById("destinationId"+index).value
		+ "&startPlaceId=" +document.getElementById("originId"+index).value
		+ "&serviceRouteId="+document.getElementById("serviceRouteId"+index).value
		+ "&adultMale=" + adultMale
		+ "&adultFemale=" + adultFemale
		+ "&childMale=" + childMale
		+ "&childFemale=" + childFemale
		+ "&stockNo=" + stockNo
		+ "&concessionId=" + concessionId
		+ "&srvcTypeCatgId=" + serviceCategoryId
		+ "&serviceCategoryId=" + categoryId
		+ "&searchType=" + searchType
		+ "&ticketType=" + ticketType
		+ "&txtJourneyDate=" + journeyDate
		+ "&slotId=" + slotId
		+ "&passengerName=" + passengerName
		;
		ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	// }
	return true;
}
function valiateSlot(index) {
	if(document.getElementById("boardingPoint"+index) && document.getElementById("boardingPoint"+index).value =="") {
		alert("Please Enter Borading Point")
		return false;
	}
	if(document.getElementById("droppingPoint"+index) && document.getElementById("droppingPoint"+index).value =="") {
		alert("Please Enter Dropping Point")
		return false;
	}
	if(document.getElementById("totalAdult"+index) && document.getElementById("totalAdult"+index).value =="") {
		alert("Please Enter Adult Count")
		return false;
	}
	if(document.getElementById("totalChild"+index) && document.getElementById("totalChild"+index).value =="") {
		alert("Please Enter Child Count")
		return false;
	}
	if(document.getElementById("bookedByName"+index) && document.getElementById("bookedByName"+index).value =="") {
		alert("Please Enter Passenger Name")
		return false;
	}
	return true;
}

function slotPaxDetails(path, form, index,slotIndex, divName, categoryId, slotId, type) {
	var totalSlotCount = document.getElementById("totalSlotCount").value;
	var slotAvailableSeats = document.getElementById("availableSeats"+index+slotIndex).value;
	if(Number(slotAvailableSeats) <= 0) {
		alert("No Seats available, Please select another Service / Slot");
		return false;
	}
	if(String(slotIndex).length>1) {
		slotIndex=String(slotIndex).charAt(1);
		slotIndex = Number(slotIndex);
	}
	if(String(index).length>1) {
		index = String(index).charAt(0);
		index = Number(index);
	}
	var list = document.getElementsByClassName('time-col-active2');
	if(list && list.length>0) {
		for(var i=0;i<=list.length;i++) {
			if(list[i]) {
				list[i].className='time-col-active';
			}
		}
	}
	var journeyTypeFlag = null;
	for(var i=0;i<=totalSlotCount;i++) {
		if(i !=Number(index)) {
			if(document.getElementById("slotService"+i+slotIndex+type)) {
				document.getElementById("slotService"+i+slotIndex+type).className = "time-col-active";
			}
			
		}
	}
	if(document.getElementById("slotPassengerDetails"+index+type)) {
		document.getElementById("slotPassengerDetails"+index+type).style.display = "";
		document.getElementById("slotService"+index+slotIndex+type).className = "time-col-active2";
	}
	
	var adultMale = 1, adultFemale = 0, childMale = 0, childFemale = 0;
	var searchType = "", stockNo = "", concessionId = "", serviceCategoryId = "";
	var ajaxAction = type;
	if(ajaxAction =="fw") {
		journeyTypeFlag="Forward";
	}else {
		journeyTypeFlag="Return";
	}
	if(document.getElementById("totalAdult"+index+slotIndex) != null)
		adultMale = trim(document.getElementById("totalAdult"+index+slotIndex).value);
	if(document.getElementById("adultFemale") != null)
		adultFemale = trim(document.getElementById("adultFemale").value);
	if(document.getElementById("totalChild"+index+slotIndex) != null)
		childMale = trim(document.getElementById("totalChild"+index+slotIndex).value);
	if(document.getElementById("childFemale") != null)
		childFemale = trim(document.getElementById("childFemale").value);
	if(adultMale == '') adultMale = 0;
	if(adultFemale == '') adultFemale = 0;
	if(childMale == '') childMale = 0;
	if(childFemale == '') childFemale = 0;
	if(document.getElementById("concessionIds"+journeyTypeFlag+index) != null)
		concessionId = document.getElementById("concessionIds"+journeyTypeFlag+index).value;
	if(document.getElementById("serviceCategoryId") != null)
		serviceCategoryId = document.getElementById("serviceCategoryId").value;
	var ticketType = "";
	if(document.getElementById("ticketType") != null)
		ticketType = document.getElementById("ticketType").value ;
	var journeyDate = document.getElementById("txtJourneyDate").value;
	
	path =  path+ "?slotIndex=" +index+slotIndex
	+ "&ajaxAction=" + ajaxAction
	//+ "&endPlaceId="+document.getElementById("destinationId"+index+slotIndex).value
	//+ "&startPlaceId=" +document.getElementById("originId"+index+slotIndex).value
	+ "&endPlaceId="+document.getElementById("endPlaceId").value
	+ "&startPlaceId=" +document.getElementById("startPlaceId").value
	+ "&serviceRouteId="+document.getElementById("serviceRouteId"+index+slotIndex+type).value
	+ "&adultMale=" + adultMale
	+ "&adultFemale=" + adultFemale
	+ "&childMale=" + childMale
	+ "&childFemale=" + childFemale
	+ "&concessionId=" + concessionId
	+ "&srvcTypeCatgId=" + serviceCategoryId
	+ "&serviceCategoryId=" + categoryId
	+ "&ticketType=" + ticketType
	+ "&txtJourneyDate=" + journeyDate 
	+ "&searchType=" + searchType
	+ "&slotId=" + document.getElementById("slotKeyRecordId"+index+slotIndex).value
	;
	
	if(divName =="SlotFareDetailsDivID") {
		ajaxCommonActionSubmit(path, divName+index+slotIndex, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}else {
		ajaxCommonActionSubmit(path, divName+index+type, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}
	
	
	return true;
}

function slotPaxDetailsInfo(path, form, index,slotIndex, divName, categoryId, slotId, type) {
	var totalSlotCount = document.getElementById("totalSlotCount").value;
	if(String(slotIndex).length>1) {
		slotIndex=String(slotIndex).charAt(1);
		slotIndex = Number(slotIndex);
	}
	if(String(index).length>1) {
		index = String(index).charAt(0);
		index = Number(index);
	}
	var journeyTypeFlag = null;
	for(var i=0;i<=totalSlotCount;i++) {
		if(i !=Number(index)) {
			if(document.getElementById("slotService"+i+slotIndex+type)) {
				document.getElementById("slotService"+i+slotIndex+type).className = "time-col-active";
			}
			
		}
	}
	if(document.getElementById("slotPassengerDetails"+index+type)) {
		document.getElementById("slotPassengerDetails"+index+type).style.display = "";
		document.getElementById("slotService"+index+slotIndex+type).className = "time-col-active2";
	}
	
	var adultMale = 1, adultFemale = 0, childMale = 0, childFemale = 0;
	var searchType = "", stockNo = "", concessionId = "", serviceCategoryId = "";
	var ajaxAction = type;
	if(ajaxAction =="fw") {
		journeyTypeFlag="Forward";
	}else {
		journeyTypeFlag="Return";
	}
	if(document.getElementById("totalAdult"+index+slotIndex) != null)
		adultMale = trim(document.getElementById("totalAdult"+index+slotIndex).value);
	if(document.getElementById("adultFemale") != null)
		adultFemale = trim(document.getElementById("adultFemale").value);
	if(document.getElementById("totalChild"+index+slotIndex) != null)
		childMale = trim(document.getElementById("totalChild"+index+slotIndex).value);
	if(document.getElementById("childFemale") != null)
		childFemale = trim(document.getElementById("childFemale").value);
	if(adultMale == '') adultMale = 0;
	if(adultFemale == '') adultFemale = 0;
	if(childMale == '') childMale = 0;
	if(childFemale == '') childFemale = 0;
	if(document.getElementById("concessionIds"+journeyTypeFlag+index) != null)
		concessionId = document.getElementById("concessionIds"+journeyTypeFlag+index).value;
	if(document.getElementById("serviceCategoryId") != null)
		serviceCategoryId = document.getElementById("serviceCategoryId").value;
	var ticketType = "";
	if(document.getElementById("ticketType") != null)
		ticketType = document.getElementById("ticketType").value ;
	var journeyDate = document.getElementById("txtJourneyDate").value;
	
	path =  path+ "?slotIndex=" +index+slotIndex
	+ "&ajaxAction=" + ajaxAction
	+ "&endPlaceId="+document.getElementById("destinationId"+index+slotIndex).value
	+ "&startPlaceId=" +document.getElementById("originId"+index+slotIndex).value
	+ "&serviceRouteId="+document.getElementById("serviceRouteId"+index+slotIndex+type).value
	+ "&adultMale=" + adultMale
	+ "&adultFemale=" + adultFemale
	+ "&childMale=" + childMale
	+ "&childFemale=" + childFemale
	+ "&concessionId=" + concessionId
	+ "&srvcTypeCatgId=" + serviceCategoryId
	+ "&serviceCategoryId=" + categoryId
	+ "&ticketType=" + ticketType
	+ "&txtJourneyDate=" + journeyDate 
	+ "&searchType=" + searchType
	+ "&slotId=" + document.getElementById("slotKeyRecordId"+index+slotIndex).value
	;
	
	if(divName =="SlotFareDetailsDivID") {
		ajaxCommonActionSubmit(path, divName+index+slotIndex, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}else {
		ajaxCommonActionSubmit(path, divName+index+type, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
	}
	
	
	return true;
}

function enablePassengerEntryForm(index, id, requestType) {
	var totalSlotCount = document.getElementById("totalSlotCount").value;
	for(var i=0;i<=totalSlotCount;i++) {
		if(i !=Number(index)) {
			if(document.getElementById(id+i+requestType)) {
				document.getElementById(id+i+requestType).style.display = "none"
			}
			
		}
	}
	if(document.getElementById(id+index+requestType)) {
		document.getElementById(id+index+requestType).style.display = "";
	}
	for(var i=0;i<=totalSlotCount;i++) {
		if(i !=Number(index)) {
			if(document.getElementById("slotService"+i+requestType)) {
				document.getElementById("slotService"+i+requestType).className = "time-col-active";
			}
			
		}
	}
	if(document.getElementById("slotPassengerDetails"+index)) {
		document.getElementById("slotPassengerDetails"+index).style.display = "";
		document.getElementById("slotService"+index+requestType).className = "time-col-active2";
	}
}

function setPaxName(journeyType, slotIndex) {
	var currentSlot = document.getElementById("currentSlotIndex").value;
	if(document.getElementById("passengerName"+journeyType+"0")) {
		document.getElementById("passengerName"+journeyType+"0").value=document.getElementById("bookedByName"+currentSlot).value;
	}
}

function setETA(response, div){
	
	if(response == null)
		return false;
	
	if(response!=null && response.eta!=null){
		var eta = response.eta;
	    if(document.getElementById(div)!= null){
	    	document.getElementById(div).innerHTML = "<p>ETA : "+eta+"</p>";
	    }
	}
	return true;
	
}

function decodeHtmlEntities(str) {
    const txt = document.createElement("textarea");
    txt.innerHTML = str;
    return txt.value;
}

async function fetchETA(url, div, body, isEnable, isDebug) {
    if (isEnable == null || !isEnable) {
        return false;
    }
    if (isDebug == null || isDebug) {
        body = JSON.stringify({ // sample ids
            docId: "27062024_SS03_1_VIJAYAWADA",
            placeId: "3481"
        })
    } else {
        body = decodeHtmlEntities(body);
    }

    try {
        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: body,
            credentials: 'omit' // This is similar to `withCredentials: false`
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();

        // Assuming data structure is as described
        if (data.status === 'success' && data.data.length > 0) {
            const etaTimestamp = data.data[0].ETA;
            if (etaTimestamp == null) {
                throw new Error('Invalid response structure', body);
            }
            const etaDate = new Date(etaTimestamp);
            const formattedETA = etaDate.toLocaleTimeString('en-US', {
                hour: '2-digit',
                minute: '2-digit',
                hour12: false
            });

            document.getElementById(div).innerText = `ETA: ${formattedETA}`;
        } else {
            throw new Error('Invalid response structure', body);
        }
    } catch (error) {
        console.error('Error fetching ETA:', error);
    }
}




function continueEndBkg() {
	if(!validateSubmitBookingLayout()) {
		return false;
	}
	if(!checkRedeemRewardEnable()) {
		return false;
	}
	if(!validateTTDDarsanPassengers('Forward')) {
		return false;
	}
	var acttype = "Forward";
	if(document.getElementById('isLinkEndBooking') != null && document.getElementById('isLinkEndBooking').value == '1'){
		acttype = "Return";
	}
	
 	if(document.getElementById('srisailamAccommodationId') != null && document.getElementById('srisailamAccommodationId').value != ''){
		if(($('#srisailamAccommodationId').length == 0  || ($('#srisailamAccommodationId').length > 0 
	 			&& document.getElementById('srisailamAccommodationId').value == ''))
	 			|| (($('#SrslmAccomadationDiv').css('display') != 'none') 
	 					&& ($('#idProofPopUp'+acttype).css('display') == 'block'))){
	
			alert("Now, please select the connecting journey service.");
			
			if(document.getElementById('srisailamAccJourneyDate') != null){
				if(document.getElementById('isFirstLinkSrslm') != null){
					document.getElementById('isFirstLinkSrslm').value = '1';
				}
			}
			
			hidediv('ForwardAvailableServicesDiv');
			showdiv('ReturnAvailableServicesDiv');
			
			var uc = 'unSelectedDivCs';
			addRemoveCss('fwInfoLeftId', uc, true);
			addRemoveCss('retInfoLeftId', uc, false);
			setTimeout("getAvailableLinkServiceList('1', '1')", 60);
			//accomPrice=0;// For return set this one to zero value.
	 	}else if(document.getElementById('paxProofId') != null){
		 		if(document.getElementById('isFirstLinkSrslm') != null){
					document.getElementById('isFirstLinkSrslm').value = '1';
				}
				getIdProofPopUp("idProofPopUp"+acttype);
 	 		
	 	}else{
	 		alert("Now, please select the connecting journey service.");
	 		
	 		hidediv('ForwardAvailableServicesDiv');
	 		showdiv('ReturnAvailableServicesDiv');
	 		
	 		var uc = 'unSelectedDivCs';
	 		addRemoveCss('fwInfoLeftId', uc, true);
	 		addRemoveCss('retInfoLeftId', uc, false);
			setTimeout("getAvailableLinkServiceList('1', '1')", 60);
	 		//accomPrice=0;// For return set this one to zero value.	
	 	}
 	}else{
		if(($('#ttdAccommodationId').length == 0  || ($('#ttdAccommodationId').length > 0 
					&& document.getElementById('ttdAccommodationId').value == ''))
					|| (($('#TtdAccomadationDiv').css('display') != 'none') 
							&& ($('#idProofPopUp'+acttype).css('display') == 'block'))){
	
				alert("Now, please select the connecting service.");
				
				if(document.getElementById('ttdAccJourneyDate') != null){
					if(document.getElementById('isFirstLinkTtd') != null){
						document.getElementById('isFirstLinkTtd').value = '1';
					}
				}
				
				if(document.getElementById('srisailamAccJourneyDate') != null){
					if(document.getElementById('isFirstLinkSrslm') != null){
						document.getElementById('isFirstLinkSrslm').value = '1';
					}
				}
				
				hidediv('ForwardAvailableServicesDiv');
				showdiv('ForwardEndAvailableServicesDiv');
				
				var uc = 'unSelectedDivCs';
				addRemoveCss('fwInfoLeftId', uc, true);
				addRemoveCss('retInfoLeftId', uc, false);
				//accomPrice=0;// For return set this one to zero value.
				setTimeout("getAvailableLinkServiceList('1', '1')", 60);
			}else if(document.getElementById('paxProofId') != null){
				if(document.getElementById('isFirstLinkTtd') != null){
					document.getElementById('isFirstLinkTtd').value = '1';
				}
				getIdProofPopUp("idProofPopUp"+acttype);
			}else{
				alert("Now, please select the connecting service.");
				
				hidediv('ForwardAvailableServicesDiv');
				showdiv('ForwardEndAvailableServicesDiv');
				var uc = 'unSelectedDivCs';
				addRemoveCss('fwInfoLeftId', uc, true);
				addRemoveCss('retInfoLeftId', uc, false);
				//accomPrice=0;// For return set this one to zero value.
				setTimeout("getAvailableLinkServiceList('1', '1')", 60);
	 	}
 	}
}

function getAvailableLinkServiceList(actType, searchType) {
	DIV_DEFAULT_WIDTH = "100%";
	var paramStr = "";
	showdiv("progressBarDiv");
	paramStr = "?txtJourneyDate=" + document.getElementById("txtJourneyDate").value;
	var linkPlaceId = document.getElementById("linkPlaceId").value;
	var divName = "ForwardAvailableServicesDiv";
	var firstConnectArrivaTime = "";
	var firstConnectArrivalDay = 0;
	if(actType == '1') {
		path = "/return/booking/avail/services.do";
		// return journey parameters
		if(document.getElementById("ForwardJourneyTime_2") != null && document.getElementById("ForwardJourneyTime_2").value != ''){
			firstConnectArrivaTime = document.getElementById("ForwardJourneyTime_2").value;
		}
		if(document.getElementById("ForwardArrivalDay") != null && document.getElementById("ForwardArrivalDay").value != '' ){
			firstConnectArrivalDay = document.getElementById("ForwardArrivalDay").value;
		}
		paramStr = paramStr 
					+ "&startPlaceId=" + linkPlaceId
					+ "&endPlaceId=" + document.getElementById("endPlaceId").value
					+ "&txtReturnJourneyDate=" + document.getElementById("txtReturnJourneyDate").value
					+ "&ajaxAction=ret" 
					+ "&isLinkEndBooking=1"	
					+ "&firstConnectArrivaTime=" + 	firstConnectArrivaTime
					+ "&firstConnectArrivalDay=" + 	firstConnectArrivalDay
					+ "&linkForwardArrivalTimeStr="+document.getElementById('linkForwardArrivalTimeStr').value;
					;
		document.getElementById("isLinkEndBooking").value = 1;
		divName = "ForwardEndAvailableServicesDiv";
	} else {
		// forward journey parameters
		path = "/forward/booking/avail/services.do";
		paramStr = paramStr
				+ "&startPlaceId=" + linkPlaceId
				+ "&endPlaceId=" + document.getElementById("endPlaceId").value
				+ "&txtLinkJourneyDate=" + document.getElementById("txtLinkJourneyDate").value
				+ "&ajaxAction=fw"
				+ "&linkForwardArrivalTimeStr="+document.getElementById('linkForwardArrivalTimeStr').value;
				;
	}
	if(document.getElementById("covidBkgEnable"))
		paramStr= paramStr	+ "&covidBkgEnable=" + document.getElementById("covidBkgEnable").value
		
	path = path + paramStr + "&qryType=" + searchType;
	showdiv('ForwardEndAvailableServicesDiv');
	ajaxCommonActionSubmit(path, divName, DIV_DEFAULT_WIDTH, DIV_DEFAULT_HEIGHT);
}

function addDaysToDate(dateStr, days){
	var [dd, mm, yyyy] = dateStr.split('/');
	var nextDate = new Date(`${mm}/${dd}/${yyyy}`);
	nextDate.setDate(nextDate.getDate() + days);
	var newDateString = `${nextDate.getDate().toString().padStart(2, '0')}/${(nextDate.getMonth() + 1).toString().padStart(2, '0')}/${nextDate.getFullYear()}`;
	return newDateString
}


function getNextJourneyDate(dptTme, jrDurationFwd){
	var day = parseInt(dptTme.slice(0, 2));
	var month = parseInt(dptTme.slice(3, 5)) - 1; // Month is zero-indexed in Date object
	var year = parseInt(dptTme.slice(6, 10));
	var hours = parseInt(dptTme.slice(10, 12));
	var minutes = parseInt(dptTme.slice(12));
	var dateNext = new Date(year, month, day, hours, minutes);
	var hh = Number(jrDurationFwd.substring(0,2));
	var mm = Number(jrDurationFwd.substring(3));
	dateNext.setHours(dateNext.getHours() + hh);
	dateNext.setMinutes(dateNext.getMinutes() + mm);
	
	dateNext.setHours(dateNext.getHours() + 2);
	dateNext.setMinutes(dateNext.getMinutes() + 0);
	
	var newDate = new Date(dateNext);
	
	var returnDateStr = "";
	year = newDate.getFullYear();
	month = newDate.getMonth()+1;
	if(month < 10){
		month = "0"+month;
	}
	day = newDate.getDate();
	if(day < 10){
		day = "0" + day;
	}
	returnDateStr = day+"/"+month+"/"+year;
	return returnDateStr;
}

function handleSelect(checkbox) {
	toggleElements();
	if (checkbox.checked == true) {
		submitAjaxAction('/ajax/return/ticket/info.do?id='
				+ document.getElementById('id').value + '&uidNumber='
				+ document.getElementById('uidNumber').value + '&mobileNo='
				+ document.getElementById('mobileNo').value,
				'returnTicketDetails');
	} else {
		document.getElementById('returnTicketDetails').innerHtml='';
		if(document.getElementById('returnId') != null)
			document.getElementById('returnId').value='';
		if(document.getElementById('returnUidNumber') != null)
			document.getElementById('returnUidNumber').value='';
		if(document.getElementById('returnMobileNo') != null)
			document.getElementById('returnMobileNo').value='';
	}
	
	if(document.getElementById('BookedTicketsDivId')!=null) {
		document.getElementById('BookedTicketsDivId').innerHTML = '';
	}
	if(document.getElementById('RefundTicketsDivId')!=null) {
		document.getElementById('RefundTicketsDivId').innerHTML = '';
	}
}


function futureDateCalPopup(id) {
	// var dateToday = new Date();
	$('#'+id).datepicker({ 
		dateFormat: 'dd/mm/yy',
		changeMonth: true,
		changeYear: true,
		maxDate: 0
		});
	$('#'+id).datepicker("show");
	
	/*
	 * var date = serverdate.getDate(); var month = serverdate.getMonth() + 1;
	 * var year = serverdate.getFullYear();
	 * 
	 * if(self.gfPop) {
	 * gfPop.fPopCalendar(document.getElementById(id),[[year,month,date]]); }
	 */
	return false;
}


